import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent implements OnInit {
  error = false;
  logdata: any;
  url = this.api.geturl();
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {
    
  }

  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    $('#back_button').css('display', 'block');
   
  }
  unsubscribe(){
    if (!($('#username').val())) {
      $('#username').addClass('error');
      this.error = true;
    }  
    if (this.error == false) {
      var user_id = {
        // user_id: this.logdata.user_id,
        username: $('#username').val(),
      }
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/user_resubscribe`, user_id).subscribe(data => {

          if (data.status == false) {
            $('.pageloader').hide();
            $('#alertbtn').trigger('click');
            $('#alerttitle').html('<img src="assets/images/block.svg"> Subscribed');
            $('#alerttext').html(data.message);
          } else {
            $('.pageloader').hide();
            // $('#error-disp-btn').trigger('click');
            // $('#modal_pass').html('<img src="assets/images/success.svg"> Profile');
            // $('#errortext').html(data.message);
            this.router.navigate(['login/']);
          }
        }, err => {
          $('.pageloader').hide();
        })
     
    }
  }
  change() {
    $('#username').val($('#username').val().replace(/[^a-z0-9]/gi, ''));

    if ($('#username').val().length < 6) {
      // console.log('enter')
      $('#username').addClass('error');
      this.error = true;
    } else {
      var reg_Ex =/^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
      var isValiduname = reg_Ex.test($('#username').val())
      if(isValiduname== false){
        this.error = true
      $('#username').addClass("error");
      }else{
        this.error =false
        $('#username').removeClass('error');
      }
      // $('#username' + id).removeClass('error');
      // this.error = false;
    }
  }
}
