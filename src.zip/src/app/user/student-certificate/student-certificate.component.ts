import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-student-certificate',
  templateUrl: './student-certificate.component.html',
  styleUrls: ['./student-certificate.component.css']
})
export class StudentCertificateComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  logdata:any;
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('#dropdownMenu1').addClass('active');//my dashboard menu highlight
    localStorage.setItem("add_click", JSON.stringify('0')); 
    $('#dashtog').trigger('click');
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    console.log(this.logdata.family_code)
    this.getDatas()
    
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
    var user_id = {
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
      family_code:this.logdata.family_code
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/studentcertificate_list`,  user_id   ).subscribe(data => {
      this.list = data.awards
      $('#showcount').html(data.awards.length);
      $('.pageloader').hide();
    }, err => {
      $('.pageloader').hide();
    })
  }
  getDatas() {
    var type = {
      type: "" ,// request post data
      family_code:this.logdata.family_code
    }
    // console.log(this.logdata.family_code)
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/studentcertificate_list`, type).subscribe(data => {
      $('.pageloader').hide();
      this.list = data.awards
      this.cumulative=data.awards.length;
      $('#showcount').html(data.awards.length);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

//deleting schools
deleteData(data) {
 
  $('#deletebttn').trigger('click');
  var user = {
    tablename : 'students',
    fieldid: data.student_id,
    fieldname: 'student_id'
  }
  localStorage.setItem('delete_item', JSON.stringify(user));
}
//
showcertificate(data){
  // alert('working')
  localStorage.setItem('student_certificate', JSON.stringify(data));
 
}



 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}
