import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SidemenuUserComponent } from './sidemenu-user.component';

describe('SidemenuUserComponent', () => {
  let component: SidemenuUserComponent;
  let fixture: ComponentFixture<SidemenuUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SidemenuUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SidemenuUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
