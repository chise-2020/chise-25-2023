import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';



declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-sidemenu-user',
  templateUrl: './sidemenu-user.component.html',
  styleUrls: ['./sidemenu-user.component.css']
})
export class SidemenuUserComponent implements OnInit {
  logdata: any;
  res: any;
  url = this.api.geturl();
  constructor(private api: ApiService, private http: HttpClient, private route: Router) {

  }

  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));

    if (localStorage.getItem("loginData") != null) {

    if (this.logdata.class == 'student 2') {
      $('#regi_student').css('display', 'none');
      // $('.grdp2').css('pointer-events', 'none');
    }

    if (this.logdata.class == 'alumnus') {
      $('.parents').css('display', 'none');
      $('.alumni').css('display', 'block');
    }
    if (this.logdata.class == 'guardian 1') {
      // $('.parents').css('display', 'block');
      $('.guard1').css('display', 'block');
    }
  }
    $('#yesbtn').click(function () {
      $('#stcount').trigger('click');
    })

    $('#nobtn').click(function () {
      window.location.href = "";
    })
  }


  checkstudent() {
    var user_id = {
      user_id: this.logdata.user_id,
      family_code: this.logdata.family_code
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/check_registration`, user_id).subscribe(data => {
      $('.pageloader').hide();

      // Get back item "kittens" from local storage
      var logdat = JSON.parse(localStorage.getItem("loginData"));
      console.log(this.logdata.authorize)
      // Change value
      logdat.student_count = data.studentcount;

      // Save the new item with updated value
      localStorage.setItem("loginData", JSON.stringify(logdat));
      
      localStorage.setItem("stcount", data.studentcount);
     
       if (this.logdata.authorize == 'Yes') 
      {
        // alert('yes')
        if ((data.startonline == 1) )
        {
          // console.log('--yes')
          if ((data.studentcount == 0)){
            $('#optionbtn2').css('display', 'block');
            $('#okbtn').css('display', 'none');
            $('#reviewbtn').trigger('click');
            $('#review').html('<div class="nostudent"> You have 0 Student in your Family Profile.<br/><br/>Each Student must be added to your Family Profile before you can register the student.<br/><br/>Do you want add now?</div>');
            $('#dynamictitle').html('<img src="assets/images/block.svg">Family Profile');
          } else {

            if ((data.status == true) && (data.guard_count == 0)) {
              $('#optionbtn').css('display', 'block');
              $('#okbtn').css('display', 'none');
              $('#reviewbtn').trigger('click');
              $('#yesbutton').css('display','block');
            $('#nobutton').css('display','block');
              $('#review').html(data.html);
              $('#dynamictitle').html('<img src="assets/images/PROFILE.svg">REGISTER STUDENT');
              // yesbutton
              if (this.logdata.class == 'guardian 2') {
                $('#yesbutton').css('display','none');
                $('#cancelbutton').css('display','block');
              }
            }
            else {
              $('#alertbtn').trigger('click');
              $('#alerttitle').html('<img src="assets/images/alert.svg">FAMILY PROFILE');
              // $('#alerttext').html('<div><h5 class="text-center " >You must <u style="font-weight: 700;" >complete</u> the User Profile before you can register.</h5></div>');
              $('#alerttext').html(data.message);
      
            }
          }
        } else {
          var user_id = {
            user_id: ''
          }
          this.http.post<any>(`${this.url}/check_online`, user_id).subscribe(data => {
            $('#notipop').html(data.message);
            $('#noti_button').trigger('click');
  
          })
          
        }
      }else {
        // alert('inside')
// console.log('--no')
$('#alertbtn').trigger('click');
$('#alerttitle').html('<img src="assets/images/alert.svg">REGISTRATION BLOCKED');
$('#alerttext').html('<div><h5 class="text-center " >Student is not allowed to register online!</h5></div>');

      }

    }, err => {
      $('.pageloader').hide();
    })
  }
  faq(){
    // alert(window.location.href);
      var url =window.location.href;
      const lastSegment = url.substring(url.lastIndexOf("/") + 1);
      // alert(lastSegment)
      localStorage.setItem('previous_url',JSON.stringify(lastSegment));
  }
}
