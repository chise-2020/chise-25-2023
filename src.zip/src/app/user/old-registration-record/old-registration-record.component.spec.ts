import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldRegistrationRecordComponent } from './old-registration-record.component';

describe('OldRegistrationRecordComponent', () => {
  let component: OldRegistrationRecordComponent;
  let fixture: ComponentFixture<OldRegistrationRecordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldRegistrationRecordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OldRegistrationRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
