import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';


declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-registration-records',
  templateUrl: './registration-records.component.html',
  styleUrls: ['./registration-records.component.css']
})
export class RegistrationRecordsComponent implements OnInit {
  studentsList: any = [];
  searchText: any = '';
  cumulative=0;
  pageOfItems: Array<any>;
  data: any =[]; 
  first_year: any =[]; 
  url = this.api.geturl();
  number: any =[];
  constructor(private api: ApiService,private fb: FormBuilder,private router: Router,private http: HttpClient ,) {
    
  }

  ngOnInit(): void {
    $('#dropdownMenu1').addClass('active');//my dashboard menu highlight
    localStorage.setItem("add_click", JSON.stringify('0')); 
    this.data = JSON.parse(localStorage.getItem('loginData')); //forgot to close
    this.get_record()
    $('#dashtog').trigger('click');
  }
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
    var user_id = {
      user_id : this.data.user_id,
      group_id : this.data.family_code,
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
      merged_stat:0
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/registration_record`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.studentsList = data.user
      this.first_year = data.first_year
      this.number = data.number
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
    })
  }
  


  get_record(){
    var user_id = {
      user_id : this.data.user_id,
      group_id : this.data.family_code,
      type : '',
      search : 0,
      value : '',
      merged_stat:0
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/registration_record`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.studentsList = data.user
      this.cumulative=data.user.length;
      this.first_year = data.first_year
      this.number = data.number
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
    })
  }

  //exporting the selected data as csv
  export_data() {
    var selected_array=['name','program_name', 'academic_term','academic_year','grade','school_name','parentname'];
    var header_array=['Student','Program Module','Term', 'Year','Grade','School','Registering Parent'];
   this.api.downloadFile(this.studentsList,selected_array,header_array, 'Student Registrations');
}
//
}
