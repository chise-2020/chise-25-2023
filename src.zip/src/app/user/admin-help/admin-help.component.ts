import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-help',
  templateUrl: './admin-help.component.html',
  styleUrls: ['./admin-help.component.css']
})
export class AdminHelpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
