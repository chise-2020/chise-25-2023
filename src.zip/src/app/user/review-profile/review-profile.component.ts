import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-review-profile',
  templateUrl: './review-profile.component.html',
  styleUrls: ['./review-profile.component.css']
})
export class ReviewProfileComponent implements OnInit {
  url = this.api.geturl();
  form: FormGroup;
  userid:any;
  logdata:any;
  myModel = "1"
  student_count= false
  constructor(private api: ApiService,private fb: FormBuilder,private http: HttpClient,private router: Router,) 
  { 
    this.createForm();
  }

  ngOnInit(): void {
    localStorage.setItem("add_click", JSON.stringify('0')); 
    $('#cnt_us').css('display', 'block');
    // this.userid = JSON.parse(localStorage.getItem('logid'));
    console.log(JSON.parse(localStorage.getItem('loginData')));
    // if(this.userid){
    //   console.log('register')
    //    console.log(this.userid)
    //  this.form.get('user_id').setValue(this.userid); 
      
    // }else{
     
      // console.log('login')
      this.logdata = JSON.parse(localStorage.getItem('loginData')); 
      this.userid=this.logdata.user_id
      console.log(this.userid) 
      this.form.get('user_id').setValue(this.userid); 
    // }
  
    
    // 
  }


  createForm() {
    this.form = this.fb.group({
      student_count: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
    });
  }

  save_students()
  {
    this.formValidation()
    if(this.student_count== true){
      return;
      }
      console.log(this.form.value);
    this.http.post<any>(`${this.url}/save_count`,  this.form.value).subscribe(data => {
      $('.pageloader').hide();
      if(this.userid!='')
      {
        // localStorage.setItem('loginData', JSON.stringify(data.user));
        // this.router.navigate(['user-profile/']);
        if(data.status==false){
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg">FAMILY PROFILE SECTIONS');
          $('#errortext').html('Failed to update the Student Count');
         
         }
        else if(data.status==true){
        localStorage.setItem('student_count', JSON.stringify(data.student_count));  
  // console.log(data.student_count);
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">FAMILY PROFILE');
          $('#errortext').html(data.message);
          $('#review_profile').css('display','block');
          $('#ok').css('display','none');
        }
      }
      }, err => {
        console.log(err);
      })
  }


  formValidation(){
    if(this.form.value.student_count){
      this.student_count= false
    
    }else{
      this.student_count= true
    }
  }
}
