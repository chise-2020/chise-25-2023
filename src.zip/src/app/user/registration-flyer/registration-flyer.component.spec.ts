import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationFlyerComponent } from './registration-flyer.component';

describe('RegistrationFlyerComponent', () => {
  let component: RegistrationFlyerComponent;
  let fixture: ComponentFixture<RegistrationFlyerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistrationFlyerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationFlyerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
