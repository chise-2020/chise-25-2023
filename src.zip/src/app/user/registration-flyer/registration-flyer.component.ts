import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-registration-flyer',
  templateUrl: './registration-flyer.component.html',
  styleUrls: ['./registration-flyer.component.css']
})
export class RegistrationFlyerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $('#mess').trigger('click');
  }

}
