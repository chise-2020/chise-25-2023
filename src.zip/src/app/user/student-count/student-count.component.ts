import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-student-count',
  templateUrl: './student-count.component.html',
  styleUrls: ['./student-count.component.css']
})
export class StudentCountComponent implements OnInit {
  url = this.api.geturl();
  form2: FormGroup;
  userid:any;
  myModel:any;
  student_count= false
  logdata:any;
  students_count:any;
  log_data:any;
  profdata:any;
  constructor(private api: ApiService,private fb: FormBuilder,private http: HttpClient,private router: Router,) 
  { 
    this.createForm2();
  }

  ngOnInit(): void {
    this.log_data = JSON.parse(localStorage.getItem('loginData')); 
    if ((this.log_data.class == "admin")) 
      { 
        console.log('admin')
    this.logdata = JSON.parse(localStorage.getItem('set_userprofile'));

      }else{
        console.log('user')
     this.logdata = JSON.parse(localStorage.getItem('loginData'));   

      }
    
    
    this.form2.get('user_id').setValue(this.logdata.user_id);
    this.form2.get('group_id').setValue(this.logdata.family_code);
    this.getUser()
    console.log(this.logdata.family_code)
  }
 


  getUser(){
    var user_id = {
      user_id : this.logdata.user_id,
      family_code : this.logdata.family_code
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/user_profile`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      // console.log(data.student_count)
      localStorage.setItem('student_count', JSON.stringify(data.student_count));
      this.profdata =JSON.parse(localStorage.getItem('set_userprofile'));
      console.log( this.profdata )
      if(data.students_count==0){
        if ((this.log_data.class != "admin") || (this.profdata.access_level == "STUDENT 2") ) 
        { 
    $('#student_count').css('display', 'none');

        }
      }else{
        this.myModel=""+data.student_count+"";
      }
      if (this.logdata.class == 'guardian 2') {
        $('.student_count').css('pointer-events', 'none');
        $('.student_count').addClass('textback');
        $('#student_count_btn').css('display', 'none');
        $('.student_count_btn').css('pointer-events', 'none');
      }
       
        }, err => {
          $('.pageloader').hide();
        })
        
  }

  createForm2() {
    this.form2 = this.fb.group({
      student_count: new FormControl('', [Validators.required,]),
      group_id: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
    });
  }

  save_students()
  {
    this.formValidation()
    if(this.student_count== true){
      return;
      }
      this.students_count= JSON.parse(localStorage.getItem('student_count'));
      console.log('old'+this.students_count)//old value
      console.log('new'+JSON.parse(this.form2.value.student_count));//new value
if(this.students_count!=JSON.parse(this.form2.value.student_count)){
      if(this.students_count < JSON.parse(this.form2.value.student_count))
{
  // alert('adding more')
  //adding more students to the family
  var user_id = {
    user_id : this.logdata.user_id,
    family_code : this.logdata.family_code,
    student_count:JSON.parse(this.form2.value.student_count)
  }
  localStorage.setItem('student_count_data', JSON.stringify(user_id));
  var students_count= JSON.parse(localStorage.getItem('student_count_data'));
  console.log(students_count)
  var stud_count=JSON.parse(this.form2.value.student_count);
  // alert(stud_count)
  $('#st_head').html('Add Student Sections?');
  
  $('#first_line').html('You have opted to add more Students to your Profile.')
  $('#first_para').html('Note: Increasing Student Count will increase # of Student Sections.');
  $('#second_para').html('# of Student Sections will go up from  '+this.students_count +' to '+stud_count);
  // # of Student Sections will go up from X to Y.

  $('#modal_pass1').html('<img src="assets/images/alert.svg">FAMILY PROFILE ');
 $('#st_count').trigger('click');
  $('#ok1').html('No');
  $('#ok').addClass('violet-btn');
  $('#ok').removeClass("green-btn");
//     this.http.post<any>(`${this.url}/save_count`,  this.form2.value).subscribe(data => {
//       $('.pageloader').hide();
//       if(data.status==false){
//         $('#error-disp-btn').trigger('click');
//         $('#modal_pass').html('<i class="fas fa-ban"></i>FAMILY PROFILE SECTIONS');
//         $('#errortext').html('Failed to update the Student Count');
//        }
//       else if(data.status==true){
//       localStorage.setItem('student_count', JSON.stringify(data.student_count));  
// // console.log(data.student_count);
//         $('#error-disp-btn').trigger('click');
//         $('#modal_pass').html('<i class="fas fa-check-circle"></i>FAMILY PROFILE SECTIONS');
//         $('#errortext').html(data.message);
        
//       }
     
      // }, err => {
      //   console.log(err);
      // })
    }else{
      //latest added student is deleted
// alert('lesser')
var user_id = {
  user_id : this.logdata.user_id,
  family_code : this.logdata.family_code,
  student_count:JSON.parse(this.form2.value.student_count)
}
localStorage.setItem('student_count_data', JSON.stringify(user_id));
var students_count= JSON.parse(localStorage.getItem('student_count_data'));
console.log(students_count.student_count)
console.log('count')
$('#st_count').trigger('click');
$('#st_head').html('Remove Student Sections?');
$('#modal_pass1').html('<img src="assets/images/alert.svg">FAMILY PROFILE ');
$('#second_para').html('# of Student Sections will go down from  '+this.students_count +' to '+students_count.student_count);
  
// $('#errortext1').html('CAUTION!<br>Student Count defines the number of Student Sections.<br><span style="text-decoration:underline">Reducing</span> the Student Count will automatically delete some sections and data that you may have entered.<br>Deletion starts with the highest section #.<br><i  class="fa fa-circle" aria-hidden="true"></i> E.g. if you change count from 3 to 2, Student #3 section will be automatically deleted.<br><br>Are you sure you want to proceed?');
$('#ok').addClass('violet-btn');
$('#ok1').html('No');

$('#ok').addClass('violet-btn');
$('#ok').removeClass("green-btn");
    }

  }else{
    $('#alertbtn').trigger('click');
    $('#alerttitle').html('<img src="assets/images/alert.svg">FAMILY PROFILE ');
    $('#alerttext').html('Student Count is unchanged!');
  }
  }


  formValidation(){
    if(this.form2.value.student_count){
      this.student_count= false
    
    }else{
      this.student_count= true
    }
  }
}
