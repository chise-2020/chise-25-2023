import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-header-user',
  templateUrl: './header-user.component.html',
  styleUrls: ['./header-user.component.css']
})
export class HeaderUserComponent implements OnInit {
  logdata: any;
  url = this.api.geturl();
  notifications= [];
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {

  }

  ngOnInit(): void {
    $(document).on('click', '.mobile-menu-button', function () {
      $(".mega-menu").toggleClass("open");
     });
     $(document).on('click', '.close-menu', function () {
      $(".mega-menu").toggleClass("open");
     });
    if (localStorage.getItem("loginData") != null) {
    this.checkuser()
    }
    this.getnotification()

    if (localStorage.getItem("loginData") != null) {

      if (this.logdata.class == 'alumnus') {
        $('.parents').css('display', 'none');
        $('.alumni').css('display', 'block');
        $('.bellicon').css('display', 'none');
      }
    }
  }
  getnotification(){
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    var user_id = {
      user_id : this.logdata.user_id
    }
    this.http.post<any>(`${this.url}/get_notification`,user_id).subscribe(data => {
      if(data.status==true)
      {
     this.notifications=data.list;
      }
     
      })
  }
  checkuser() {
    
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id: this.logdata.user_id
      }
      this.http.post<any>(`${this.url}/check_user`, user_id).subscribe(data => {

        if(data.onlinereg_status==1){
          $('#faicon').addClass('green2');
        }else{
          $('#faicon').addClass('redhead');
          $('#faicon').css('background','red !important');
            $('#faicon').html('ONLINE REGISTRATION CLOSED');
        }

        if (data.status == false) {
          this.router.navigate(['login/']);
          localStorage.clear();
        }

      })
    


  }
faq(){
  // alert(window.location.href);
    var url =window.location.href;
    const lastSegment = url.substring(url.lastIndexOf("/") + 1);
    // alert(lastSegment)
    localStorage.setItem('previous_url',JSON.stringify(lastSegment));
}
 
  logout() {
    localStorage.clear();
    this.router.navigate(['login/']);
  }
  notification() {
    // alert('working')
    if (localStorage.getItem('loginData') === null) {
      this.router.navigate(['login/']);
      localStorage.clear();



    } else {
      
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id: ''
      }
      this.http.post<any>(`${this.url}/check_online`, user_id).subscribe(data => {
          $('#notipop').html(data.message);
        $('#noti_button').trigger('click');

      })
     
    }


  }
}
