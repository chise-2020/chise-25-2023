import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finish-page',
  templateUrl: './finish-page.component.html',
  styleUrls: ['./finish-page.component.css']
})
export class FinishPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
