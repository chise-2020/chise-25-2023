import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';


declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-admin-support',
  templateUrl: './admin-support.component.html',
  styleUrls: ['./admin-support.component.css']
})
export class AdminSupportComponent implements OnInit {
  logdata:any;
  form: FormGroup;
  category=false
  description=false
  requests: any = [];
  ticketid:any[];
  time:any[];
  url = this.api.geturl();
  constructor(private api: ApiService,private fb: FormBuilder,  private http: HttpClient , private router: Router,) { 
    this.createForm();
    
  }

  ngOnInit(): void {
    localStorage.setItem("add_click", JSON.stringify('0')); 
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    var dt = new Date();
    var time = dt.getFullYear()+ "-"+ (dt.getMonth()+1)+ "-"+ dt.getDate()+ " "+ dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    this.form.get('date').setValue(time);
    this.form.get('user_id').setValue(this.logdata.user_id);
    this.getrequest()

   var ticketid=Math.random().toString(16).slice(10);
    this.form.get('ticketid').setValue(ticketid);
  }

   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }

  search()
  {

    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;

    var pwd={
      user_id : this.logdata.user_id,
      group_id : this.logdata.family_code,
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
    }
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/get_requests`,  pwd).subscribe(data => {
          $('.pageloader').hide();
          this.requests=data.results;
          }, err => {
            $('.pageloader').hide();
          })
  }
 

  getrequest(){
    var pwd={
      user_id : this.logdata.user_id,
      group_id : this.logdata.family_code,
      type : '',
      search : 0,
      value : '',
    }
             $('.pageloader').show();
             this.http.post<any>(`${this.url}/get_requests`,  pwd).subscribe(data => {
               $('.pageloader').hide();
               this.requests=data.results;
               }, err => {
                 $('.pageloader').hide();
               })
  
   }
 
   show_request()
   {

    var value={
      category : this.form.getRawValue().category,
      description : this.form.getRawValue().description,
      user_id : this.logdata.user_id,
      date:this.form.getRawValue().date,
      ticketid:this.form.getRawValue().ticketid,
    }

    this.http.post<any>(`${this.url}/get_family`,  value).subscribe(data => {
      $('.pageloader').hide();
        $('#reviewbtn').trigger('click');
        $('#review').html(data.html);
        $('#yesbutton').css('display','none');  
        $('#nobutton').css('display','none');
        $('#okbtn').css('display', 'block');
        $('#dynamictitle').html('<img src="assets/images/alert.svg"> View Request');
      }, err => {
        $('.pageloader').hide();
      })

   }

  validate(){
   this.category=this.description=false;
      if(this.form.getRawValue().category=='')
        this.category= true
      if(this.form.getRawValue().description=='')
        this.description= true
    
    if(this.category== false  && this.description== false){
      var value = this.form.getRawValue()
            $('.pageloader').show();
            this.http.post<any>(`${this.url}/add_request`,  value).subscribe(data => {
              $('.pageloader').hide();
              if(data.status==false){
                $('#error-disp-btn').trigger('click');
                $('#modal_pass').html('<img src="assets/images/block.svg"> Admin Support');
                $('#errortext').html(data.message);
               }
              else if(data.status==true){
                $('#pass_pop').trigger('click');
                $('#error-disp-btn').trigger('click');
                $('#modal_pass').html('<img src="assets/images/success.svg"> Admin Support ');
                $('#errortext').html(data.message);
                this.form.reset();
                var dt = new Date();
                var time = dt.getFullYear()+ "-"+ (dt.getMonth()+1)+ "-"+ dt.getDate()+ " "+ dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
                this.form.get('date').setValue(time);
                this.form.get('user_id').setValue(this.logdata.user_id);
                var ticketid=Math.random().toString(16).slice(10);
                this.form.get('ticketid').setValue(ticketid);
                this.getrequest();
              }
              }, err => {
                $('.pageloader').hide();
              })
      }
 
  }

  createForm() {
    this.form = this.fb.group({
      category: new FormControl('', [Validators.required,]),
      description:new FormControl('', [Validators.required,]),
      date:new FormControl('', [Validators.required,]),
      ticketid:new FormControl('', [Validators.required,]),
      user_id:new FormControl('', [Validators.required,]),
    });
  }
}
