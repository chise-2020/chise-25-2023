import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { JwPaginationModule } from 'jw-angular-pagination';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ApiService } from './api.service';

//common pages starts
import { StartComponent } from './common/start/start.component';
import { SubscribeComponent } from './common/subscribe/subscribe.component';
import { LoginComponent } from './common/login/login.component';
import { FooterComponent } from './common/footer/footer.component';
import { TermsConditionComponent } from './common/terms-condition/terms-condition.component';
import { ForgotPasswordComponent } from './common/forgot-password/forgot-password.component';
import { ForgotSuccessComponent } from './common/forgot-success/forgot-success.component';
import { CommingSoonComponent } from './common/comming-soon/comming-soon.component';
///user pages starts
import { ReviewProfileComponent } from './user/review-profile/review-profile.component';
import { UserProfileComponent } from './user/user-profile/user-profile.component';
import { RegisterStudentComponent } from './user/register-student/register-student.component';
import { RegistrationRecordsComponent } from './user/registration-records/registration-records.component';
import { OldRegistrationRecordComponent } from './user/old-registration-record/old-registration-record.component';
import { StudentCertificateComponent } from './user/student-certificate/student-certificate.component';
import { AdminSupportComponent } from './user/admin-support/admin-support.component';
import { MessagesComponent } from './user/messages/messages.component';
import { SidemenuUserComponent } from './user/sidemenu-user/sidemenu-user.component';
import { HeaderUserComponent } from './user/header-user/header-user.component';
import { AdminHelpComponent } from './user/admin-help/admin-help.component';
import { StudentCountComponent } from './user/student-count/student-count.component';
import { ResetPasswordComponent } from './user/reset-password/reset-password.component';
import { RegistrationFlyerComponent } from './user/registration-flyer/registration-flyer.component';
import { TeacherNotesComponent } from './user/teacher-notes/teacher-notes.component';
///admin pages starts
import { AdminSidebarComponent } from './admin/includes/admin-sidebar/admin-sidebar.component';
import { AdminHeaderComponent } from './admin/includes/admin-header/admin-header.component';
import { AdminConfigurationComponent } from './admin/admin-configuration/admin-configuration.component';
import { AdminRegisterStudentComponent } from './admin/admin-register-student/admin-register-student.component';
import { AdminMergeComponent } from './admin/admin-merge/admin-merge.component';
import { AdminSupportsComponent } from './admin/admin-supports/admin-supports.component';
import { AdminAluminiRecordsComponent } from './admin/admin-alumini-records/admin-alumini-records.component';
import { AdminSetupComponent } from './admin/admin-setup/admin-setup.component';
import { AdminAddeditUserprofileComponent } from './admin/admin-addedit-userprofile/admin-addedit-userprofile.component';
import { AdminAddeditLettergradeComponent } from './admin/admin-addedit-lettergrade/admin-addedit-lettergrade.component';
import { AdminAddeditSchoolcourseComponent } from './admin/admin-addedit-schoolcourse/admin-addedit-schoolcourse.component';
import { AdminAddeditSchoolnameComponent } from './admin/admin-addedit-schoolname/admin-addedit-schoolname.component';
import { AdminAddeditProgrammoduleComponent } from './admin/admin-addedit-programmodule/admin-addedit-programmodule.component';
import { AdminAddeditTeacherassignmentComponent } from './admin/admin-addedit-teacherassignment/admin-addedit-teacherassignment.component';
import { AdminUserinfoUsersubscriptionComponent } from './admin/admin-userinfo-usersubscription/admin-userinfo-usersubscription.component';
import { AdminUserinfoUserprofileComponent } from './admin/admin-userinfo-userprofile/admin-userinfo-userprofile.component';
import { AdminOldregistrationRecordsComponent } from './admin/admin-oldregistration-records/admin-oldregistration-records.component';
import { AdminAllregistrationRecordsComponent } from './admin/admin-allregistration-records/admin-allregistration-records.component';
import { AdminAluminiinfoComponent } from './admin/admin-aluminiinfo/admin-aluminiinfo.component';
import { AdminTeacherassignmentComponent } from './admin/admin-teacherassignment/admin-teacherassignment.component';
import { AdminSchoolinfoLettergradeComponent } from './admin/admin-schoolinfo-lettergrade/admin-schoolinfo-lettergrade.component';
import { AdminSchoolinfoSchoolcourseComponent } from './admin/admin-schoolinfo-schoolcourse/admin-schoolinfo-schoolcourse.component';
import { AdminSchoolinfoSchoolnamesComponent } from './admin/admin-schoolinfo-schoolnames/admin-schoolinfo-schoolnames.component';
import { AdminSchoolinfoChisemodulesComponent } from './admin/admin-schoolinfo-chisemodules/admin-schoolinfo-chisemodules.component';
import { AdminSchoolinfoChiseParticipationComponent } from './admin/admin-schoolinfo-chise-participation/admin-schoolinfo-chise-participation.component';
import { ContactEmailComponent } from './admin/contact-email/contact-email.component';
import { ContactNumberComponent } from './admin/contact-number/contact-number.component';
import { ContactAdressComponent } from './admin/contact-adress/contact-adress.component';
import { AlumniOverviewComponent } from './admin/alumni-overview/alumni-overview.component';
import { StudentCertificatesComponent } from './admin/student-certificates/student-certificates.component';
import { TeacherCertificatesComponent } from './admin/teacher-certificates/teacher-certificates.component';

import { AdminChiseStatusComponent } from './admin/admin-chise-status/admin-chise-status.component';
///teacher pages starts
import { TeacherHeaderComponent } from './teacher/teacher-header/teacher-header.component';
import { TeacherSidemenuComponent } from './teacher/teacher-sidemenu/teacher-sidemenu.component';
import { StudentAttendenceLevelComponent } from './teacher/student-attendence-level/student-attendence-level.component';
import { TeacherAwardsComponent } from './teacher/teacher-awards/teacher-awards.component';
import { StudentAwardsComponent } from './teacher/student-awards/student-awards.component';
import { AwardStudentCertificateComponent } from './teacher/award-student-certificate/award-student-certificate.component';
import { TrackAssignmentComponent } from './teacher/track-assignment/track-assignment.component';
import { RollCallComponent } from './teacher/roll-call/roll-call.component';
import { UnsubscribeComponent } from './user/unsubscribe/unsubscribe.component';
import { FinishPageComponent } from './user/finish-page/finish-page.component';
import { AwardCertificateComponent } from './admin/award-certificate/award-certificate.component';
import { CertificateTeacherComponent } from './admin/certificate-teacher/certificate-teacher.component';
import { CertificateStudentComponent } from './admin/certificate-student/certificate-student.component';
import { AdminEditOldregistrationComponent } from './admin/admin-edit-oldregistration/admin-edit-oldregistration.component';
import { AdminRollCallComponent } from './admin/admin-roll-call/admin-roll-call.component';
import { FooterTermConditionComponent } from './common/footer-term-condition/footer-term-condition.component';
import { ContactUsComponent } from './common/contact-us/contact-us.component';
import { FeedbackComponent } from './common/feedback/feedback.component';
import { FaqComponent } from './common/faq/faq.component';
import { AdminSupportExecutiveComponent } from './admin/admin-support-executive/admin-support-executive.component';
import { RegistrationflyerComponent } from './teacher/registrationflyer/registrationflyer.component';
import { AddLetterGradeComponent } from './admin/add-letter-grade/add-letter-grade.component';
import { QuestionsComponent } from './common/questions/questions.component';
import { VideoTrainingComponent } from './common/video-training/video-training.component';
import { QuestionStudentPortalComponent } from './common/question-student-portal/question-student-portal.component';
import { TestComponent } from './admin/test/test.component';
import { AdminProgramConfigComponent } from './admin/admin-program-config/admin-program-config.component';

import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { TestTableComponent } from './admin/test-table/test-table.component';
import { AdminProgramReviewComponent } from './admin/admin-program-review/admin-program-review.component';
import { AdminRegistrationFlyerComponent } from './admin/admin-registration-flyer/admin-registration-flyer.component';

import { CKEditorModule } from '@ckeditor/ckeditor5-angular';


import { ExecDataAnalyticsComponent } from './admin/exec-data-analytics/exec-data-analytics.component';
import { TotalRegistrationComponent } from './admin/total-registration/total-registration.component';
import { ChatComponent } from './common/chat/chat.component';
import { SettingsComponent } from './common/settings/settings.component';
import { ExecDatasheetComponent } from './admin/exec-datasheet/exec-datasheet.component';
import { YourContributionsComponent } from './alumni/your-contributions/your-contributions.component';
import { MyProfileComponent } from './alumni/my-profile/my-profile.component';
import { YourParticipationComponent } from './alumni/your-participation/your-participation.component';
import { YourEmploymentHistoryComponent } from './alumni/your-employment-history/your-employment-history.component';
import { ChiseEventsComponent } from './alumni/chise-events/chise-events.component';
import { StudentInternshipComponent } from './alumni/student-internship/student-internship.component';
import { FundraisersComponent } from './alumni/fundraisers/fundraisers.component';
import { DidUDonateComponent } from './alumni/did-u-donate/did-u-donate.component';
import { SurveyComponent } from './common/survey/survey.component';
import { AlumniContributionComponent } from './admin/alumni-contribution/alumni-contribution.component';
import { AddFundraisersComponent } from './admin/add-fundraisers/add-fundraisers.component';
import { AddServicesComponent } from './admin/add-services/add-services.component';
import { StudentInternshipsComponent } from './admin/student-internships/student-internships.component';
import { AddEventsComponent } from './admin/add-events/add-events.component';
import { AddInternshipComponent } from './alumni/add-internship/add-internship.component';
import { AddEmploymentHistoryComponent } from './admin/add-employment-history/add-employment-history.component';
import { NotificationsComponent } from './common/notifications/notifications.component';
import { NewMergedRegistrationRecordsComponent } from './admin/new-merged-registration-records/new-merged-registration-records.component';
import { AdminAlumniinfoDetailsComponent } from './admin/admin-alumniinfo-details/admin-alumniinfo-details.component';
import { AdminSchoolinfoLettergradeDetailsComponent } from './admin/admin-schoolinfo-lettergrade-details/admin-schoolinfo-lettergrade-details.component';
import { EmploymentHistoryListComponent } from './admin/employment-history-list/employment-history-list.component';
import { AlumniDonationComponent } from './admin/alumni-donation/alumni-donation.component';
import { EditAllRegistrationComponent } from './admin/edit-all-registration/edit-all-registration.component';
import { ListEventsComponent } from './admin/list-events/list-events.component';
import { ListFundraiserComponent } from './admin/list-fundraiser/list-fundraiser.component';
import { ListSurveyComponent } from './admin/list-survey/list-survey.component';
import { MathCourseComponent } from './admin/math-course/math-course.component';
import { ScienceCourseComponent } from './admin/science-course/science-course.component';
import { CsCourseComponent } from './admin/cs-course/cs-course.component';
import { SummaryTableComponent } from './admin/summary-table/summary-table.component';
import { ListLetterGradesComponent } from './admin/list-letter-grades/list-letter-grades.component';
import { SchoolSectionsComponent } from './admin/school-sections/school-sections.component';
import { AddEditSchoolSectionsComponent } from './admin/add-edit-school-sections/add-edit-school-sections.component';
import { FlyerViewComponent } from './common/flyer-view/flyer-view.component';
import { SectionAssignmentComponent } from './admin/section-assignment/section-assignment.component';
import { EditSectionAssignmentComponent } from './admin/edit-section-assignment/edit-section-assignment.component';
import { TrackConfigurationComponent } from './admin/track-configuration/track-configuration.component';
import { AddSessionsComponent } from './admin/add-sessions/add-sessions.component';

@NgModule({
  declarations: [
    AppComponent,
    StartComponent,
    SubscribeComponent,
    LoginComponent,
    FooterComponent,
    TermsConditionComponent,
    ForgotPasswordComponent,
    ReviewProfileComponent,
    UserProfileComponent,
    RegisterStudentComponent,
    RegistrationRecordsComponent,
    OldRegistrationRecordComponent,
    StudentCertificateComponent,
    AdminSupportComponent,
    MessagesComponent,
    SidemenuUserComponent,
    HeaderUserComponent,
    ForgotSuccessComponent,
    AdminHelpComponent,
    StudentCountComponent,
    ResetPasswordComponent,

    AdminSidebarComponent,
    AdminSidebarComponent,
    AdminHeaderComponent,
    AdminConfigurationComponent,
    AdminRegisterStudentComponent,
    AdminMergeComponent,
    AdminSupportsComponent,
    AdminAluminiRecordsComponent,
    AdminSetupComponent,
    AdminAddeditUserprofileComponent,
    AdminAddeditLettergradeComponent,
    AdminAddeditSchoolcourseComponent,
    AdminAddeditSchoolnameComponent,
    AdminAddeditProgrammoduleComponent,
    AdminAddeditTeacherassignmentComponent,
    AdminUserinfoUsersubscriptionComponent,
    AdminUserinfoUserprofileComponent,
    AdminOldregistrationRecordsComponent,
    AdminAllregistrationRecordsComponent,
    AdminAluminiinfoComponent,
    AdminTeacherassignmentComponent,
    AdminSchoolinfoLettergradeComponent,
    AdminSchoolinfoSchoolcourseComponent,
    AdminSchoolinfoSchoolnamesComponent,
    AdminSchoolinfoChisemodulesComponent,
    TeacherHeaderComponent,
    TeacherSidemenuComponent,
    StudentAttendenceLevelComponent,
    TeacherAwardsComponent,
    StudentAwardsComponent,
    AwardStudentCertificateComponent,
    TrackAssignmentComponent,
    RollCallComponent,
    AdminSchoolinfoChiseParticipationComponent,
    ContactEmailComponent,
    ContactNumberComponent,
    ContactAdressComponent,
    CommingSoonComponent,
    AlumniOverviewComponent,
    RegistrationFlyerComponent,
    TeacherNotesComponent,
    StudentCertificatesComponent,
    TeacherCertificatesComponent,
    UnsubscribeComponent,
    FinishPageComponent,
    AwardCertificateComponent,
    CertificateTeacherComponent,
    CertificateStudentComponent,
    AdminChiseStatusComponent,
    AdminEditOldregistrationComponent,
    AdminRollCallComponent,
    FooterTermConditionComponent,
    ContactUsComponent,
    FeedbackComponent,
    FaqComponent,
    AdminSupportExecutiveComponent,
    RegistrationflyerComponent,
    AddLetterGradeComponent,
    QuestionsComponent,
    VideoTrainingComponent,
    QuestionStudentPortalComponent,
    TestComponent,
    TestTableComponent,
    AdminProgramConfigComponent,
    AdminProgramReviewComponent,
    AdminRegistrationFlyerComponent,
    ExecDataAnalyticsComponent,
    TotalRegistrationComponent,
    ChatComponent,
    SettingsComponent,
    ExecDatasheetComponent,
    YourContributionsComponent,
    MyProfileComponent,
    YourParticipationComponent,
    YourEmploymentHistoryComponent,
    ChiseEventsComponent,
    StudentInternshipComponent,
    FundraisersComponent,
    DidUDonateComponent,
    SurveyComponent,
    AlumniContributionComponent,
    AddFundraisersComponent,
    AddServicesComponent,
    StudentInternshipsComponent,
    AddEventsComponent,
    AddInternshipComponent,
    AddEmploymentHistoryComponent,
    NotificationsComponent,
    NewMergedRegistrationRecordsComponent,
    AdminAlumniinfoDetailsComponent,
    AdminSchoolinfoLettergradeDetailsComponent,
    EmploymentHistoryListComponent,
    AlumniDonationComponent,
    EditAllRegistrationComponent,
    ListEventsComponent,
    ListFundraiserComponent,
    ListSurveyComponent,
    MathCourseComponent,
    ScienceCourseComponent,
    CsCourseComponent,
    SummaryTableComponent,
    ListLetterGradesComponent,
    SchoolSectionsComponent,
    AddEditSchoolSectionsComponent,
    FlyerViewComponent,
    SectionAssignmentComponent,
    EditSectionAssignmentComponent,
    TrackConfigurationComponent,
    AddSessionsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    JwPaginationModule,
    NgMultiSelectDropDownModule.forRoot(),
    CKEditorModule,
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }

