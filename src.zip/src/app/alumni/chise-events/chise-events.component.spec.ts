import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChiseEventsComponent } from './chise-events.component';

describe('ChiseEventsComponent', () => {
  let component: ChiseEventsComponent;
  let fixture: ComponentFixture<ChiseEventsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChiseEventsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChiseEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
