import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-chise-events',
  templateUrl: './chise-events.component.html',
  styleUrls: ['./chise-events.component.css']
})
export class ChiseEventsComponent implements OnInit {
  url = this.api.geturl();
  UserData: any;
  events_list: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
 
  }
  ngOnInit(): void {
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    this.getevents();
   
if ((this.UserData.class == 'guardian 1') || (this.UserData.class == 'alumnus') || (this.UserData.class == 'guardian 2') || (this.UserData.class == 'student 2')) {
  $('.admins').css('display', 'none');
  $('#dropdownMenu121').addClass('active');
}
if ((this.UserData.class == "admin") || (this.UserData.class == "executive 2") || (this.UserData.class == "executive 1") || (this.UserData.class == "teacher")) {
  $('.users').css('display', 'none');    
   $('#dropdownMenu1211').addClass('active');   
}
  }
  getevents(){
    var type={
      user_id:'',
      sender:0
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_events`,type).subscribe(data => {
      $('.pageloader').hide();
      this.events_list=data.events;
      $('#card1').addClass('selected');
    }, err => {
      $('.pageloader').hide();
    });
  }
  openTab(tabName) {
    var id=tabName;
    tabName='div'+tabName;
    // alert(tabName)
    $('.events-card').removeClass('selected');
    var i, x;
    x = document.getElementsByClassName("containerTab");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
     
    }
    document.getElementById(tabName).style.display = "block";
    $('#card'+id).addClass('selected');
  }
}
