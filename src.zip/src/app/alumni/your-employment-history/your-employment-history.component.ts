import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-your-employment-history',
  templateUrl: './your-employment-history.component.html',
  styleUrls: ['./your-employment-history.component.css']
})
export class YourEmploymentHistoryComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  subscriptionList: any = [];
  items = [];
  exe: any;
  pageOfItems: Array<any>;
  year: any;
  alumni: any;
  cumulative=0;
  chise_event = false;
  alumni_name = false;
  company_name = false;
  years=false;
  error = false;
  form: FormGroup;//initializing form
  chise_events: any;
  salary = false;
  employment_list: any = [];
  logdata: any;
  constructor(private api: ApiService, private http: HttpClient, private router: Router, private fb: FormBuilder,) {
    
  }
  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    this.getData();
    $('#dropdownMenu1').addClass('active');
  }
  //setting value of filter
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
  
 search(){
   var searchval=$('#value').val();
   if(searchval=='')
   {
     var search=0;
     $('#ff').html('Filter Unselected');
   }
   else
   var search=1;
   var user_id = {
     user_id : this.logdata.user_id,
     group_id : this.logdata.family_code,
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
     merged_stat:0
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_employment_history`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.employment_list=data.employment_list;
     $('#showcount').html(data.employment_list.length);
   }, err => {
     $('.pageloader').hide();
   })
 }
  getData(){
    var userid = {
      user_id:this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_employment_history`, userid).subscribe(data => {
      $('.pageloader').hide();
     this.employment_list=data.employment_list;
     $('#showcount').html(data.employment_list.length);
     this.cumulative=data.employment_list.length;
    }, err => {
      $('.pageloader').hide();
    })
  }


  //exporting the selected data as csv
  export_data() {
    var selected_array=['year','company_name', 'salary'];
    var header_array=[ 'Year','Company','Salary'];
   this.api.downloadFile(this.employment_list,selected_array,header_array, 'Track Assigned To Me');
}
}
