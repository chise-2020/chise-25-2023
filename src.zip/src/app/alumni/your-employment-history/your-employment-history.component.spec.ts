import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YourEmploymentHistoryComponent } from './your-employment-history.component';

describe('YourEmploymentHistoryComponent', () => {
  let component: YourEmploymentHistoryComponent;
  let fixture: ComponentFixture<YourEmploymentHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YourEmploymentHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YourEmploymentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
