import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-your-contributions',
  templateUrl: './your-contributions.component.html',
  styleUrls: ['./your-contributions.component.css']
})
export class YourContributionsComponent implements OnInit {
  url = this.api.geturl();
  UserData: any;
  cumulative=0;
  intern_list: any = [];
  contributed_list: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {

  }
  ngOnInit(): void {
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    this.getData();
      $('#dropdownMenu1').addClass('active');
  }
  //setting value of filter
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
  
 search(){
   var searchval=$('#value').val();
   if(searchval=='')
   {
     var search=0;
     $('#ff').html('Filter Unselected');
   }
   else
   var search=1;
   var user_id = {
     user_id : this.UserData.user_id,
     group_id : this.UserData.family_code,
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
     merged_stat:0
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_alumni_contributions`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.contributed_list = data.contri_list;
     $('#showcount').html(data.total_sum)
     $('#showcount1').html(data.contri_list.length)
     
   }, err => {
     $('.pageloader').hide();
   })
 }
  getData() {
    var userid = {
      user_id: this.UserData.user_id,
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_alumni_contributions`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.contributed_list = data.contri_list;
      $('#showcount').html(data.total_sum)
      $('#showcount1').html(data.contri_list.length)
      this.cumulative=data.contri_list.length;
    }, err => {
      $('.pageloader').hide();
    })
  }
  //exporting the selected data as csv
  export_data() {
    var selected_array=['year','event_name', 'contributed_amt'];
    var header_array=['Year', 'Event Name','$$'];
   this.api.downloadFile(this.contributed_list,selected_array,header_array, 'Your Chise Contributions');
}
//
}
