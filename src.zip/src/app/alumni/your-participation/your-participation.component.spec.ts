import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YourParticipationComponent } from './your-participation.component';

describe('YourParticipationComponent', () => {
  let component: YourParticipationComponent;
  let fixture: ComponentFixture<YourParticipationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YourParticipationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YourParticipationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
