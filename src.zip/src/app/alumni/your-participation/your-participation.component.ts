import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-your-participation',
  templateUrl: './your-participation.component.html',
  styleUrls: ['./your-participation.component.css']
})
export class YourParticipationComponent implements OnInit {
  url = this.api.geturl();
  UserData: any;
  intern_list: any = [];
  contributed_list: any;
  data: any =[]; 
  cumulative=0;
  studentsList: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {

  }
  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData')); //forgot to close
    this.get_record();
    $('#dropdownMenu1').addClass('active');
  }
  //setting value of filter
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
  
 search(){
   var searchval=$('#value').val();
   if(searchval=='')
   {
     var search=0;
     $('#ff').html('Filter Unselected');
   }
   else
   var search=1;
   var user_id = {
     user_id : this.data.user_id,
     group_id : this.data.family_code,
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
     merged_stat:0
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_alumni_participation`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.studentsList = data.user
     $('#showcount1').html(data.user.length);
    $('#showcount').html(data.count);
   }, err => {
     $('.pageloader').hide();
   })
 }
 


 get_record(){
   var user_id = {
     user_id : this.data.user_id,
     group_id : '',
     type : '',
     search : 0,
     value : '',
     merged_stat:0
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_alumni_participation`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.studentsList = data.user;
     this.cumulative=data.user.length;
     $('#showcount1').html(data.user.length);
        $('#showcount').html(data.count);
   }, err => {
     $('.pageloader').hide();
   })
 }

   //exporting the selected data as csv
   export_data() {
    var selected_array=['program_name','academic_term', 'academic_year','school_name','grade'];
    var header_array=['ChiS&E Track','Term','Year','School','Grade'];
   this.api.downloadFile(this.studentsList,selected_array,header_array, 'Your Chise Participation');
}
}
