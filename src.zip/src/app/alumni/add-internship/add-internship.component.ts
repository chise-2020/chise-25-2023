import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
@Component({
  selector: 'app-add-internship',
  templateUrl: './add-internship.component.html',
  styleUrls: ['./add-internship.component.css']
})
export class AddInternshipComponent implements OnInit {
  url = this.api.geturl();
  public Editor = ClassicEditor;
  public sourceData: string;
  form: FormGroup;//initializing form
  UserData: any;
  title=false;
  phone_number=false;
  start_date=false;
  email=false;
  details=false;
  place=false;
  end_date=false;
  error= false;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }
  ngOnInit(): void {
    this.sourceData = '';
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('.form-control').on('change', function () {
      $(this).removeClass("error");
    });
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    if ((this.UserData.class == 'guardian 1') || (this.UserData.class == 'alumnus') || (this.UserData.class == 'guardian 2') || (this.UserData.class == 'student 2')) {
      $('.admins').css('display', 'none');
    }
    if ((this.UserData.class == "admin") || (this.UserData.class == "executive 2") || (this.UserData.class == "executive 1") || (this.UserData.class == "teacher")) {
      $('.users').css('display', 'none');       
    }
    if((this.UserData.class == 'alumnus') ){
      $('#guardian').css('display', 'none'); 
      $('#teacher').css('display', 'none'); 
    }
    if((this.UserData.class == 'guardian 1')  || (this.UserData.class == 'guardian 2') || (this.UserData.class == 'student 2') ){
      $('#admin').css('display', 'none'); 
    }
    if((this.UserData.class == 'alumnus') ){
      $('#dropdownMenu121').addClass('active');
      }
      if((this.UserData.class == 'admin') ){
      $('#dropdownMenu29').addClass('active');
      }
    this.form.get('user_id').setValue(this.UserData.user_id);
  }
 //creating form
 createForm() {
  this.form = this.fb.group({
    title: new FormControl('', [Validators.required,]),
    phone_number: new FormControl('', [Validators.required,]),
    place: new FormControl('', [Validators.required,]),
    email: new FormControl('', [Validators.required,]),
    start_date: new FormControl('', [Validators.required,]),
    details: new FormControl('', [Validators.required,]),
    user_id: new FormControl('', [Validators.required,]),
    end_date: new FormControl('', [Validators.required,]),
  });
}
//
submit(){
  // alert('id');
  if (!($('#title').val())) {
    $('#title').addClass('error');
    this.error = true;
  } else {
    $('#title').removeClass('error');
    this.error = false;
  }
   if (!($('#phone_number').val())) {
    $('#phone_number').addClass('error');
    this.error = true;
  } else {
    $('#phone_number').removeClass('error');
    this.error = false;
  }
  if (!($('#place').val())) {
    $('#place').addClass('error');
    this.error = true;
  } else {
    $('#place').removeClass('error');
    this.error = false;
  }
  if (!($('#start_date').val())) {
    $('#start_date').addClass('error');
    this.error = true;
  } else {
    $('#start_date').removeClass('error');
    this.error = false;
  }
  if (!($('#email').val())) {
    $('#email').addClass('error');
    this.error = true;
  } else {
    $('#email').removeClass('error');
    this.error = false;
  }
  if (!($('#details').val())) {
    $('#details').addClass('error');
    this.error = true;
  } else {
    $('#details').removeClass('error');
    this.error = false;
  }
  if (!($('#end_date').val())) {
    $('#end_date').addClass('error');
    this.error = true;
  } else {
    $('#end_date').removeClass('error');
    this.error = false;
  }
    if (this.error == false) {
     
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/add_internship`,this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          //this.oldPassword= true
          $('#new-pop').trigger('click');
          $('#new_pop_text').html('<img src="assets/images/block.svg">Student Internship ');
          $('#new_pop_html').html(data.message);
          this.form.reset();
        }
        else if (data.status == true) {
          $('#ok').css('display','none');
           if((this.UserData.class == 'alumnus') ){
          $('#redirect_ok').css('display','block');
           }
           if((this.UserData.class == 'admin') ){
            $('#redirect_ok2').css('display','block');
           }
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">Student Internship ');
          $('#errortext').html(data.message);
          this.form.reset();
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}
changes(){
      //guardian validation
      var inputVal = ($('#phone_number').val());
      // $('#phone' + id).replace(/[^0-9\.]/g,'');
      var regExp = /[a-zA-Z]/g;
      if (regExp.test(inputVal)) {
        //letters found
        $('#phone_number').addClass('error');
        this.error = true;
      } else {
        $('#phone_number').removeClass('error');
        this.error = false;
      }
  
      $('#phone_number').val($('#phone_number').val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));
  
  
}
}
