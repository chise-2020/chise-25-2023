import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  logdata: any;
  newPassword = false;
  oldPassword = false;
  confirmPassword = false;
  email=false;
  phone=false;
  address=false;
  city=false;
  state=false;
  zip_code=false;
  PasswordForm: FormGroup;
  form:FormGroup;
  url = this.api.geturl();
  UserData: any;
  error=false;
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {
    this.createPasswordForm();
    this.createForm();
  }

  ngOnInit(): void {
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('.form-control').on('change', function () {
      $(this).removeClass("error");
    });
    // localStorage.setItem("add_click", JSON.stringify('0')); 
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    // console.log(this.logdata.user_id)
    this.getProfile();
    $(document).on('click', '.toggle-password', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input = $("#oldPassword");
      input.attr('type') === 'password' ? input.attr('type', 'text') : input.attr('type', 'password')

    });

    $(document).on('click', '.togglepassword', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input1 = $("#newPassword");
      input1.attr('type') === 'password' ? input1.attr('type', 'text') : input1.attr('type', 'password')
    });

    $(document).on('click', '.togglepasswords', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input2 = $("#confirmPassword");
      input2.attr('type') === 'password' ? input2.attr('type', 'text') : input2.attr('type', 'password')
    });
  }
  view_btn() {
    $('#yesbutton').css('display', 'none');
    $('#nobutton').css('display', 'none');
  }
  createForm() {
    this.form = this.fb.group({
      user_id: new FormControl(),
      email: new FormControl('', [Validators.required,]),
      phone: new FormControl('', [Validators.required,]),
      planned_major: new FormControl('', [Validators.required,]),
      collage_name: new FormControl('', [Validators.required,]),
      yo_hs_graduation: new FormControl('', [Validators.required,]),
      yo_graduation: new FormControl('', [Validators.required,]),
      collage_minor: new FormControl('', [Validators.required,]),
      city: new FormControl('', [Validators.required,]),
      state: new FormControl('', [Validators.required,]),
      zip_code: new FormControl('', [Validators.required,]),
      address: new FormControl('', [Validators.required,]),
      minor:new FormControl('', [Validators.required,]),
    });
  }
  createPasswordForm() {
    this.PasswordForm = this.fb.group({
      oldPassword: new FormControl('', [Validators.required,]),
      newPassword: new FormControl('', [Validators.required,]),
      confirmPassword: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
    });
  }
  passwordSubmit() {
    var number = /([0-9])/;
    var alphabets = /([a-zA-Z])/;
    var special_characters = /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/;
    this.oldPassword = this.newPassword = this.confirmPassword = false;
    if (this.PasswordForm.getRawValue().oldPassword == '')
      this.oldPassword = true
    if (this.PasswordForm.getRawValue().newPassword == '')
      this.newPassword = true
    if (this.PasswordForm.getRawValue().confirmPassword == '')
      this.confirmPassword = true

    if (this.oldPassword == false && this.newPassword == false && this.confirmPassword == false) {
      if (this.PasswordForm.getRawValue().newPassword.length < 8) {
        this.newPassword = true
        $('#pass_pop').trigger('click');
        $('#new-pop').trigger('click');
        $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
        $('#new_pop_html').html('Password should be atleast 8 characters.')
        return;
      }
      if (this.PasswordForm.getRawValue().newPassword != this.PasswordForm.getRawValue().confirmPassword) {
        this.confirmPassword = true
        $('#pass_pop').trigger('click');
        $('#new-pop').trigger('click');
        $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
        $('#new_pop_html').html('Password mismatch.');
        return;
      }
      // if (this.PasswordForm.getRawValue().newPassword.match(/[a-z]/g) && this.PasswordForm.getRawValue().newPassword.match(/[A-Z]/g) && this.PasswordForm.getRawValue().newPasswordtr.match(/[0-9]/g) && this.PasswordForm.getRawValue().newPassword.match(/[^a-zA-Z\d]/g) && this.PasswordForm.getRawValue().newPassword.length >= 8) {
        var pwd = {
          oldpass: this.PasswordForm.value.oldPassword,
          newpass: this.PasswordForm.value.newPassword,
          user_id: this.logdata.user_id
        }
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/changepassword`, pwd).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            //this.oldPassword= true
            $('#pass_pop').trigger('click');
            $('#new-pop').trigger('click');
            $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
            $('#new_pop_html').html(data.message);
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg"> Password ');
            $('#errortext').html(data.message);
          }
        }, err => {
          $('.pageloader').hide();
        })
      // } else {
      //   this.newPassword = true
      //   $('#pass_pop').trigger('click');
      //   $('#new-pop').trigger('click');
      //   $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
      //   $('#new_pop_html').html('Password must must contain at least one number and one uppercase and lowercase letter,and one special character and at least 8 or more characters');
      //   $('#new_pop_html').css('line-height', '40px');
      //   $('#new_pop_html').css('font-size', ' 19px');
      //   return;
      // }

    }

  }
  test_str() {
    var str = $('#newPassword').val();
    if (str.match(/[a-z]/g) && str.match(/[A-Z]/g) && str.match(/[0-9]/g) && str.match(/[^a-zA-Z\d]/g) && str.length >= 8) {
      $('#newPassword').removeClass('error');
      $('#error_title').html('');
     }
    else {
      $('#newPassword').addClass('error');
      $('#error_title').html('( Password must must contain at least one number and one uppercase and lowercase letter,and one special character and at least 8 or at most 12 characters )')
   
    }
  }
  getProfile(){
    // console.log()
    var type={
      user_id:this.logdata.user_id
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_profile`,type).subscribe(data => {
      $('.pageloader').hide();
      this.form.get('user_id').setValue(this.logdata.user_id);
      this.form.get('email').setValue(data.profile_details.email);
      this.form.get('phone').setValue(data.profile_details.phone);
      this.form.get('address').setValue(data.profile_details.street);
      this.form.get('city').setValue(data.profile_details.city);
      this.form.get('state').setValue(data.profile_details.state);
      this.form.get('zip_code').setValue(data.profile_details.zip_code);
      this.form.get('yo_hs_graduation').setValue(data.profile_details.yo_hs_graduation);
      this.form.get('collage_name').setValue(data.profile_details.collage_name);
      this.form.get('planned_major').setValue(data.profile_details.planned_major);
      this.form.get('minor').setValue(data.profile_details.minor);
    }, err => {
      $('.pageloader').hide();
    });
  }
  submit(){
    // if (!($('#address').val())) {
    //   $('#address').addClass('error');
    //   this.error = true;
    //   this.address=true;
    // } else {
    //   $('#address').removeClass('error');
    //   this.error = false;
    //   this.address=false;
    // }
    //  if (!($('#zip_code').val())) {
    //   $('#zip_code').addClass('error');
    //   this.error = true;
    //   this.zip_code=true;
    // } else {
    //   $('#zip_code').removeClass('error');
    //   this.error = false;
    //   this.zip_code=false;
    // }
    if (!($('#phone').val())) {
      $('#phone').addClass('error');
      this.error = true;
      this.phone=true;
    } else {
      $('#phone').removeClass('error');
      this.error = false;
      this.phone=false;
    }
    // if (!($('#state').val())) {
    //   $('#state').addClass('error');
    //   this.error = true;
    //   this.state=true;
    // } else {
    //   $('#state').removeClass('error');
    //   this.error = false;
    //   this.state=false;
    // }
    if (!($('#email').val())) {
      $('#email').addClass('error');
      this.error = true;
      this.email=true;
    } else {
      $('#email').removeClass('error');
      this.error = false;
      this.error=false;
    }
    // if (!($('#city').val())) {
    //   $('#city').addClass('error');
    //   this.error = true;
    //   this.city=true;
    // } else {
    //   $('#city').removeClass('error');
    //   this.error = false;
    //   this.city=false;
    // }
      if ((this.email == false) ||  (this.phone == false) ) {
       
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/edit_profile`,this.form.value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            //this.oldPassword= true
            $('#new-pop').trigger('click');
            $('#new_pop_text').html('<img src="assets/images/block.svg">My Profile');
            $('#new_pop_html').html(data.message);
            this.form.reset();
          }
          else if (data.status == true) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">My Profile');
            $('#errortext').html(data.message);
            this.form.reset();
          }
        }, err => {
          $('.pageloader').hide();
        }
        )
      }
  }
  changes(){
    //guardian validation
    var inputVal = ($('#phone').val());
    // $('#phone' + id).replace(/[^0-9\.]/g,'');
    var regExp = /[a-zA-Z]/g;
    if (regExp.test(inputVal)) {
      //letters found
      $('#phone').addClass('error');
      this.error = true;
    } else {
      $('#phone').removeClass('error');
      this.error = false;
    }

    $('#phone').val($('#phone').val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));


}
}
