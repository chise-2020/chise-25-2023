import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DidUDonateComponent } from './did-u-donate.component';

describe('DidUDonateComponent', () => {
  let component: DidUDonateComponent;
  let fixture: ComponentFixture<DidUDonateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DidUDonateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DidUDonateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
