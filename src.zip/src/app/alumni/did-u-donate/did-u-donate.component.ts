import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-did-u-donate',
  templateUrl: './did-u-donate.component.html',
  styleUrls: ['./did-u-donate.component.css']
})
export class DidUDonateComponent implements OnInit {
  url = this.api.geturl();
  UserData: any;
  events_list: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
 
  }
  ngOnInit(): void {
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    this.getevents();
    if ((this.UserData.class == 'guardian 1') || (this.UserData.class == 'alumnus') || (this.UserData.class == 'guardian 2') || (this.UserData.class == 'student 2')) {
      $('.admins').css('display', 'none');
    }
    if ((this.UserData.class == "admin") || (this.UserData.class == "executive 2") || (this.UserData.class == "executive 1") || (this.UserData.class == "teacher")) {
      $('.users').css('display', 'none');    
      $('#dropdownMenu1211').addClass('active');      
    }
   
  }
  getevents(){
    var type={
      user_id: this.UserData.user_id,
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/did_u_donate`,type).subscribe(data => {
      $('.pageloader').hide();
      this.events_list=data.events;
      // $('#card1').addClass('selected');
    }, err => {
      $('.pageloader').hide();
    });
  }
}
