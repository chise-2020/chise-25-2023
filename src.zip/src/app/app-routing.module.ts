
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


//common user pages starts here
import { StartComponent } from './common/start/start.component';
import { SubscribeComponent } from './common/subscribe/subscribe.component';
import { LoginComponent } from './common/login/login.component';
import { TermsConditionComponent } from './common/terms-condition/terms-condition.component';
import { ForgotPasswordComponent } from './common/forgot-password/forgot-password.component';
import { ForgotSuccessComponent } from './common/forgot-success/forgot-success.component';
import { CommingSoonComponent } from './common/comming-soon/comming-soon.component';
import { FooterTermConditionComponent } from './common/footer-term-condition/footer-term-condition.component';
import { QuestionsComponent } from './common/questions/questions.component';
///user pages starts
import { ReviewProfileComponent } from './user/review-profile/review-profile.component';
import { UserProfileComponent } from './user/user-profile/user-profile.component';
import { RegisterStudentComponent } from './user/register-student/register-student.component';
import { RegistrationRecordsComponent } from './user/registration-records/registration-records.component';
import { OldRegistrationRecordComponent } from './user/old-registration-record/old-registration-record.component';
import { StudentCertificateComponent } from './user/student-certificate/student-certificate.component';
import { AdminSupportComponent } from './user/admin-support/admin-support.component';
import { MessagesComponent } from './user/messages/messages.component';
import { RegistrationFlyerComponent } from './user/registration-flyer/registration-flyer.component';
import { TeacherNotesComponent } from './user/teacher-notes/teacher-notes.component';

///admin pages starts
import { AdminSidebarComponent } from './admin/includes/admin-sidebar/admin-sidebar.component';
import { AdminConfigurationComponent } from './admin/admin-configuration/admin-configuration.component';
import { AdminRegisterStudentComponent } from './admin/admin-register-student/admin-register-student.component';
import { AdminMergeComponent } from './admin/admin-merge/admin-merge.component';
import { AdminSupportsComponent } from './admin/admin-supports/admin-supports.component';
import { AdminAluminiRecordsComponent } from './admin/admin-alumini-records/admin-alumini-records.component';
import { AdminSetupComponent } from './admin/admin-setup/admin-setup.component';
import { AdminAddeditUserprofileComponent } from './admin/admin-addedit-userprofile/admin-addedit-userprofile.component';
import { AdminAddeditLettergradeComponent } from './admin/admin-addedit-lettergrade/admin-addedit-lettergrade.component';
import { AdminAddeditSchoolcourseComponent } from './admin/admin-addedit-schoolcourse/admin-addedit-schoolcourse.component';
import { AdminAddeditSchoolnameComponent } from './admin/admin-addedit-schoolname/admin-addedit-schoolname.component';
import { AdminAddeditProgrammoduleComponent } from './admin/admin-addedit-programmodule/admin-addedit-programmodule.component';
import { AdminAddeditTeacherassignmentComponent } from './admin/admin-addedit-teacherassignment/admin-addedit-teacherassignment.component';
import { AdminUserinfoUsersubscriptionComponent } from './admin/admin-userinfo-usersubscription/admin-userinfo-usersubscription.component';
import { AdminUserinfoUserprofileComponent } from './admin/admin-userinfo-userprofile/admin-userinfo-userprofile.component';
import { AdminOldregistrationRecordsComponent } from './admin/admin-oldregistration-records/admin-oldregistration-records.component';
import { AdminAllregistrationRecordsComponent } from './admin/admin-allregistration-records/admin-allregistration-records.component';
import { AdminAluminiinfoComponent } from './admin/admin-aluminiinfo/admin-aluminiinfo.component';
import { AdminTeacherassignmentComponent } from './admin/admin-teacherassignment/admin-teacherassignment.component';
import { AdminSchoolinfoLettergradeComponent } from './admin/admin-schoolinfo-lettergrade/admin-schoolinfo-lettergrade.component';
import { AdminSchoolinfoSchoolcourseComponent } from './admin/admin-schoolinfo-schoolcourse/admin-schoolinfo-schoolcourse.component';
import { AdminSchoolinfoSchoolnamesComponent } from './admin/admin-schoolinfo-schoolnames/admin-schoolinfo-schoolnames.component';
import { AdminSchoolinfoChisemodulesComponent } from './admin/admin-schoolinfo-chisemodules/admin-schoolinfo-chisemodules.component';
import { AdminSchoolinfoChiseParticipationComponent } from './admin/admin-schoolinfo-chise-participation/admin-schoolinfo-chise-participation.component';
import { ContactEmailComponent } from './admin/contact-email/contact-email.component';
import { ContactNumberComponent } from './admin/contact-number/contact-number.component';
import { ContactAdressComponent } from './admin/contact-adress/contact-adress.component';
import { AlumniOverviewComponent } from './admin/alumni-overview/alumni-overview.component';
import { StudentCertificatesComponent } from './admin/student-certificates/student-certificates.component';
import { TeacherCertificatesComponent } from './admin/teacher-certificates/teacher-certificates.component';
import { AddLetterGradeComponent } from './admin/add-letter-grade/add-letter-grade.component';

//exec page start 
import { ExecDataAnalyticsComponent } from './admin/exec-data-analytics/exec-data-analytics.component';

///teacher pages starts
import { TeacherHeaderComponent } from './teacher/teacher-header/teacher-header.component';
import { TeacherSidemenuComponent } from './teacher/teacher-sidemenu/teacher-sidemenu.component';
import { StudentAttendenceLevelComponent } from './teacher/student-attendence-level/student-attendence-level.component';
import { TeacherAwardsComponent } from './teacher/teacher-awards/teacher-awards.component';
import { StudentAwardsComponent } from './teacher/student-awards/student-awards.component';
import { AwardStudentCertificateComponent } from './teacher/award-student-certificate/award-student-certificate.component';
import { TrackAssignmentComponent } from './teacher/track-assignment/track-assignment.component';
import { RollCallComponent } from './teacher/roll-call/roll-call.component';

import { UnsubscribeComponent } from './user/unsubscribe/unsubscribe.component';
import { FinishPageComponent } from './user/finish-page/finish-page.component';
import { AwardCertificateComponent } from './admin/award-certificate/award-certificate.component';
import { CertificateTeacherComponent } from './admin/certificate-teacher/certificate-teacher.component';
import { CertificateStudentComponent } from './admin/certificate-student/certificate-student.component';

import { AdminChiseStatusComponent } from './admin/admin-chise-status/admin-chise-status.component';
import { AdminEditOldregistrationComponent } from './admin/admin-edit-oldregistration/admin-edit-oldregistration.component';

import { AdminRollCallComponent } from './admin/admin-roll-call/admin-roll-call.component';

import { ContactUsComponent } from './common/contact-us/contact-us.component';
import { FeedbackComponent } from './common/feedback/feedback.component';
import { FaqComponent } from './common/faq/faq.component';
import { AdminSupportExecutiveComponent } from './admin/admin-support-executive/admin-support-executive.component';
import { RegistrationflyerComponent } from './teacher/registrationflyer/registrationflyer.component';
import { AdminProgramConfigComponent } from './admin/admin-program-config/admin-program-config.component';

import { TestComponent } from './admin/test/test.component';
import { TestTableComponent } from './admin/test-table/test-table.component';
import { TotalRegistrationComponent } from './admin/total-registration/total-registration.component';
import { ChatComponent } from './common/chat/chat.component';
import { SettingsComponent } from './common/settings/settings.component';
import { ExecDatasheetComponent } from './admin/exec-datasheet/exec-datasheet.component';
import { YourContributionsComponent } from './alumni/your-contributions/your-contributions.component';

import { AlumniContributionComponent } from './admin/alumni-contribution/alumni-contribution.component';
import { ChiseEventsComponent } from './alumni/chise-events/chise-events.component';
import { AddFundraisersComponent } from './admin/add-fundraisers/add-fundraisers.component';
import { AddServicesComponent } from './admin/add-services/add-services.component';
import { StudentInternshipsComponent } from './admin/student-internships/student-internships.component';
import { AddEventsComponent } from './admin/add-events/add-events.component';
import { StudentInternshipComponent } from './alumni/student-internship/student-internship.component';
import { FundraisersComponent } from './alumni/fundraisers/fundraisers.component';
import { DidUDonateComponent } from './alumni/did-u-donate/did-u-donate.component';
import { SurveyComponent } from './common/survey/survey.component';
import { AddInternshipComponent } from './alumni/add-internship/add-internship.component';
import { MyProfileComponent } from './alumni/my-profile/my-profile.component';
import { YourParticipationComponent } from './alumni/your-participation/your-participation.component';
import { YourEmploymentHistoryComponent } from './alumni/your-employment-history/your-employment-history.component';
import { AddEmploymentHistoryComponent } from './admin/add-employment-history/add-employment-history.component';
import { NotificationsComponent } from './common/notifications/notifications.component';
import { NewMergedRegistrationRecordsComponent } from './admin/new-merged-registration-records/new-merged-registration-records.component';
import { AdminAlumniinfoDetailsComponent } from './admin/admin-alumniinfo-details/admin-alumniinfo-details.component';
import { AdminSchoolinfoLettergradeDetailsComponent } from './admin/admin-schoolinfo-lettergrade-details/admin-schoolinfo-lettergrade-details.component';
import { EmploymentHistoryListComponent } from './admin/employment-history-list/employment-history-list.component';
import { AlumniDonationComponent } from './admin/alumni-donation/alumni-donation.component';
import { EditAllRegistrationComponent } from './admin/edit-all-registration/edit-all-registration.component';
import { ListEventsComponent } from './admin/list-events/list-events.component';
import { ListFundraiserComponent } from './admin/list-fundraiser/list-fundraiser.component';
import { ListSurveyComponent } from './admin/list-survey/list-survey.component';
import { MathCourseComponent } from './admin/math-course/math-course.component';
import { ScienceCourseComponent } from './admin/science-course/science-course.component';
import { CsCourseComponent } from './admin/cs-course/cs-course.component';
import { SummaryTableComponent } from './admin/summary-table/summary-table.component';
import { ListLetterGradesComponent } from './admin/list-letter-grades/list-letter-grades.component';

import { SchoolSectionsComponent } from './admin/school-sections/school-sections.component';
import { AddEditSchoolSectionsComponent } from './admin/add-edit-school-sections/add-edit-school-sections.component';
import { FlyerViewComponent } from './common/flyer-view/flyer-view.component';
import { SectionAssignmentComponent } from './admin/section-assignment/section-assignment.component';
import { EditSectionAssignmentComponent } from './admin/edit-section-assignment/edit-section-assignment.component';
import { AdminRegistrationFlyerComponent } from './admin/admin-registration-flyer/admin-registration-flyer.component';
import { TrackConfigurationComponent } from './admin/track-configuration/track-configuration.component';
import { AddSessionsComponent } from './admin/add-sessions/add-sessions.component';

const routes: Routes = [

  { path: 'test', component: TestComponent },
  { path: 'test-table', component: TestTableComponent },
  { path: '', component: StartComponent },
  { path: 'signup', component: StartComponent },
  { path: 'comming-soon', component: CommingSoonComponent },

  { path: 'terms-conditions', component: TermsConditionComponent },
  { path: 'subscribe', component: SubscribeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'forgot-success', component: ForgotSuccessComponent },
  { path: 'terms-and-condition', component: FooterTermConditionComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'feedback', component: FeedbackComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'online-help', component: QuestionsComponent },
  ///user
  { path: 'review-profile', component: ReviewProfileComponent },
  { path: 'user-profile', component: UserProfileComponent },
  { path: 'register-student', component: RegisterStudentComponent },
  { path: 'registration-record', component: RegistrationRecordsComponent },
  { path: 'old-registration-record', component: OldRegistrationRecordComponent },
  { path: 'student-certificate', component: StudentCertificateComponent },
  { path: 'admin-support', component: AdminSupportComponent },
  { path: 'messsage', component: MessagesComponent },
  { path: 'reg-flyer', component: RegistrationFlyerComponent },
  { path: 'teacher-notes', component: TeacherNotesComponent },

  { path: 'resubscribe', component: UnsubscribeComponent },
  { path: 'finish-page', component: FinishPageComponent },
  //admin
  { path: 'add-sessions', component: AddSessionsComponent },
  { path: 'admin-configure', component: AdminConfigurationComponent },
  { path: 'register-student-team', component: AdminRegisterStudentComponent },
  { path: 'merge-record', component: AdminMergeComponent },
  { path: 'admin-supports', component: AdminSupportsComponent },
  { path: 'admin-alumini-records', component: AdminAluminiRecordsComponent },
  { path: 'setup-online-registration', component: AdminSetupComponent },
  { path: 'edit-user-profile', component: AdminAddeditUserprofileComponent },
  { path: 'edit-letter-grade', component: AdminAddeditLettergradeComponent },
  { path: 'edit-school-course', component: AdminAddeditSchoolcourseComponent },
  { path: 'edit-school-name', component: AdminAddeditSchoolnameComponent },
  { path: 'edit-program-module', component: AdminAddeditProgrammoduleComponent },
  { path: 'edit-teachers-assignment', component: AdminAddeditTeacherassignmentComponent },
  { path: 'admin-user-subscription', component: AdminUserinfoUsersubscriptionComponent },
  { path: 'admin-user-profile', component: AdminUserinfoUserprofileComponent },
  { path: 'old-registration-records', component: AdminOldregistrationRecordsComponent },
  { path: 'all-registration-records', component: AdminAllregistrationRecordsComponent },
  { path: 'new-merged-registration-records', component:NewMergedRegistrationRecordsComponent },
  { path: 'alumini-info', component: AdminAluminiinfoComponent },
  { path: 'teacher-assignment', component: AdminTeacherassignmentComponent },
  { path: 'letter-grades', component: AdminSchoolinfoLettergradeComponent },

  { path: 'program-configuration', component: AdminProgramConfigComponent },
  { path: 'registration-flyer', component: AdminRegistrationFlyerComponent },
  { path: 'configure_track', component: TrackConfigurationComponent },
 

  

  { path: 'section-assignment', component: SectionAssignmentComponent },
  { path: 'edit-section-assignment', component: EditSectionAssignmentComponent },

  { path: 'school-course', component: AdminSchoolinfoSchoolcourseComponent },
  { path: 'school-names', component: AdminSchoolinfoSchoolnamesComponent },
  { path: 'chise-modules', component: AdminSchoolinfoChisemodulesComponent },
  { path: 'edit-old-registration-records', component: AdminEditOldregistrationComponent },

  { path: 'chise-participation-student', component: AdminSchoolinfoChiseParticipationComponent },
  { path: 'teacher-certificates', component: TeacherCertificatesComponent },
  { path: 'student-certificates', component: StudentCertificatesComponent },

  { path: 'contact-email', component: ContactEmailComponent },
  { path: 'contact-number', component: ContactNumberComponent },
  { path: 'contact-adress', component: ContactAdressComponent },
  { path: 'alumini-overview', component: AlumniOverviewComponent },

  { path: 'award-certificate', component: AwardCertificateComponent },
  { path: 'certificate-teacher', component: CertificateTeacherComponent },
  { path: 'certificate-student', component: CertificateStudentComponent },
  { path: 'admin-chise-status', component: AdminChiseStatusComponent },
  { path: 'student-roll-call', component: AdminRollCallComponent },
  { path: 'adminsupport', component: AdminSupportExecutiveComponent },
  { path: 'add-letter-grade', component: AddLetterGradeComponent },

  { path: 'alumni-contribution', component: AlumniContributionComponent },
  { path: 'add-events', component: AddEventsComponent },
  { path: 'add-fundraisers', component: AddFundraisersComponent },
  { path: 'add-services', component: AddServicesComponent },
  { path: 'student-internship', component: StudentInternshipsComponent },
  //teacher
  { path: 'student-attendence-level', component: StudentAttendenceLevelComponent },
  { path: 'teacher-awards', component: TeacherAwardsComponent },
  { path: 'student-awards', component: StudentAwardsComponent },
  { path: 'award-student-certificate', component: AwardStudentCertificateComponent },
  { path: 'track-assignment', component: TrackAssignmentComponent },
  { path: 'roll-call', component: RollCallComponent },

  { path: 'registration-flyer', component: RegistrationflyerComponent },

  //exec
  { path: 'total-registration', component: TotalRegistrationComponent },
  { path: 'datasheet', component: ExecDatasheetComponent },
  { path: 'data-analytics', component: ExecDataAnalyticsComponent },

  //common
  { path: 'chat', component: ChatComponent },
  { path: 'settings', component: SettingsComponent },
  { path: 'survey', component: SurveyComponent },
  { path: 'notifications', component: NotificationsComponent },
  { path: 'view-flyer', component: FlyerViewComponent },
 
  //alumni
  { path: 'your-contributions', component: YourContributionsComponent },
  { path: 'chise-events', component: ChiseEventsComponent },
  { path: 'studentinternships', component: StudentInternshipComponent },
  { path: 'chise-fundraisers', component: FundraisersComponent },
  { path: 'did-you-donate', component: DidUDonateComponent },
  { path: 'add-internship', component: AddInternshipComponent },
  { path: 'my-profile', component: MyProfileComponent },
  { path: 'your-participation', component: YourParticipationComponent },
  { path: 'your-employment-history', component: YourEmploymentHistoryComponent },
  {path:'add-employment-history',component:AddEmploymentHistoryComponent},
  {path:'alumini-info-details',component:AdminAlumniinfoDetailsComponent},
  {path:'letter-grades-details',component:AdminSchoolinfoLettergradeDetailsComponent},
   {path:'employment-list',component:EmploymentHistoryListComponent},
   {path:'alumni-donation-list',component:AlumniDonationComponent},
   {path:'register-studentteam',component:EditAllRegistrationComponent},
   {path:'list-events',component:ListEventsComponent},
   {path:'list-fundraisers',component:ListFundraiserComponent},
   {path:'list-survey',component:ListSurveyComponent},
   {path:'math-course',component:MathCourseComponent},
   {path:'science-course',component:ScienceCourseComponent},
   {path:'cs-course',component:CsCourseComponent},
   {path:'summary-table',component:SummaryTableComponent},
   {path:'list-lettergrade',component:ListLetterGradesComponent},
   {path:'school-sections',component:SchoolSectionsComponent},
   {path:'add-edit-school-sections',component:AddEditSchoolSectionsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload',
    useHash: true
  })],
  exports: [RouterModule]
})



export class AppRoutingModule { }
