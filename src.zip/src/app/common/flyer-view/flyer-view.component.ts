import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-flyer-view',
  templateUrl: './flyer-view.component.html',
  styleUrls: ['./flyer-view.component.css']
})
export class FlyerViewComponent implements OnInit {
  url = this.api.geturl();
  public sourceData: string;
  constructor(private api: ApiService, private router: Router, private http: HttpClient,) {

  }


  ngOnInit(): void {
    this.getflyer();
  }


  getflyer(){
    var userid = {
      user_id: ''
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_flyer`, userid).subscribe(data => {
      $('.pageloader').hide();
      if(data.status==true)
      {
        $('#flyercontent').html(data.html);
      }
      else
      {
        this.sourceData = 'Welcome, ChiS&E Families!';
      }
  }, err => {
      $('.pageloader').hide();
    })
  }


}
