import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  constructor(private api: ApiService,private fb: FormBuilder,private http: HttpClient , private router: Router) { 
    this.createForm();
  }
  url = this.api.geturl();

  form: FormGroup;
  username = false
  ngOnInit(): void {
    $('#feedback').css('display','none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
  }

  createForm() {
    this.form = this.fb.group({
      username: new FormControl('', [Validators.required,]),    
    });
  }

  change() {
    $('#username').val($('#username').val().replace(/[^a-z0-9]/gi, ''));
   
    var reg_Ex =/^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
    var isValiduname = reg_Ex.test($('#username').val())
    // if(isValiduname== false){
    //   this.username= true
    // $('#uname').addClass("error");
    // }else{
    //   this.username=false
    // }
  }

  reset_password(){
    if(this.form.value.username)
    {
      this.username= false 
// alert($('#username').val());
      if(($('#username').val()) =='Admin1'){
        $('#alerttitle').html('<img src="assets/images/block.svg"> Username');
        $('#alerttext').html('You cannot reset the password of the Super user!');
        $('#alertbtn').trigger('click');
      }else{
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/update_password`,  this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if(data.status==false){
          $('#alerttitle').html('<img src="assets/images/block.svg"> Username');
          $('#alerttext').html(data.message);
          $('#alertbtn').trigger('click');
        }
        else if(data.status==true){
          this.router.navigate(['forgot-success/']);
        }
        }, err => {
          $('.pageloader').hide();
        })
      }
    }else
    {
      this.username= true
      // return;
    }

  }

}
