import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  url = this.api.geturl();
  progForm: FormGroup;
  to_user = false;
  user_Class = false;
  message = false;
  error: boolean;
  public Editor = ClassicEditor;
  public sourceData: string;
  dropdownList :any=[];
  dropdownsList = [];
  selectedItems = [];
  dropdownSettings = {};
  dropdown_Settings = {};
  logdata: any;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    this.sourceData = '';
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    this.progForm = this.formBuilder.group({
      user_class: new FormControl('', [Validators.required,]),
      from_user: new FormControl('', ),
      message: new FormControl('', [Validators.required,]),
      to_user: new FormControl('',[Validators.required,] ),
    })
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    console.log(this.logdata.user_id);
this.progForm.get('from_user').setValue(this.logdata.user_id);
if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'alumnus') || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
  $('.admins').css('display', 'none');
}
if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
  $('.users').css('display', 'none');       
}
if((this.logdata.class == 'alumnus') ){
  $('#guardian').css('display', 'none'); 
  $('#teacher').css('display', 'none'); 
}
if((this.logdata.class == 'guardian 1')  || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2') ){
  $('#admin').css('display', 'none'); 
}
    this.dropdownSettings =
    {
      singleSelection: true,
      idField: 'email_id',
      textField: 'first_name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      // showSelectedItemsAtTop: false,
    };
  }
  onchange(){
    var userid = {
      user_class:$('#user_class').val()
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_emails`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.dropdownList = data.emails
  
    }, err => {
      $('.pageloader').hide();
    })
  }
  submit() {
    this.error = false;
    if (!($('#user_class').val())) {
      $('#user_class').addClass('error');
      this.error = true;
    }
    if (!($('#to_user').val())) {
      $('#to_user').addClass('error');
      this.error = true;
    }else{
      $('#to_user').removeClass('error');
      this.error = false;
    }
    // console.log($('#welcome_message').val());
    // if (!($('#welcome_message').val())) {
    //   $('#welcome_message').addClass('error');
    //   this.error = true;
      
    // }
    if (this.error == false) {

      $('.pageloader').show();
      this.http.post<any>(`${this.url}/chat`, this.progForm.value).subscribe(data => {
        $('.pageloader').hide();
        console.log(data.status)
        if (data.status == false) {
          // alert('nah')
          $('#alerttitle').html('<img src="assets/images/block.svg">Send Email');
          $('#alerttext').html(data.message);
          $('#alertbtn').trigger('click');
        }
        else if (data.status == true) {
          // alert('yah')
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">Send Email');
          $('#errortext').html(data.message);
        }
      }, err => {
        console.log(err);
      })
    }
  }
}
