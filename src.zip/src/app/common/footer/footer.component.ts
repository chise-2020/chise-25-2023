import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  url = this.api.geturl();
  form2: FormGroup;
  userid: any;
  myModel: any;
  student_count = false
  students_count: any;
  logdata: any;
  returnpath: any;
  terms: any;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm2();
  }

  ngOnInit(): void {
    $("#current_year").text( (new Date).getFullYear() );
    // this.terms = JSON.parse(localStorage.getItem('terms_accept'));
    // if (localStorage.getItem("terms_accept") != null) {
    //   // $('.termscon').css('display','none');
    //   $('.termscon').css('pointer-events', 'none'); 
    //   }
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    console.log(this.logdata)
    console.log('footer')
    if (localStorage.getItem("loginData") != null) {
      this.form2.get('user_id').setValue(this.logdata.user_id);
      this.form2.get('group_id').setValue(this.logdata.family_code);
      //localStorage.setItem("stcount",data.studentcount);
      this.students_count = JSON.parse(localStorage.getItem('student_count'));
      console.log(this.students_count)
      this.myModel = "" + this.students_count + "";

      // console.log(this.logdata.class)
      if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
        $('.unsubs').css('display', 'none');

      }
      if ((this.logdata.class == "guardian 1") || (this.logdata.class == "guardian 2") || (this.logdata.class == "student 2")) {
        $('#feedback').css('display', 'none');
      }
    } else {
      $('#feedback').css('display', 'none');
      $('.unsubs').css('display', 'none');

    }




  }
  send_globalmessage(){
    var value = {
      message: $('#show_message').html(),
      teacher_name:$('#teacher_name').html(),
      track_name:$('#track_name').html(),
      term_year:$('#term_year').html(),
      track_id:$('#teacher_track').val(),
      teacher_id:$('#teacher_id').html()
    } 
    console.log(value);
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/send_globalmessage`, value).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg">Message to Students');
        $('#errortext').html(data.message);
      }
      else if (data.status == true) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Message to Students');
        $('#errortext').html(data.message);
      }
     
    }, err => {
      $('.pageloader').hide();
    })
  }
  logout() {
    console.log('clicked');
    localStorage.clear();
    window.location.reload();
    //     localStorage.openpages = Date.now();
    var onLocalStorageEvent = function (e) {
      if (e.key == "openpages") {
        // Emit that you're already available.
        localStorage.page_available = Date.now();
      }
      if (e.key == "page_available") {
        alert("One more page already open");
        // alert(window.location.href);
        const url = window.location.href;
        const lastSegment = url.split("/").pop();
        this.router.navigate(['login/']);
      }
    };
    // window.addEventListener('storage', onLocalStorageEvent, false);  
  }

  deleteData_cont() {
    var del = JSON.parse(localStorage.getItem('delete_item'));
    console.log(del)
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/delete_record`, del).subscribe(data => {
      if (data.status == true) {
        $('.pageloader').hide();
        this.reloadComponent();
        localStorage.setItem('delete_item', JSON.stringify(''));
      } else if (data.status == false) {
        $('.pageloader').hide();
      }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

  reset_reg_stud() {
    var setup_online= JSON.parse(localStorage.getItem('online_reg'));
    console.log(setup_online)
    if(setup_online == null){
     localStorage.setItem('reg_click', JSON.stringify(0));
    var user_id = JSON.parse(localStorage.getItem('student_item'));
    console.log(user_id.stud_id)
    $('#username' + user_id.stud_id).val('');
    $('#email' + user_id.stud_id).val('');
    $('#phone' + user_id.stud_id).val(''); 
    }else{
      window.location.reload();
    }
    
  }

  register_student() {
    var user_id = JSON.parse(localStorage.getItem('student_item'));
    console.log(user_id)
    if (user_id == null) {
      // alert('admin')
      $('.pageloader').show();
      var value = JSON.parse(localStorage.getItem('online_reg'));
      console.log(value.term)
      this.http.post<any>(`${this.url}/set_up_online`, value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == true) {
          window.location.reload();
        }
      }, err => {
        $('.pageloader').hide();
      })


    } else {
      // alert(user_id.user_class);
      var reg_check = JSON.parse(localStorage.getItem('reg_click'));
      // alert(user_id.user_class)
      if ((user_id.user_class == 'student 2')) {
        console.log(reg_check)
        console.log(user_id.id)
        if ((user_id.username !='') && (user_id.id =='')) {
          if (reg_check == 0) {
            // alert('in'); 
            localStorage.setItem('reg_click', JSON.stringify(1));
            $('#regbutton').trigger('click');
            $('#cnfrmtitle').html('<img src="assets/images/alert.svg">FAMILY PROFILE');
            $('#reg_content').html(user_id.first_name+' '+user_id.last_name);
          } else {
            // alert('api')
            localStorage.setItem('reg_click', JSON.stringify(0));
            $('.pageloader').show();
            this.http.post<any>(`${this.url}/update_user_profile`, user_id).subscribe(data => {

              if (data.status == false) {
                $('.pageloader').hide();
                $('#alertbtn').trigger('click');
                $('#alerttitle').html('<img src="assets/images/block.svg">FAMILY PROFILE ');
                $('#alerttext').html(data.message);
                // $('#alerttext').addClass('underline_text');
              } else {
                $('.pageloader').hide();
                $('#error-disp-btn').trigger('click');
                $('#modal_pass').html('<img src="assets/images/success.svg">FAMILY PROFILE ');
                $('#errortext').html(data.message);
                // $('#errortext').addClass('underline_text');
              }
            }, err => {
              $('.pageloader').hide();
            })
          }

        } else {
          localStorage.setItem('reg_click', JSON.stringify(0));
          $('.pageloader').show();
          this.http.post<any>(`${this.url}/update_user_profile`, user_id).subscribe(data => {

            if (data.status == false) {
              $('.pageloader').hide();
              $('#alertbtn').trigger('click');
              $('#alerttitle').html('<img src="assets/images/block.svg">FAMILY PROFILE ');
              $('#alerttext').html(data.message);
              // $('#alerttext').addClass('underline_text');
            } else {
              $('.pageloader').hide();
              $('#error-disp-btn').trigger('click');
              $('#modal_pass').html('<img src="assets/images/success.svg">FAMILY PROFILE ');
              $('#errortext').html(data.message);
              // $('#errortext').addClass('underline_text');
            }
          }, err => {
            $('.pageloader').hide();
          })
        }


      } else {
        localStorage.setItem('reg_click', JSON.stringify(0));
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/update_user_profile`, user_id).subscribe(data => {

          if (data.status == false) {
            $('.pageloader').hide();
            $('#alertbtn').trigger('click');
            $('#alerttitle').html('<img src="assets/images/block.svg">FAMILY PROFILE ');
            $('#alerttext').html(data.message);
            // $('#alerttext').addClass('underline_text');
          } else {
            $('.pageloader').hide();
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">FAMILY PROFILE ');
            $('#errortext').html(data.message);
            // $('#errortext').addClass('underline_text');
          }
        }, err => {
          $('.pageloader').hide();
        })
      }


    }
  }
  send_flyermail(){
    var value = {
      id: '',
    } 
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/send_flyermail`, value).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg">Registration Flyer');
        $('#errortext').html(data.message);
      }
      else if (data.status == true) {
        $('#pass_pop').trigger('click');
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Registration Flyer');
        $('#errortext').html('Successfully send mail');
      }
     
    }, err => {
      $('.pageloader').hide();
    })
  }
  send_mail(){
    
    var user_id = JSON.parse(localStorage.getItem('send_mail_data'));

    if(user_id.length!=0)
    {
      var value = {
        user_id: user_id.user_id,
      } 
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/send_usermail`, value).subscribe(data => {
        $('.pageloader').hide();
        localStorage.setItem('send_mail_data', JSON.stringify(0));
        if (data.status == false) {
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg">LOGIN EMAIL');
          $('#errortext').html(data.message);
        }
        else if (data.status == true) {
          //$('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">LOGIN EMAIL');
          $('#errortext').html(data.message);
        }
       
      }, err => {
        $('.pageloader').hide();
      })

    }else
    {
      if($('#c_current').prop("checked") == true) {
        var email=1;
      }
      else if($('#c_current').prop("checked") == false) {
        var email=0;
      }
       var value2= {
        email: email,
      } 
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/send_usermail`, value2).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg">EMAIL');
          $('#errortext').html(data.message);
        }
        else if (data.status == true) {
         // $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">EMAIL');
          $('#errortext').html(data.message);
        }
       
      }, err => {
        $('.pageloader').hide();
      })
    }
    

   
    
  }
  support_submit() {
    var values = {
      support_id: $('#support_id').val(),
      admin_response: $('#admin_response').val(),
    }
    // alert($('#admin_resposne').val()) 
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/add_adminresponse`, values).subscribe(data => {
      // console.log(data.status)
      if (data.status == true) {
        $('.pageloader').hide();
        // $('#alertbtn').trigger('click');
        // $('#alerttitle').html('<img src="assets/images/success.svg">Admin Response');
        // $('#alerttext').html(data.message);

        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Admin Response');
        $('#errortext').html(data.message);
      } else {
        $('.pageloader').hide();
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg"> Admin Response');
        $('#errortext').html(data.message);

      }
    }, err => {
      $('.pageloader').hide();
    })
  }
  student_certi(){
    var type = JSON.parse(localStorage.getItem('set_award_details'));
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/award_student_certi`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      if (data.status == false) {
        $('#alerttitle').html('<img src="assets/images/block.svg">Award Student Certificates');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      else if (data.status == true) {
        $('#alerttitle').html('<img src="assets/images/success.svg">Award Student Certificates');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  rollcall() {
    // var value = JSON.parse(localStorage.getItem('set_rollcall'));
    var type = JSON.parse(localStorage.getItem('setrollcall'));
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/add_rollcall`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      if (data.status == false) {
        $('#alerttitle').html('<img src="assets/images/block.svg">Roll Call');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      else if (data.status == true) {
        // $('#pass_pop').trigger('click');
        // $('#error-disp-btn').trigger('click');
        // $('#modal_pass').html('<img src="assets/images/success.svg">ASSIGN REVIEW TEAM');
        // $('#errortext').html(data.message);
        $('#alerttitle').html('<img src="assets/images/success.svg">Roll Call');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
    // $('.pageloader').show();
    // this.http.post<any>(`${this.url}/student_rollcall`, value).subscribe(data => {
    //   $('.pageloader').hide();
    //   $('#error-disp-btn').trigger('click');
    //   $('#modal_pass').html('<img src="assets/images/success.svg"> Student Roll Call');
    //   $('#errortext').html('Successfully toggled the Certificate.');
    //   // window.location.reload();
    //   $('#yesbtn').css('display', 'none');
    //   $('#ok_btn').css('display', 'none');
    //   $('#ok').css('display', 'block');
    // }, err => {
    //   $('.pageloader').hide();
    // })
  }
  award_certi() {
    var value = JSON.parse(localStorage.getItem('set_awards'));
    // var value={
    //   type:'student'
    // }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/award_certificate`, value).subscribe(data => {
      $('.pageloader').hide();
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/success.svg">Award Certificate');
      $('#error-body').html('Successfully Awarded certificates.');
      $('#ok').css('display', 'block');
      $('#ok').html('Ok');
      $('#review_btns').css('display', 'none');
      $('#award_yesbtn').css('display', 'none');
    }, err => {
      $('.pageloader').hide();
    })
  }
  unsubscribe() {
    var user_id = {
      user_id: this.logdata.user_id,
      email: this.logdata.email,
      userclass: this.logdata.class,
      family_code: this.logdata.family_code
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/user_unsubscribe`, user_id).subscribe(data => {

      if (data.status == false) {
        $('.pageloader').hide();
        $('#alertbtn').trigger('click');
        $('#alerttitle').html('<img src="assets/images/block.svg"> Unsubscribe');
        $('#alerttext').html(data.message);
      } else {
        $('.pageloader').hide();
        // $('#error-disp-btn').trigger('click');
        // $('#modal_pass').html('<i class="fas fa-check-circle"></i> Profile');
        // $('#errortext').html(data.message);
        localStorage.clear();
        this.router.navigate(['finish-page/']);
      }
    }, err => {
      $('.pageloader').hide();
    })
  }
  accept_term() {
    // localStorage.setItem('terms_accept', JSON.stringify('1'));
    //setting terms and condition as accepted
  }
  profilego() {
    if (localStorage.getItem('loginData') != null) {

      if ((this.logdata.class == "guardian 1")) {
        // if ((this.logdata.student_count != "0")) {
        this.router.navigate(['user-profile/']);
        // }
        // else {
        //   this.router.navigate(['review-profile/']);
        // }

      }
      else if ((this.logdata.class == "guardian 2") || (this.logdata.class == "student 2")) {
        this.router.navigate(['user-profile/']);
      }
      else if ((this.logdata.class == "admin")) {
        this.router.navigate(['admin-user-subscription/']);
      }
      else if ((this.logdata.class == "executive 1")) {
        this.router.navigate(['admin-user-subscription/']);
      }
      else if ((this.logdata.class == "executive 2")) {
        this.router.navigate(['admin-user-subscription/']);
      }
      else if ((this.logdata.class == "teacher")) {
        this.router.navigate(['student-attendence-level/']);
      }
      $('#closebutton').trigger('click');
    }
  }
  unsubscribe_popup() {
    $('#unsubscribebutton').trigger('click');
  }
  reloadComponent() {
    let currentUrl = this.router.url;
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([currentUrl]);
  }
  refresh(): void {
    // window.location.reload(); 
    this.returnpath = JSON.parse(localStorage.getItem('set_editpath'));
    console.log(this.returnpath)
    if(this.returnpath == 'schoolsection')
    {
      this.router.navigate(['school-sections/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "school_name") {
      this.router.navigate(['school-names/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "user_subscription") {
      this.router.navigate(['admin-user-subscription/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "school_course") {
      this.router.navigate(['school-course/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "alumni") {
      this.router.navigate(['alumini-info/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "lettergrade") {
      this.router.navigate(['letter-grades/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "teacherassignment") {
      this.router.navigate(['teacher-assignment/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }

    if (this.returnpath == "program_module") {
      this.router.navigate(['chise-modules/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }

    if (this.returnpath == "register_student") {
      this.router.navigate(['all-registration-records/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }


    if (this.returnpath == "counts") {
      this.router.navigate(['user-profile/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "merge_unmerge") {
      this.router.navigate(['merge-record/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "user_profile") {
      this.router.navigate(['admin-user-profile/']);
      localStorage.setItem('set_editpath', JSON.stringify(''));
    }
    if (this.returnpath == "fundraiser") {
      this.router.navigate(['list-fundraisers/']);
      localStorage.setItem('set_fundid', JSON.stringify(''));
    }
    if (this.returnpath == "events") {
      this.router.navigate(['list-events/']);
      localStorage.setItem('set_evenid', JSON.stringify(''));
    }
    if (this.returnpath == "survey") {
      this.router.navigate(['list-survey/']);
      localStorage.setItem('set_survey', JSON.stringify(''));
    }

    if (this.returnpath == "survey") {
      this.router.navigate(['list-survey/']);
      localStorage.setItem('set_survey', JSON.stringify(''));
    }

    if (this.returnpath == "section_assignment") {
      this.router.navigate(['section-assignment/']);
      localStorage.setItem('section_assignment', JSON.stringify(''));
    }

    if (this.returnpath == "track_config") {
      this.router.navigate(['program-configuration/']);
      localStorage.setItem('track_config', JSON.stringify(''));
    }

    if (this.returnpath == "session_config") {
      window.location.reload();
      localStorage.setItem('set_trackconfig', JSON.stringify(''));
      // this.router.navigate(['program-configuration/']);
      // localStorage.setItem('session_config', JSON.stringify(''));
    }
    
    
    if (this.returnpath == "") {
      window.location.reload();
    }
    if (!(this.returnpath)) {
      window.location.reload();
    }


  }



  createForm2() {
    this.form2 = this.fb.group({
      student_count: new FormControl('', [Validators.required,]),
      group_id: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
    });
  }



  save_students() {
    localStorage.setItem('set_editpath', JSON.stringify('counts'));
    this.formValidation()
    if (this.student_count == true) {
      return;
    }

    // Get back item "kittens" from local storage
    var logdat = JSON.parse(localStorage.getItem("loginData"));

    // Change value
    logdat.student_count = this.form2.value.student_count;

    // Save the new item with updated value
    localStorage.setItem("loginData", JSON.stringify(logdat));
    this.students_count = JSON.parse(localStorage.getItem('student_count'));
    console.log(this.students_count)
    //localStorage.setItem("stcount",data.studentcount);
    this.myModel = "" + this.students_count + "";
    this.http.post<any>(`${this.url}/save_count`, this.form2.value).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg"> FAMILY PROFILE ');
        $('#errortext').html('Failed to Update');
      }
      else if (data.status == true) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg"> FAMILY PROFILE ');
        $('#errortext').html(data.message);

      }

    }, err => {
      console.log(err);
    })
  }
  save_student_count() {
    // localStorage.setItem('set_editpath', JSON.stringify('counts'));
    var students_count = JSON.parse(localStorage.getItem('student_count_data'));
    // console.log(students_count)
    //localStorage.setItem("stcount",data.studentcount);
    // this.myModel = "" + this.students_count + "";
    this.http.post<any>(`${this.url}/save_student_count`, students_count).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg"> FAMILY PROFILE ');
        $('#errortext').html('Failed to Update');
      }
      else if (data.status == true) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg"> FAMILY PROFILE ');
        $('#errortext').html(data.message);
        $('#student_ok').css('display', 'none');
        $('#ok').html('ok');
        $('#ok').removeClass('violet-btn');
        $('#ok').addClass("green-btn");
      }

    }, err => {
      console.log(err);
    })
  }

  formValidation() {
    if (this.form2.value.student_count) {
      this.student_count = false

    } else {
      this.student_count = true
    }
  }

  save_reg(){
    var value = JSON.parse(localStorage.getItem('reg_student'));
    $('.pageloader').show();
        this.http.post<any>(`${this.url}/register_save`,  value).subscribe(data => {
          $('.pageloader').hide();
          if(data.status==false){
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg"> Register Student');
            $('#errortext').html(data.message);
           }
          else if(data.status==true){
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg"> Register Student');
            $('#errortext').html(data.message);
            // this.form.reset();
          }
          }, err => {
            $('.pageloader').hide();
          })

  }
  contact_click(){
    localStorage.setItem("contact_click", JSON.stringify('1'));   
  }
  check_pop(){//to check if add student button is clicked
    localStorage.setItem("add_click", JSON.stringify('1')); 
    this.router.navigate(['user-profile/']);
  }
}
