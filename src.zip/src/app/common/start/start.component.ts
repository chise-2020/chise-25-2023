import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css']
})
export class StartComponent implements OnInit {

  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) { }

  ngOnInit(): void {
    localStorage.clear();
    $('#feedback').css('display','none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
    localStorage.clear ();
  }
  start_helpclick(){
    localStorage.setItem('starthelp',JSON.stringify(1));
    
  }
  startclick(){
$('#overlay_3').trigger('click');
  }


}
