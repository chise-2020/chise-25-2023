import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-success',
  templateUrl: './forgot-success.component.html',
  styleUrls: ['./forgot-success.component.css']
})
export class ForgotSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
