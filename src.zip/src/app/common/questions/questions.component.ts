import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  url = this.api.geturl();
  logdata: any = [];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#FAQ').trigger('click');
    if (localStorage.getItem("loginhelp") == '1'){
      $('#FAQ').trigger('click');
    }
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if(this.logdata ) {
    }
  }

}
