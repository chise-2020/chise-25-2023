import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-footer-term-condition',
  templateUrl: './footer-term-condition.component.html',
  styleUrls: ['./footer-term-condition.component.css']
})
export class FooterTermConditionComponent implements OnInit {

  logdata: any;
  constructor() { }

  ngOnInit(): void {
    $('#feedback').css('display','none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if((this.logdata.terms_status == 1)) {
       $('.termscon1').addClass('active-terms');  
       $('#termscheck').prop('checked', true);
    }else{
      $('#termscheck').prop('checked', false);
    }
      // $('#overlay_3').trigger('click');(localStorage.getItem("terms_accept") != null) ||
      $('.termscon').css('pointer-events', 'none');
      $('.termscon1').css('pointer-events', 'none');
       $('.termscon').prop("disabled",true);
   
      $('.termscon1').addClass('disabled-button');
      $('.termscon').addClass('disabled-button');
      this.getdata()
  }
getdata(){
  
}
}
