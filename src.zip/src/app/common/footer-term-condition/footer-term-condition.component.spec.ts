import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterTermConditionComponent } from './footer-term-condition.component';

describe('FooterTermConditionComponent', () => {
  let component: FooterTermConditionComponent;
  let fixture: ComponentFixture<FooterTermConditionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FooterTermConditionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterTermConditionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
