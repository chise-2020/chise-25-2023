import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { empty } from 'rxjs';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  url = this.api.geturl();
  form: FormGroup;
  password = false;
  username = false;
  // this.username = this.password = false;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm();
  }

  ngOnInit(): void {
    $('#feedback').css('display', 'none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
    localStorage.clear ();
    localStorage.setItem('contact_click', JSON.stringify('0'));
    if (JSON.parse(localStorage.getItem('contactclick')) == 1) {
      // location.reload(); 
      localStorage.setItem('contactclick', JSON.stringify('0'));
    }
    // localStorage.clear();
    $("#uname").focus();

    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });



    $(function () {
      $('#eye').click(function () {
        if ($(this).hasClass('fa-eye-slash')) {
          $(this).removeClass('fa-eye-slash');
          $(this).addClass('fa-eye');
          $('#password').attr('type', 'text');
        } else {
          $(this).removeClass('fa-eye');
          $(this).addClass('fa-eye-slash');
          $('#password').attr('type', 'password');
        }
      });
    });

  }

  createForm() {
    this.form = this.fb.group({
      username: new FormControl('', [Validators.required,]),
      password: new FormControl('', [Validators.required,]),

    });
  }

  change() {
    $('#uname').val($('#uname').val().replace(/[^a-z0-9]/gi, ''));
    if (($('#uname').val().length < 6) || ($('#uname').val().length > 6)) {

      $('#uname').addClass('error');
      this.username = true
    } else {
      var reg_Ex = /^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
      var isValiduname = reg_Ex.test($('#uname').val())
      if (isValiduname == false) {
        this.username = true
        $('#uname').addClass("error");
      } else {
        this.username = false
      }
    }
  }

  submit() {
   

    localStorage.setItem('submit_status', JSON.stringify(1));
    if (($('#uname').val())) {
      if (($('#uname').hasClass('error')) == true) {
        this.username = true;
        $('#uname').addClass('error');
      } else {
        this.username = false;
        $('#uname').removeClass('error');
      }
    } else {
      this.username = true;
      $('#uname').addClass('error');
    }

    if (!($('#password').val())) {
      this.password = true;
      $('#password').addClass('error');
    } else {
      this.password = false;
      $('#password').removeClass('error');
    }
    // if (this.form.value.password == '') {
    //   this.password = true

    // }
    if ((this.username == false) && (this.password == false)) {
      console.log(localStorage.getItem('loginData'))
      // alert(JSON.parse(localStorage.getItem('loginData')))
      
      if ((localStorage.getItem('loginData') == null)) {
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/login`, this.form.value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            localStorage.setItem('submit_status', JSON.stringify(''));
            $('#alerttitle').html('<img src="assets/images/block.svg">LOGIN');
            $('#alerttext').html(data.message);
            $('#alertbtn').trigger('click');
          }
          else if (data.status == true) {
            localStorage.setItem('loginhelp', JSON.stringify(''));
            localStorage.setItem('starthelp', JSON.stringify(''));
            localStorage.setItem('loginData', JSON.stringify(data.user));
            console.log(localStorage.getItem('loginData'));
            if ((data.user.class == "guardian 1")) {
              if ((data.user.student_count != "0")) {
                this.router.navigate(['user-profile/']);
              }
              else {
                this.router.navigate(['review-profile/']);
              }

            }
            else if ((data.user.class == "guardian 2") || (data.user.class == "student 2")) {
              this.router.navigate(['user-profile/']);
            }
            else if ((data.user.class == "admin") || (data.user.class == "data manager") || (data.user.class == "executive 1") || (data.user.class == "executive 2")) {
              this.router.navigate(['admin-user-subscription/']);
            }
            else if ((data.user.class == "teacher")) {
              this.router.navigate(['track-assignment/']);
            }
            else if ((data.user.class == "alumnus")) {
              this.router.navigate(['my-profile/']);
            }
            else {
              this.router.navigate(['login/']);
            }
          }
        }, err => {
          console.log(err);
        })

      } else {
        //already logged in from the browser so they can't log in again without logging out
        this.router.navigate(['login/']);
        $('#alerttitle').html('<img src="assets/images/block.svg">Login');
        $('#alerttext').html('You have already logged into the Student Portal.<br>Do you want to log out?');
        $('#logout_button').css('display', 'block');
        $('#nobutton').css('display', 'block');
        $('#closebutton').css('display', 'none');
        $('#alertbtn').trigger('click');

      }


    }
  }
  login_helpclick() {
    console.log('enter click')
    localStorage.setItem('loginhelp', JSON.stringify(1));
  }
 
}

