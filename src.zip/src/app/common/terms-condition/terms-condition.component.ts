import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-terms-condition',
  templateUrl: './terms-condition.component.html',
  styleUrls: ['./terms-condition.component.css']
})
export class TermsConditionComponent implements OnInit {

constructor(private api: ApiService,private fb: FormBuilder,private http: HttpClient,private router: Router,) 
{ }
 
  ngOnInit(): void {
    $('#feedback').css('display','none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
    console.log(localStorage.getItem("terms_accept"))
        // alert(window.location.href);
    // if (localStorage.getItem("terms_accept") != null) {
    //   // $('#overlay_3').trigger('click');
    //   $('.termscon').css('pointer-events', 'none');
    //   $('.termscon1').css('pointer-events', 'none');
    //    $('.termscon').prop("disabled",true);
    //   $('.termscon1').addClass('active-terms');
    //   $('.termscon1').addClass('disabled-button');
    //   $('.termscon').addClass('disabled-button');
    //   }  
     
  }
  acceptterm(){
  // alert('terms_accept')
    localStorage.setItem('terms_accept', JSON.stringify('1'));
    //setting terms and condition as accepted
  }


}
