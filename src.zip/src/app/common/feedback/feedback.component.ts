import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient) {
    this.createForm();
  }
  url = this.api.geturl();
  form: FormGroup;
  section = false
  user_friendly = false
  feedback_message = false
  logdata: any = [];
  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    $("#user_friendly").focus();

    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });

    $('.add').click(function () {
      $('.block:last').before('<div class="d-flex flex-column mt-5"><select class="form-control mb-2" ><option>Section</option><option>User Profile</option><option>Register Student</option</select><labelclass="review-lab" >Tell us more</label><textarea placeholder="Your feedback" rows="3" class="form-control" ></textarea><span class="remove">Remove Option</span> </div>');
    });
    $('.optionBox').on('click', '.remove', function () {
      $(this).parent().parent().remove();
    });
  }
  createForm() {
    this.form = this.fb.group({
      user_id: new FormControl('', [Validators.required,]),
      section: new FormControl('', [Validators.required,]),
      feedback_message: new FormControl('', [Validators.required,]),
      user_friendly: new FormControl('', [Validators.required,]),
    });
  }
  submit() {
    // alert('in')
    this.formValidation()
    if (this.section == true || this.feedback_message == true || this.user_friendly == true) {
      return;
      // alert('error')
    }
    if (localStorage.getItem("loginData") != null) {
      this.form.get('user_id').setValue(this.logdata.user_id);
    }
    console.log(this.form.value)
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/feedback`, this.form.value).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == true) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg"> Feedback');
        $('#errortext').html(data.message);
      } else {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg"> Feedback');
        $('#errortext').html(data.message);
      }


    }, err => {
      $('.pageloader').hide();
    })
  }

  formValidation() {
    if (this.form.value.section) {
      this.section = false

    } else {
      this.section = true
    }
    if (this.form.value.feedback_message) {
      this.feedback_message = false
    } else {
      this.feedback_message = true
    }
    if (this.form.value.user_friendly) {
      this.user_friendly = false
    } else {
      this.user_friendly = true
    }

  }
}
