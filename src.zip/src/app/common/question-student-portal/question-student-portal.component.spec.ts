import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionStudentPortalComponent } from './question-student-portal.component';

describe('QuestionStudentPortalComponent', () => {
  let component: QuestionStudentPortalComponent;
  let fixture: ComponentFixture<QuestionStudentPortalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestionStudentPortalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionStudentPortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
