import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-question-student-portal',
  templateUrl: './question-student-portal.component.html',
  styleUrls: ['./question-student-portal.component.css']
})
export class QuestionStudentPortalComponent implements OnInit {
  logdata: any = [];
  url = this.api.geturl();
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    if (localStorage.getItem("starthelp") == '1'){
      $('#sign_up_table').css('display','block');//table 1
      $('#start_table').css('display','block');//table 2
    }
    if ((localStorage.getItem("loginhelp") == '1') ){
      $('#login_table').css('display','block');//table 1
      $('#start_table').css('display','block');//table 2
    }
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if (this.logdata) {
      $('#activity_insideapp').css('display','block');//table 2
    
    if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
          $('#inside_app_whoru').css('display','block');                                  //table 2
    }else{
      $('#start_table').css('display','block');
    }
  }
  }

}
