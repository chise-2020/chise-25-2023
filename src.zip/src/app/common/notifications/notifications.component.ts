import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  logdata: any;
  url = this.api.geturl();
  form: FormGroup;//initializing form
  UserData: any;
  chise_events: any;
  user_class=false;
  survey_link=false;
  error=false;
  survey_list: any=[];
  exe: number;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    console.log(this.logdata.email);
if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'alumnus') || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
  $('.admins').css('display', 'none');
}
if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
  $('.users').css('display', 'none');       
}
  }

}
