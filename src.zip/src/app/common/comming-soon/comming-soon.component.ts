import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-comming-soon',
  templateUrl: './comming-soon.component.html',
  styleUrls: ['./comming-soon.component.css']
})
export class CommingSoonComponent implements OnInit {
  data: any = [];
  logperson: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    
  }

  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData'));
    if((this.data.class== "guardian 1")){
      this.logperson='guardian';
    }
    else if((this.data.class== "admin")){
      this.logperson='admin';
    }
    else if((this.data.class== "teacher")){
      this.logperson='teacher';
    }
    else
    {
      
    }

   
  }

}
