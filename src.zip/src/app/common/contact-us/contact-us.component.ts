import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  constructor(private api: ApiService,private fb: FormBuilder,private http: HttpClient) { 
    this.createForm();
  }
  url = this.api.geturl();
  form: FormGroup;
  fname = false
  lname = false
  uname = false
  email = false
  message = false
  logdata: any = [];
  ngOnInit(): void {
    //if(JSON.parse(localStorage.getItem('contact_click')) ==0){
    $('#contact_model').trigger('click');
    //}
    localStorage.setItem('loginhelp', JSON.stringify(''));
    localStorage.setItem('starthelp', JSON.stringify(''));
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
//     var log=this.logdata.replace('"','');
// var datalog=log.replace('"','');
    if (this.logdata) {
      if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
        $('.unsubs').css('display', 'none');
      }
    }else{
      $('#feedback').css('display', 'none');
      $('.unsubs').css('display', 'none');
    }
    $("#fname").focus();

    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
  }
  createForm() {
    this.form = this.fb.group({
      user_id: new FormControl('', [Validators.required,]),
      fname: new FormControl('', [Validators.required,]),
      lname: new FormControl('', [Validators.required, ]),
      uname: new FormControl('', [Validators.required, ]),
      email: new FormControl('', [Validators.required, Validators.pattern('^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]+$')]),
      message: new FormControl('', [Validators.required, ]),
    });
  }
  submit(){
    // alert('in')
    this.formValidation()
    if(this.fname== true || this.lname== true||  this.email== true|| this.message== true){
      return;
      // alert('error')
      }
    //  console.log(this.logdata.user_id)
//     var log=this.logdata.replace('"','');
// var datalog=log.replace('"','');
     if (this.logdata) {
    this.form.get('user_id').setValue(this.logdata.user_id);
     }

    $('.pageloader').show();
    this.http.post<any>(`${this.url}/contact_us`,  this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if(data.status==true){
          $('#ok').css('display', 'none');
          $('#redirect_back').css('display', 'block');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg"> Contact Admin');
          $('#errortext').html(data.message);
        }else
        {
          $('#ok').css('display', 'none');
          $('#redirect_back').css('display', 'block');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg"> Contact Admin');
          $('#errortext').html(data.message);
        }

       
    }, err => {
      $('.pageloader').hide();
    })
}

  formValidation(){
    if (($('#fname').val())){
      $('#fname').removeClass('error');
      this.fname= false
    
    }else{
      $('#fname').addClass('error');
      this.fname= true
    }
   if (($('#lname').val())){
      $('#lname').removeClass('error');
      this.lname= false
    }else{
      $('#lname').addClass('error');
      this.lname= true
    }
    if (($('#message').val())){
      $('#message').removeClass('error');
      this.message= false
    }else{
      $('#message').addClass('error');
      this.message= true
    }
   
 
    if (($('#email').val())){
      var regEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      var isValidEmail = regEx.test(this.form.value.email)
      if(isValidEmail== false){
        this.email = true
        $('#email').addClass("error");
      }else{
        this.email = false
        $('#email').removeClass("error");
      }
    }else{
      this.email= true
      $('#email').addClass("error");
    }
  }
  go_back(){
    history.back();
    localStorage.setItem("contactclick", JSON.stringify('1'));   
// location.reload(); 
  }
}
