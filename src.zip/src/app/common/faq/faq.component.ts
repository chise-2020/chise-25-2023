import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  logdata: any = [];
  url = this.api.geturl();
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('#contacttab').addClass('active');
    $('#profile-tab').removeClass('active');
    $('#FAQ').addClass('active');
    $('#FAQ').addClass('show');
    $('#FAQ').removeClass('fade');
    $('#Portal-Speak').removeClass('active');
    $('#Portal-Speak').removeClass('show');
    $('#cnt_us').css('display', 'block');
    // alert();
    // console.log(window.history.previous.href)
    // var url =window.history.previous.href;
    // const lastSegment = url.substring(url.lastIndexOf("/") + 1);
    // alert(lastSegment )

    // console.log(lastSegment); // "playlist"
    // if((lastSegment=="") || (lastSegment=="") ){
    //   console.log('entersignup')
    // $('#signup').css('display','block');
    // }

    if (localStorage.getItem("starthelp") == '1') {
      $('#signup').css('display', 'block');
      $('#signup_tab').css('display', 'block');
      // $('#coll_4').removeClass('collapsed');
      // $('#collapseq4').addClass('show');
      $('#terms').css('display', 'block');
      $('#signup_tab').addClass('active');
    }
    console.log(localStorage.getItem("loginhelp"))
    if ((localStorage.getItem("loginhelp") == '1')) {
      console.log('enterlogin')
      $('#login').css('display', 'block');
      $('#login_tab').css('display', 'block');
      $('#login_tab').addClass('active');
      // $('#coll_5').removeClass('collapsed');
      // $('#Login').addClass('show');
      // $('#faq').css('display','block');
      $('#admin_support').css('display', 'none');
      $('#survey').css('display', 'none');
      $('#abt_swt').css('display', 'none');
    }
    console.log(localStorage.getItem("previous_url"))




    var link = localStorage.getItem("previous_url")
    var url = link.replace('"', '');
    var urls = url.replace('"', '');
    console.log(urls)
    if (urls) {
      console.log('enter apps')
    }
    if (urls) {

      if ((localStorage.getItem("previous_url") != null)) {
     
        console.log('enter app')
        $('#faq').css('display', 'block');
        $('#admin_support').css('display', 'none');
        $('#survey').css('display', 'block');
        $('#abt_swt').css('display', 'block');
        $('#terms').css('display', 'block');
        if (urls == 'user-profile') {
          // console.log('enterprofile')
          $('#family_prof').css('display', 'block');
          $('#coll_6').removeClass('collapsed');
          $('#Family-Profile').addClass('show');
        }
        if ((urls == 'registration-record') || (urls == 'old-registration-record') || (urls == 'student-certificate')) {
          console.log('enter my dash')
          $('#my_dash').css('display', 'block');
          $('#coll_7').removeClass('collapsed');
          $('#My-Dashboard').addClass('show');
        }
        if (urls == 'register-student') {
          // console.log('enterprofile')
          $('#reg_student').css('display', 'block');
          $('#coll_8').removeClass('collapsed');
          $('#Register-Student').addClass('show');
        }
      }
    }else{
      if ((localStorage.getItem("loginhelp") == '1') || (localStorage.getItem("starthelp") == '1')) {
        $('#tabcontent').css('display', '');
      }else{
          $('#tabcontent').css('display', 'none');
      }
     
    
    }

    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    // var log=this.logdata.replace('"','');
    // var datalog=log.replace('"','');
    console.log('logdata')
    console.log(this.logdata)
    if (this.logdata) {
      localStorage.setItem('loginhelp', JSON.stringify(''));
      localStorage.setItem('starthelp', JSON.stringify(''));
      // alert(this.logdata.class )
      if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
        $('#tabcontent').css('display', '');
        $('#reg_tab').css('display', 'block');
        $('#reg_tab').addClass('active');
        $('#reg_student').css('display', 'block');
        $('#family_tab').css('display', 'block');
        $('#dash_tab').css('display', 'block');
        $('#admin_support_tab').css('display', 'block');
        $('#abt_sftw').css('display', 'block');
      }
      if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
        $('#tabcontent').css('display', '');
        $('#abt_sftw').css('display', 'block');
        $('#settings-s').css('display', 'block');

      }

    }
    if (this.logdata) {
      if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
        $('.unsubs').css('display', 'none');
      }
    } else {
      $('#feedback').css('display', 'none');
      $('.unsubs').css('display', 'none');
    }
    if (localStorage.getItem('loginData') !== null) {
      if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
        $('#guardian_faq').css('display', 'none');
        // block
        // $('#user_side').css('display', 'block');
        // $('#user_head').css('display', 'block');
      }
      if ((this.logdata.class == 'teacher')) {
        // $('#teacher_side').css('display', 'block');
        // $('#teacher_head').css('display', 'block');
      }
      // (this.logdata.class == 'admin') || 
      if ((this.logdata.class == 'executive 1') || (this.logdata.class == 'executive 2') || (this.logdata.class == 'teacher')) {
        {
          // $('#tabcontent').css('display', 'none');
          // $('#admin_side').css('display', 'block');
          // $('#admin_head').css('display', 'block');
        }
      }

    }




  }
  goBack() {
    window.history.back();
  }
  clear_data() {
    $('#reg_student').css('display', '');
  }
}
