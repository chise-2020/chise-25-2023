import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-video-training',
  templateUrl: './video-training.component.html',
  styleUrls: ['./video-training.component.css']
})
export class VideoTrainingComponent implements OnInit {
  url = this.api.geturl();
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $(document).ready(function () {
      $('.hide').hide();
      $('this').hide();
    })
    $(function () {                       //run when the DOM is ready
      $(".card-folder").click(function () {  //use a class, since your ID gets mangled
        $(this).parent().parent().addClass("hide");      //add the class to the clicked element
      });
    });

    $(document).ready(function () {
      $('.back-folder').click(function () {  //use a class, since your ID gets mangled
        $(".folder").removeClass("hide");
        $(".vide-tutorials").css("display", "none");
        $('.folder').css('display', '');
      });
    })
    $(".tab1").click(function () {
      $(this).children().addClass("ac-active");
      $(".tab2").children().removeClass("ac-active");
      $("#faq").show();
      $("#training").hide();
    });
    $(".tab2").click(function () {
      $("#faq").hide();
      $("#training").show();
      $(this).children().addClass("ac-active");
      $(".tab1> .card-main-faq").removeClass("ac-active");

    });

    $(".sideways li").click(function () {
      $(this).addClass('active').siblings().removeClass('active');

    });
    $(document).ready(function () {

      // Gets the video src from the data-src on each button

      var $videoSrc;
      $('.video-btn').click(function () {
        $videoSrc = $(this).data("src");
      });
      console.log($videoSrc);
      // when the modal is opened autoplay it  
      $('#myModal').on('shown.bs.modal', function (e) {

        // set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
        $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
      })
      // stop playing the youtube video when I close the modal
      $('#myModal').on('hide.bs.modal', function (e) {
        // a poor man's stop video
        $("#video").attr('src', $videoSrc);
      })

      // document ready  
    });
  }
  show(job) {
    $('.hide').hide();
    $('.' + job).show();
    $('.folder').css('display', 'none');
  }
}
