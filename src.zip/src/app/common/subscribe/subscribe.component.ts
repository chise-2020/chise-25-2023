import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit {
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm();
  }
  url = this.api.geturl();
  form: FormGroup;
  fname = false
  lname = false
  uname = false
  email = false
  terms = false

  ngOnInit(): void {
    $('#feedback').css('display', 'none');
    $('.unsubs').css('display', 'none');
    $('#cnt_us').css('display', 'block');
    $("#fname").focus();
    localStorage.setItem('contact_click', JSON.stringify('0'));
    localStorage.setItem('loginhelp', JSON.stringify(''));
    localStorage.setItem('starthelp', JSON.stringify(''));
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
  }



  createForm() {
    this.form = this.fb.group({
      date: new FormControl('', [Validators.required,]),
      fname: new FormControl('', [Validators.required,]),
      lname: new FormControl('', [Validators.required,]),
      uname: new FormControl('', [Validators.required,]),
      email: new FormControl('', [Validators.required, Validators.pattern('^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]+$')]),
      terms: new FormControl('', [Validators.required,]),
    });
  }

  submit() {
    this.formValidation()
    if (this.fname == true || this.lname == true || this.uname == true || this.email == true || this.terms == true) {
      return;
    }
    var dt = new Date();
    var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    this.form.get('date').setValue(time);

    $('.pageloader').show();
    this.http.post<any>(`${this.url}/subsribe`, this.form.value).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == true) {
        localStorage.setItem('logid', JSON.stringify(data.userid));
        localStorage.setItem('loginData', JSON.stringify(data.user));
        console.log(data.user)
        console.log('sub_over')
        // this.router.navigate(['review-profile/']);
        $('#overlaysuccessbtn').trigger('click');
      }else if(data.status == 'false'){
        $('#successbtn').trigger('click');
        $('#alert_title').html('<img src="assets/images/block.svg">SIGNUP');
        $('#alert_text').html(data.message);
      } else {
        $('#alertbtn').trigger('click');
        $('#alerttitle').html('<img src="assets/images/block.svg">SIGNUP');
        $('#alerttext').html(data.message);
      }
    }, err => {
      $('.pageloader').hide();
    })

  }

  mark(e) {
    if(e.target.checked){    
      $('#terms').removeClass('error');
      $('#terms_span').removeClass('error'); 
      this.terms = false   
    }else
    {
      $('#terms').addClass('error');
    $('#terms_span').addClass('error');
    this.terms = true

    }
 }

  formValidation() {
    if($("#terms").prop('checked') == true){
      // alert('checked')
      $('#terms').removeClass('error');
      $('#terms_span').removeClass('error');
      this.terms = false
  }else{
    // alert('not checked')
    $('#terms').addClass('error');
    $('#terms_span').addClass('error');
    this.terms = true
  }
    if (($('#fname').val())) {
      $('#fname').removeClass('error');
      this.fname = false
    } else {
      $('#fname').addClass('error');
      this.fname = true
    }
    if (($('#lname').val())) {
      $('#lname').removeClass('error');
      this.lname = false
    } else {
      $('#lname').addClass('error');
      this.lname = true
    }

    if (!($('#uname').val())) {
      $('#uname').addClass('error');
      this.uname = true;
    } else {
      if ((($('#uname').hasClass('error')) == true)) {
        $('#uname').addClass('error');
        this.uname = true;
      } else {
        this.uname = false;
        $('#uname').removeClass('error');
      }
    }
    if (($('#email').val())) {
      var regEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      var isValidEmail = regEx.test(this.form.value.email)
      if (isValidEmail == false) {
        this.email = true
        $('#email').addClass("error");
      } else {
        this.email = false
        $('#email').removeClass("error");
      }
    } else {
      this.email = true
      $('#email').addClass("error");
    }
  }


  change() {
    $('#uname').val($('#uname').val().replace(/[^a-z0-9]/gi, ''));
    if (($('#uname').val().length < 6) || ($('#uname').val().length > 6)) {

      $('#uname').addClass('error');
      this.uname = true
    } else {
      var reg_Ex = /^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
      var isValiduname = reg_Ex.test($('#uname').val())
      if (isValiduname == false) {
        this.uname = true
        $('#uname').addClass("error");
      } else {
        this.uname = false
      }
    }
  }
}
