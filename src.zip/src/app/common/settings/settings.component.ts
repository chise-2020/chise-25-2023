import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  url = this.api.geturl();
  isChecked: false;
  logdata: any = [];
  email_automatic: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {

  }

  ngOnInit(): void {
    localStorage.setItem('online_reg', JSON.stringify(''));
    $('.sdebar').css('display', 'none');
    $('#nnext').css('display', 'none');
    

    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    console.log(this.logdata.email);
if ((this.logdata.class == 'guardian 1') || (this.logdata.class == 'alumnus')  || (this.logdata.class == 'guardian 2') || (this.logdata.class == 'student 2')) {
  $('.admins').css('display', 'none');
}
if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") || (this.logdata.class == "teacher")) {
  $('.users').css('display', 'none');       
}
  }

  send_mail_setting() {
    $('#cnfrmtitle').html('<img src="assets/images/alert.svg">SEND EMAIL AUTOMATICALLY');
    $('#regbutton').trigger('click');
    if($('#c_current').prop("checked") == true) {
      $('#modelcontent').html('With this selected switch position, the system will automatically send all ChiS&E Login email notifications.<br><br>Are you sure of this?');
    }
    else if($('#c_current').prop("checked") == false) {
      $('#modelcontent').html('With this selected switch position, the system will send all ChiS&E Login email notifications manually.<br><br>Are you sure of this?');
    }
    
    $('#cnfrm_mail').css('display', 'block');
    $('#cnfrm_reg').css('display', 'none');
  }
  
}