import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoSchoolcourseComponent } from './admin-schoolinfo-schoolcourse.component';

describe('AdminSchoolinfoSchoolcourseComponent', () => {
  let component: AdminSchoolinfoSchoolcourseComponent;
  let fixture: ComponentFixture<AdminSchoolinfoSchoolcourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoSchoolcourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoSchoolcourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
