import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-student-internships',
  templateUrl: './student-internships.component.html',
  styleUrls: ['./student-internships.component.css']
})
export class StudentInternshipsComponent implements OnInit {
  url = this.api.geturl();
  UserData: any;
  intern_list: any = [];
  cumulative=0;
  cumulative1=0;
  exe=0;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
 
  }
  ngOnInit(): void {
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    this.getinternships();
    if(this.UserData.class!='admin')
    {
      this.exe =1;
      
    }
    
  }
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
  getinternships(){
    var type={
      user_id:'',
      admin_list:'1'
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/student_internship`,type).subscribe(data => {
      $('.pageloader').hide();
      this.intern_list=data.intern_list;
      this.cumulative=data.intern_list.length;
      this.cumulative1=data.intern_list.length;
    }, err => {
      $('.pageloader').hide();
    });
  }
  search(){
    var type={
      user_id:'',
      admin_list:'1'
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/student_internship`,type).subscribe(data => {
      $('.pageloader').hide();
      this.intern_list=data.intern_list;
      this.cumulative1=data.intern_list.length;
    }, err => {
      $('.pageloader').hide();
    });
  }
  approve(approve_id,internid){
    var type={
      approve_status:approve_id,
      internship_id:internid
    };
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/internship_approval`,type).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        //this.oldPassword= true
        $('#new-pop').trigger('click');
        $('#new_pop_text').html('<img src="assets/images/block.svg">Student Internships');
        $('#new_pop_html').html(data.message);
      }
      else if (data.status == true) {
  
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Student Internships');
        $('#errortext').html(data.message);
      }
    }, err => {
      $('.pageloader').hide();
    });
  }
}
