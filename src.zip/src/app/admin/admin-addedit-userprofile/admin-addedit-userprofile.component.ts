import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-admin-addedit-userprofile',
  templateUrl: './admin-addedit-userprofile.component.html',
  styleUrls: ['./admin-addedit-userprofile.component.css']
})
export class AdminAddeditUserprofileComponent implements OnInit {
  logdata: any;
  logindata: any;
  res: any;
  form: FormGroup;
  fakeArray: any;
  saved_text: any;
  url = this.api.geturl();
  error = false;
  first_nameg1 = false; last_nameg1 = false; usernameg1 = false; emailg1 = false; addressg1 = false; cityg1 = false; stateg1 = false; zipg1 = false; phoneg1 = false; veterang1 = false;
  first_nameg2 = false; last_nameg2 = false; usernameg2 = false; emailg2 = false; addressg2 = false; cityg2 = false; stateg2 = false; zipg2 = false; phoneg2 = false; veterang2 = false;


  first_name1 = false; last_name1 = false; username1 = false; email1 = false; address1 = false; city1 = false; state1 = false; zip1 = false; phone1 = false;
  first_name2 = false; last_name2 = false; username2 = false; email2 = false; address2 = false; city2 = false; state2 = false; zip2 = false; phone2 = false;
  first_name3 = false; last_name3 = false; username3 = false; email3 = false; address3 = false; city3 = false; state3 = false; zip3 = false; phone3 = false;
  first_name4 = false; last_name4 = false; username4 = false; email4 = false; address4 = false; city4 = false; state4 = false; zip4 = false; phone4 = false;
  first_name5 = false; last_name5 = false; username5 = false; email5 = false; address5 = false; city5 = false; state5 = false; zip5 = false; phone5 = false;
  first_name6 = false; last_name6 = false; username6 = false; email6 = false; address6 = false; city6 = false; state6 = false; zip6 = false; phone6 = false;

  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {
    this.createForm();
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('select').on('change', function () {
      $(this).removeClass("error");
    });

    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('.clearerr').click(function () {
      $('.form-control').removeClass('error');
    });

    // $('.yourphone2').usPhoneFormat({
    //   format: '(xxx) xxx-xxxx',
    // });
    $('#c1').trigger('click');
    $('#s1').trigger('click');
    $('.sdebar').css('display', 'none');
    $('#e3').show();
    $('#e3').closest('a').addClass('active');

    this.logindata = JSON.parse(localStorage.getItem('loginData'));
    this.logdata = JSON.parse(localStorage.getItem('set_userprofile'));
    console.log(this.logdata)
    console.log('session data')
    if (this.logdata.access_level == 'STUDENT 2') {
      $('#student_count').css('display', 'none');
      $('.grdp').css('pointer-events', 'none');
      $('.grdp').addClass('textback');
      $('.grdpsave').addClass('disabled-button');
      $('.grdpsave').css('pointer-events', 'none');
      $('.grdpsave').addClass('textback');

      $('.grdp2').css('pointer-events', 'none');
      $('.grdp2').addClass('textback');
      $('.grdpsave2').addClass('disabled-button');
      $('.grdpsave2').css('pointer-events', 'none');
      $('.grdpsave2').addClass('textback');
    }
    if (this.logdata.access_level == 'GUARDIAN 2') {
      $('.student_count').css('pointer-events', 'none');
      $('.student_count').addClass('textback');
      $('#student_count_btn').css('display', 'none');
      $('.student_count_btn').css('pointer-events', 'none');

      $('.grdp').css('pointer-events', 'none');
      $('.grdp').addClass('textback');
      $('.grdpsave').addClass('disabled-button');
      $('.grdpsave').css('pointer-events', 'none');
    }
    var dt = new Date();
    var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    this.form.get('date').setValue(time);
    this.form.get('user_id').setValue(this.logdata.user_id);
    if (localStorage.getItem('loginData') !== null)
      this.getUser()
    this.getdate()

    $('.e3').css('display', 'block');
    
  }
  keypress_func() {
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
  }
  username_change(id) {
    // alert(id)
    if (($('#username' + id).val())) {
      $('#username' + id).val($('#username' + id).val().replace(/[^a-z0-9]/gi, ''));
      if (($('#username' + id).val().length < 6) || ($('#username' + id).val().length > 6)) {
        // console.log('enter')
        $('#username' + id).addClass('error');
        this.error = true;
      } else {
        var reg_Ex = /^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
        var isValiduname = reg_Ex.test($('#username' + id).val())
        if (isValiduname == false) {
          this.error = true
          $('#username' + id).addClass("error");
        } else {
          this.error = false
          $('#username' + id).removeClass('error');
        }
        // $('#username' + id).removeClass('error');
        // this.error = false;
      }
    } else {
      $('#username' + id).removeClass('error');
      this.error = false;
    }
  }
  username_changes(id) {
    if (($('#usernameg' + id).val())) {
      // for guardian validation
      $('#usernameg' + id).val($('#usernameg' + id).val().replace(/[^a-z0-9]/gi, ''));

      if (($('#usernameg' + id).val().length < 6) || ($('#usernameg' + id).val().length > 6)) {

        $('#usernameg' + id).addClass('error');
        this.error = true;
      } else {
        var reg_Ex = /^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
        var isValiduname = reg_Ex.test($('#usernameg' + id).val())
        if (isValiduname == false) {
          this.error = true
          $('#usernameg' + id).addClass("error");
        } else {
          this.error = false
          $('#usernameg' + id).removeClass('error');
        }
        // $('#username' + id).removeClass('error');
        // this.error = false;
      }
    } else {
      $('#usernameg' + id).removeClass('error');
      this.error = false;
    }
  }
  change(id) {
    var inputVal = ($('#phone' + id).val());
    // $('#phone' + id).replace(/[^0-9\.]/g,'');
    var regExp = /[a-zA-Z]/g;
    if (regExp.test(inputVal)) {
      //letters found
      $('#phone' + id).addClass('error');
      this.error = true;
    } else {
      $('#phone' + id).removeClass('error');
      this.error = false;
    }

    $('#phone' + id).val($('#phone' + id).val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));
  }
  changes(id) {
    //guardian validation
    var inputVal = ($('#phoneg' + id).val());
    // $('#phone' + id).replace(/[^0-9\.]/g,'');
    var regExp = /[a-zA-Z]/g;
    if (regExp.test(inputVal)) {
      //letters found
      $('#phoneg' + id).addClass('error');
      this.error = true;
    } else {
      $('#phoneg' + id).removeClass('error');
      this.error = false;
    }

    $('#phoneg' + id).val($('#phoneg' + id).val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));



  }
  save_user(id) {
    if (($('#phone' + id).hasClass('error')) == true) {
      this.error = true;
    } else {
      this.error = false;
    }
    if (($('#username' + id).hasClass('error')) == true) {
      this.error = true;
    } else {
      this.error = false;
    }
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if ((($('#phone' + id).hasClass('error')) == true) || (($('#username' + id).hasClass('error')) == true)) {
      if ((($('#phone' + id).hasClass('error')) == true))
        $('#phone' + id).addClass('error');

      if ((($('#username' + id).hasClass('error')) == true))
        $('#username' + id).addClass('error');
    } else {
      $(".form-control").removeClass('error');
    }
    var t = id;
    var val1 = "first_name" + t;
    var val2 = "last_name" + t;
    var val3 = "username" + t;
    var val4 = "email" + t;
    var val5 = "address" + t;
    var val6 = "city" + t;
    var val7 = "state" + t;
    var val8 = "zip" + t;
    var val9 = "phone" + t;
    var val10 = "veteran" + t;
    var val11 = "id" + t;
    var val12 = "userclass" + t;
    var val20 = "auth" + t;
    // alert($('#'+val6).val())
    if (!($('#' + val1).val())) {
      $('#' + val1).addClass('error');
      this.error = true;
    }
    if (!($('#' + val2).val())) {
      $('#' + val2).addClass('error');
      this.error = true;
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val3).val())) {
        $('#' + val3).addClass('error');
        this.error = true;
      } else {
        if (($('#' + val3).hasClass('error')) == true) {
          this.error = true;
        } else {
          this.error = false;
        }
      }
    }

   
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val4).val())) {
        $('#' + val4).addClass('error');
        this.error = true;
      }
    } else {
      if (($('#' + val3).val())) {
        if (!($('#' + val4).val())) {
          $('#' + val4).addClass('error');
          this.error = true;
        }
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!regex.test($('#' + val4).val())) {
        $('#' + val4).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val5).val())) {
        $('#' + val5).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val6).val())) {
        $('#' + val6).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val7).val())) {
        $('#' + val7).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val8).val())) {
        $('#' + val8).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val9).val())) {
        $('#' + val9).addClass('error');
        this.error = true;
      }
    } else {
      if (($('#' + val3).val())) {
        if (!($('#' + val9).val())) {
          $('#' + val9).addClass('error');
          this.error = true;
        }
      }
    }
    if ($('#' + val9).val()) {
      // alert($('#' + val9).val().length)
      if (($('#' + val9).val().length) < 14) {
        $('#' + val9).addClass('error');
        this.error = true;
      }
    }
    if ((id == 'g1') || (id == 'g2')) {
      if (!($('#' + val10).val())) {
        $('#' + val10).addClass('error');
        this.error = true;
      }
    }
    // alert(this.error)
    if (this.error == false) {
      var user_id = {
        user_id: this.logdata.user_id,
        family_code: this.logdata.family_code,
        first_name: $('#' + val1).val(),
        last_name: $('#' + val2).val(),
        username: $('#' + val3).val(),
        email: $('#' + val4).val(),
        address: $('#' + val5).val(),
        city: $('#' + val6).val(),
        state: $('#' + val7).val(),
        zip_code: $('#' + val8).val(),
        phone: $('#' + val9).val(),
        Veteran: $('#' + val10).val(),
        id: $('#' + val11).val(),
        user_class: $('#' + val12).val(),
        date: $('#date').val(),
        authorize: $('#' + val20).val(),
      }
      localStorage.setItem('student_item', JSON.stringify(user_id));
      $('#family_name').html($('#' + val1).val() + ' ' + $('#' + val2).val());
      $('#family_username').html($('#' + val3).val());
      $('#family_email').html($('#' + val4).val());
      $('#family_phone').html($('#' + val9).val());
      $('#f_add').html($('#' + val5).val());
      $('#f_city').html($('#' + val6).val());
      $('#f_state').html($('#' + val7).val());
      $('#f_zip').html($('#' + val8).val());
      $('#f_veteran').html($('#' + val10).val());
      $('#family_auth').html($('#' + val20).val());
      $('#family_btn').trigger('click');
      if (id == 'g1') {
        $('#family_title').html('<i class="fa fa-user" aria-hidden="true"></i>Guardian 1');
        $('#family_address').css('display', '');
        $('#family_city').css('display', '');
        $('#family_state').css('display', '');
        $('#family_zip').css('display', '');
        $('#family_veteran').css('display', '');
        $('#f_auth').css('display', '');
        $('#u_astrerix').css('display', '');
        $('#e_astrerix').css('display', '');
        $('#p_astrerix').css('display', '');
      }
      else if (id == 'g2') {
        $('#family_title').html('<i class="fa fa-user" aria-hidden="true"></i>Guardian 2');
        $('#family_address').css('display', '');
        $('#family_city').css('display', '');
        $('#family_state').css('display', '');
        $('#family_zip').css('display', '');
        $('#family_veteran').css('display', '');
        $('#f_auth').css('display', '');
        $('#u_astrerix').css('display', '');
        $('#e_astrerix').css('display', '');
        $('#p_astrerix').css('display', '');
      } else {
        $('#family_title').html('<i class="fa fa-user" aria-hidden="true"></i>Student ' + id);
        $('#family_address').css('display', 'none');
        $('#family_city').css('display', 'none');
        $('#family_state').css('display', 'none');
        $('#family_zip').css('display', 'none');
        $('#family_veteran').css('display', 'none');
        $('#f_auth').css('display', 'none');
        $('#u_astrerix').css('display', 'none');
        $('#e_astrerix').css('display', 'none');
        $('#p_astrerix').css('display', 'none');
      }
      // $('.pageloader').show();
      // var path = localStorage.setItem('set_editpath', JSON.stringify('user_profile'));
      // this.http.post<any>(`${this.url}/update_user_profile`, user_id).subscribe(data => {
      //   $('.pageloader').hide();
      //   $('#error-disp-btn').trigger('click');
      //   $('#modal_pass').html('<img src="assets/images/alert.svg">Family Profile');
      //   $('#errortext').html('Successfully updated profile');


      // }, err => {
      //   $('.pageloader').hide();
      // })

    }

  }


  getdate() {
    var user_id = {
      user_id: this.logindata.user_id,
      type: "profile"
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_last_update`, user_id).subscribe(data => {
      $('.pageloader').hide();
      this.saved_text = data.saved_text;

    }, err => {
      $('.pageloader').hide();
    })

  }

  getUser() {
    var user_id = {
      user_id: this.logdata.user_id,
      family_code: this.logdata.family_code
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/user_profile`, user_id).subscribe(data => {
      $('.pageloader').hide();
      this.fakeArray = Array(parseInt(data.student_count)); // [0,1,2,3,4]
      var std = data.student_count;
      $('#dynamictitle').html('<img src="assets/images/alert.svg"> Family PROFILE');
      $('#review').html(data.html);

      if (data.results.students != '') {
        for (let i = 0; i <= std; i++) {

          if (data.results.students[i]) {

            var t = i + 1;
            if ((data.results.students[i].username != null)) {
              this.form.controls['username' + t].disable();
            }
            if (this.logdata.access_level == 'STUDENT 2') {
              // console.log('enter')
              // console.log(this.logdata.user_id)
              if (data.results.students[i].id != this.logdata.user_id) {
                //if log.user_id and this id is not same its not their record, thus it can't be edited
                this.form.controls['first_name' + t].disable();
                this.form.controls['last_name' + t].disable();
                this.form.controls['email' + t].disable();
                this.form.controls['phone' + t].disable();
                this.form.controls['zip' + t].disable();
                this.form.controls['veteran' + t].disable();
                this.form.controls['city' + t].disable();
                this.form.controls['state' + t].disable();
                this.form.controls['username' + t].disable();
              }
            }
            if (this.logdata.access_level == 'GUARDIAN 2') {
              this.form.controls['first_name' + t].disable();
              this.form.controls['last_name' + t].disable();
              this.form.controls['username' + t].disable();
              this.form.controls['email' + t].disable();
              this.form.controls['phone' + t].disable();
              this.form.controls['zip' + t].disable();
              this.form.controls['veteran' + t].disable();
              this.form.controls['city' + t].disable();
              this.form.controls['state' + t].disable();
            }
            this.form.get('id' + t).setValue(data.results.students[i].id);
            this.form.get('first_name' + t).setValue(data.results.students[i].first_name);
            this.form.get('last_name' + t).setValue(data.results.students[i].last_name);
            this.form.get('username' + t).setValue(data.results.students[i].username);
            this.form.get('email' + t).setValue(data.results.students[i].email);
            this.form.get('address' + t).setValue(data.results.students[i].street);
            this.form.get('city' + t).setValue(data.results.students[i].city);
            this.form.get('state' + t).setValue(data.results.students[i].state);
            this.form.get('zip' + t).setValue(data.results.students[i].zip_code);
            this.form.get('phone' + t).setValue(data.results.students[i].phone);
            this.form.get('veteran' + t).setValue(data.results.students[i].Veteran);


          }
        }
      }

      if (data.results.guardians != '') {
        for (let i = 0; i <= 1; i++) {

          if (data.results.guardians[i]) {
            var m = i + 1;

            if (data.results.guardians[i].username != '') {
              $('#usernameg' + m).css('pointer-events', 'none');
              $('#usernameg' + m).addClass('textback');
            }

            // $('#gurard' + m).html(data.results.guardians[i].first_name + ' ' + data.results.guardians[i].last_name);
            this.form.get('authg' + m).setValue(data.results.guardians[i].authorize);
            this.form.get('idg' + m).setValue(data.results.guardians[i].id);
            this.form.get('first_nameg' + m).setValue(data.results.guardians[i].first_name);
            this.form.get('last_nameg' + m).setValue(data.results.guardians[i].last_name);
            this.form.get('usernameg' + m).setValue(data.results.guardians[i].username);
            this.form.get('emailg' + m).setValue(data.results.guardians[i].email);
            this.form.get('addressg' + m).setValue(data.results.guardians[i].street);
            this.form.get('cityg' + m).setValue(data.results.guardians[i].city);
            this.form.get('stateg' + m).setValue(data.results.guardians[i].state);
            this.form.get('zipg' + m).setValue(data.results.guardians[i].zip_code);
            this.form.get('phoneg' + m).setValue(data.results.guardians[i].phone);

            if (data.results.guardians[i].city)
              this.form.get('cityg' + m).setValue(data.results.guardians[i].city);
            else
              this.form.get('cityg' + m).setValue('Chicago');

            if (data.results.guardians[i].state)
              this.form.get('stateg' + m).setValue(data.results.guardians[i].state);
            else
              this.form.get('stateg' + m).setValue('IL');

            if (data.results.guardians[i].Veteran)
              this.form.get('veterang' + m).setValue(data.results.guardians[i].Veteran);
            else
              this.form.get('veterang' + m).setValue('No');//setting default as no

            if (data.results.guardians[i].authorize)
              this.form.get('authg' + m).setValue(data.results.guardians[i].authorize);
            else
              this.form.get('authg' + m).setValue('No');//setting default as no

          } else {
            var m = i + 1;
            this.form.get('cityg' + m).setValue('Chicago');
            this.form.get('stateg' + m).setValue('IL');
            this.form.get('veterang' + m).setValue('No');
            this.form.get('authg' + m).setValue('No');
          }

        }
      } else {
        for (let h = 0; h <= 1; h++) {
          var s = h + 1;
          this.form.get('cityg' + s).setValue('Chicago');
          this.form.get('stateg' + s).setValue('IL');
          this.form.get('authg' + m).setValue('No');
        }
      }


    }, err => {
      $('.pageloader').hide();
    })

  }



  createForm() {

    this.form = this.fb.group({
      date: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
      //  ***parent 1 form****
      first_nameg1: new FormControl('', [Validators.required,]),
      last_nameg1: new FormControl('', [Validators.required,]),
      usernameg1: new FormControl('', [Validators.required,]),
      emailg1: new FormControl('', [Validators.required,]),
      addressg1: new FormControl('', [Validators.required,]),
      cityg1: new FormControl('', [Validators.required,]),
      stateg1: new FormControl('', [Validators.required,]),
      zipg1: new FormControl('', [Validators.required,]),
      phoneg1: new FormControl('', [Validators.required,]),
      veterang1: new FormControl('', [Validators.required,]),
      idg1: new FormControl('', [Validators.required,]),
      authg1: new FormControl('', [Validators.required,]),

      //  ***parent 2 form****
      first_nameg2: new FormControl('', [Validators.required,]),
      last_nameg2: new FormControl('', [Validators.required,]),
      usernameg2: new FormControl('', [Validators.required,]),
      emailg2: new FormControl('', [Validators.required,]),
      addressg2: new FormControl('', [Validators.required,]),
      cityg2: new FormControl('', [Validators.required,]),
      stateg2: new FormControl('', [Validators.required,]),
      zipg2: new FormControl('', [Validators.required,]),
      phoneg2: new FormControl('', [Validators.required,]),
      veterang2: new FormControl('', [Validators.required,]),
      idg2: new FormControl('', [Validators.required,]),
      authg2: new FormControl('', [Validators.required,]),
      //  ***student 1 form****
      first_name1: new FormControl('', [Validators.required,]),
      last_name1: new FormControl('', [Validators.required,]),
      username1: new FormControl('', [Validators.required,]),
      email1: new FormControl('', [Validators.required,]),
      address1: new FormControl('', [Validators.required,]),
      city1: new FormControl('', [Validators.required,]),
      state1: new FormControl('', [Validators.required,]),
      zip1: new FormControl('', [Validators.required,]),
      phone1: new FormControl('', [Validators.required,]),
      veteran1: new FormControl('', [Validators.required,]),
      id1: new FormControl('', [Validators.required,]),
      //  ***student 2 form****
      first_name2: new FormControl('', [Validators.required,]),
      last_name2: new FormControl('', [Validators.required,]),
      username2: new FormControl('', [Validators.required,]),
      email2: new FormControl('', [Validators.required,]),
      address2: new FormControl('', [Validators.required,]),
      city2: new FormControl('', [Validators.required,]),
      state2: new FormControl('', [Validators.required,]),
      zip2: new FormControl('', [Validators.required,]),
      phone2: new FormControl('', [Validators.required,]),
      veteran2: new FormControl('', [Validators.required,]),
      id2: new FormControl('', [Validators.required,]),
      //  ***student 3 form****
      first_name3: new FormControl('', [Validators.required,]),
      last_name3: new FormControl('', [Validators.required,]),
      username3: new FormControl('', [Validators.required,]),
      email3: new FormControl('', [Validators.required,]),
      address3: new FormControl('', [Validators.required,]),
      city3: new FormControl('', [Validators.required,]),
      state3: new FormControl('', [Validators.required,]),
      zip3: new FormControl('', [Validators.required,]),
      phone3: new FormControl('', [Validators.required,]),
      veteran3: new FormControl('', [Validators.required,]),
      id3: new FormControl('', [Validators.required,]),
      //  ***student 4 form****
      first_name4: new FormControl('', [Validators.required,]),
      last_name4: new FormControl('', [Validators.required,]),
      username4: new FormControl('', [Validators.required,]),
      email4: new FormControl('', [Validators.required,]),
      address4: new FormControl('', [Validators.required,]),
      city4: new FormControl('', [Validators.required,]),
      state4: new FormControl('', [Validators.required,]),
      zip4: new FormControl('', [Validators.required,]),
      phone4: new FormControl('', [Validators.required,]),
      veteran4: new FormControl('', [Validators.required,]),
      id4: new FormControl('', [Validators.required,]),
      //  ***student 5 form****
      first_name5: new FormControl('', [Validators.required,]),
      last_name5: new FormControl('', [Validators.required,]),
      username5: new FormControl('', [Validators.required,]),
      email5: new FormControl('', [Validators.required,]),
      address5: new FormControl('', [Validators.required,]),
      city5: new FormControl('', [Validators.required,]),
      state5: new FormControl('', [Validators.required,]),
      zip5: new FormControl('', [Validators.required,]),
      phone5: new FormControl('', [Validators.required,]),
      veteran5: new FormControl('', [Validators.required,]),
      id5: new FormControl('', [Validators.required,]),
      //  ***student 6 form****
      first_name6: new FormControl('', [Validators.required,]),
      last_name6: new FormControl('', [Validators.required,]),
      username6: new FormControl('', [Validators.required,]),
      email6: new FormControl('', [Validators.required,]),
      address6: new FormControl('', [Validators.required,]),
      city6: new FormControl('', [Validators.required,]),
      state6: new FormControl('', [Validators.required,]),
      zip6: new FormControl('', [Validators.required,]),
      phone6: new FormControl('', [Validators.required,]),
      veteran6: new FormControl('', [Validators.required,]),
      id6: new FormControl('', [Validators.required,]),

    });
  }

}
