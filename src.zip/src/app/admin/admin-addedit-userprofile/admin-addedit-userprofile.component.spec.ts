import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddeditUserprofileComponent } from './admin-addedit-userprofile.component';

describe('AdminAddeditUserprofileComponent', () => {
  let component: AdminAddeditUserprofileComponent;
  let fixture: ComponentFixture<AdminAddeditUserprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddeditUserprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddeditUserprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
