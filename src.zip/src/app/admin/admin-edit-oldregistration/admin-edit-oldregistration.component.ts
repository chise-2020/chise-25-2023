import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

declare var $: any;
@Component({
  selector: 'app-admin-edit-oldregistration',
  templateUrl: './admin-edit-oldregistration.component.html',
  styleUrls: ['./admin-edit-oldregistration.component.css']
})
export class AdminEditOldregistrationComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  olddata: any = [];
  form: FormGroup;//initializing form
  guardian_1 = false
  update_id = false
  student_name = false
  academic_term=false
  academic_year=false
  error = false
  novalue = null;
  novalue1 = null;
  grades : any = [];
  modules : any = [];
  selected :any=[];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    // this.getlists();
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
    this.olddata = JSON.parse(localStorage.getItem('set_edit_oldreg'));
    
    $('#c4').trigger('click');
    $('#mergemenu').addClass('active');
      $('#e17').css('display', 'block');
      $('#e17').closest('a').addClass('active');
      $('#headdyn').html("Edit Old Registration Records");
      console.log(this.olddata)
      this.form.get('update_id').setValue(this.olddata.id);
      this.form.get('guardian_1').setValue(this.olddata.parent_name);
      this.form.get('guardian_2').setValue(this.olddata.parent2_name);
      this.form.get('student_name').setValue(this.olddata.full_names);
      this.form.get('academic_term').setValue(this.olddata.academic_term);
      this.form.get('academic_year').setValue(this.olddata.academic_year);
      
    
  }


//   getlists(){
//     var user_id = {
//       user_id : '',
//     }
//    $('.pageloader').show();
//      this.http.post<any>(`${this.url}/drop_lists`,  user_id   ).subscribe(data => {
//       $('.pageloader').hide();
//       this.grades = data.grade
//       this.modules =  data.modules
//     }, err => {
//       $('.pageloader').hide();
//     })
 
// }

  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      guardian_1: new FormControl('', [Validators.required,]),
      guardian_2: new FormControl('', [Validators.required,]),
      student_name: new FormControl('', [Validators.required,]),
      academic_term: new FormControl('', [Validators.required,]),
      academic_year: new FormControl('', [Validators.required,]),
     
    });
  }
  //
  //submitting function
  submit() {
    var path=localStorage.setItem('set_editpath', JSON.stringify('merge_unmerge'));
    
    this.error=this.guardian_1 = this.student_name = this.academic_term = this.academic_year = false;
    if (this.form.getRawValue().guardian_1 == '')
    {
      this.guardian_1 = true
      this.error=true
    }
    if (this.form.getRawValue().student_name == '')
    {
      this.student_name = true
      this.error=true
    }
    if (this.form.getRawValue().academic_term == '')
    {
      this.academic_term = true
      this.error=true
    }
    if (this.form.getRawValue().academic_year == '')
    {
      this.academic_year = true
      this.error=true
    }
    
    

      if (this.error == false) {
        var value = this.form.getRawValue()
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_merge`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg">OLD REGISTRATION RECORD');
            $('#errortext').html(data.message);
            localStorage.setItem('set_edit_oldreg', JSON.stringify(''));
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">OLD REGISTRATION RECORD');
            $('#errortext').html(data.message);
            localStorage.setItem('set_edit_oldreg', JSON.stringify(''));
          }
        }, err => {
          $('.pageloader').hide();
        })
      }
  }
  //

}
