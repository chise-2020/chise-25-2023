import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEditOldregistrationComponent } from './admin-edit-oldregistration.component';

describe('AdminEditOldregistrationComponent', () => {
  let component: AdminEditOldregistrationComponent;
  let fixture: ComponentFixture<AdminEditOldregistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminEditOldregistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEditOldregistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
