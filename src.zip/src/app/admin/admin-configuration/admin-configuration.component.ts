import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
declare var $: any;
//to define $
@Component({
  selector: 'app-admin-configuration',
  templateUrl: './admin-configuration.component.html',
  styleUrls: ['./admin-configuration.component.css']
})
export class AdminConfigurationComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  configdata: any = [];
  form: FormGroup;//initializing form
  first_name = false
  last_name = false
  update_id = false
  email = false
  username = false
  user_class=false
  path:any;
  error = false;
  localdata: any;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {

    $('#dropdownMenu12').addClass('active');// menu highlight

    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('.sdebar').css('display','none');
    this.localdata = JSON.parse(localStorage.getItem('loginData'));
    this.configdata = JSON.parse(localStorage.getItem('set_subscribeduser'));
    console.log(this.configdata)
  if (this.configdata.length==0) {
    $('#add_1').addClass('active');
      localStorage.setItem('set_editpath', JSON.stringify(''));
      $('#c3').trigger('click');
      $('#headdyn').html("Add User & Configure Class ");
    } else {
      $('#c1').trigger('click');
      $('#s1').trigger('click');
      $('#e2').css('display', 'block');
      $('#e2').closest('a').addClass('active');
      $('#headdyn').html("Edit User & Configure Class ");
      this.form.get('update_id').setValue(this.configdata.user_id);
      this.form.get('first_name').setValue(this.configdata.first_name);
      this.form.get('last_name').setValue(this.configdata.last_name);
      this.form.get('username').setValue(this.configdata.username);
      this.form.get('email').setValue(this.configdata.email);
      this.form.get('user_class').setValue(this.configdata.user_class);
      if(this.configdata.user_class == 'admin'){
        this.form.get('user_class').disable();
      }
      this.form.get('phone').setValue(this.configdata.phone);

      // alert(this.configdata.username)
      if(this.configdata.username != null){
        // alert('enter')
          $('#username').css('pointer-events', 'none');
      $('#username').addClass('textback');  
      }
  
    }
  }
 //creating form
 createForm() {
  this.form = this.fb.group({
    phone: new FormControl(),
    update_id: new FormControl(),
    first_name: new FormControl('', [Validators.required,]),
    last_name: new FormControl('', [Validators.required,]),
    username: new FormControl('', [Validators.required,]), 
    email: new FormControl('', [Validators.required, Validators.pattern('^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]+$')]),
    user_class: new FormControl('', [Validators.required,]), 
  });
}
//

changes(id) {
  //guardian validation
  var inputVal = ($('#phone').val());
  // $('#phone' + id).replace(/[^0-9\.]/g,'');
  var regExp = /[a-zA-Z]/g;
  if (regExp.test(inputVal)) {
    //letters found
    $('#phone').addClass('error');
    this.error = true;
  } else {
    $('#phone').removeClass('error');
    this.error = false;
  }

  $('#phone').val($('#phone').val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));



}
username_changes() {
  // for guardian validation
  $('#username').val($('#username').val().replace(/[^a-z0-9]/gi, ''));
  if(($('#username').val().length<6)||($('#username').val().length>6) ) {
    $('#username').addClass('error');
    this.error = true;
    this.username = true;
  }else{
    var reg_Ex =/^([0-9]+[a-zA-Z]+|[a-zA-Z]+[0-9]+)[0-9a-zA-Z]*$/
    var isValiduname = reg_Ex.test($('#username').val())
    if(isValiduname== false){
      this.error = true
      this.username = true;
    $('#username').addClass("error");
    }else{
      this.error =false
      this.username = false;
      $('#username').removeClass('error');
    }
    // $('#username').removeClass('error');
    // this.error =  false;
  }
}
//submitting function
submit() {
  this.path=localStorage.setItem('set_editpath', JSON.stringify('user_subscription'));
  if (!($('#first_name').val())) {
    $('#first_name').addClass('error');
    this.error = true;
    this.first_name = true;
  }else{
    $('#first_name').removeClass('error');
    this.error = false;
    this.first_name = false;
  }
  if (!($('#last_name').val())) {
    $('#last_name').addClass('error');
    this.error = true;
    this.last_name = true;
  }else{
    $('#last_name').removeClass('error');
    this.error = false;
    this.last_name = false;
  }
  
  if (!($('#email').val())) {
    $('#email').addClass('error');
    this.error = true;
    this.email = true;
  }else{
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(!regex.test($('#email').val())) {
    //false
    $('#email').addClass('error');
    this.error = true;
    this.email = true;
  }else{
//true
 $('#email').removeClass('error');
    this.error = false;
    this.email = false;
  }
   
  }

  if (!($('#user_class option:selected').val())) {
    $('#user_class').addClass('error');
    this.error = true;
    this.user_class = true;
  }else{
    $('#user_class').removeClass('error');
    this.error = false;
    this.user_class = false;
  }

  // if (!($('#username').val())) {
  //   $('#username').addClass('error');
  //   this.error = true;
  //   this.username = true;
  // }else{

  //   if($('#username').val().length<6){
  //   $('#username').addClass('error');
  //   this.error =true;
  //   this.username = true;
  // }else{
  //   $('#username').removeClass('error');
  //   this.error = false;
  //   this.username = false;
  // }

  // }

  // if($('#user_class').val()=='student 2'){
  //   if (!($('#username').val())) {
  //     $('#username').removeClass('error');
  //     this.error = false;
  //     this.username = false;
  //   }
  //   if (!($('#email').val())) {

  //     $('#email').removeClass('error');
  //     this.error = false;
  //     this.email = false;
  //   }
  // }
// alert(this.error)
  if (this.form.getRawValue().update_id == '')
    this.update_id = true

  if (this.error == false) {
    // if (this.update_id == true) {
    //   console.log('add_api')
      if (this.first_name == false && this.last_name == false && this.email == false && this.username == false && this.user_class == false) {
        var value = this.form.getRawValue()
        console.log(value)
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_subscription`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg"> User Info');
            $('#errortext').html(data.message);
            localStorage.setItem('set_subscribeduser', JSON.stringify(''));//clear session 
            this.form.reset();
          }
          else if (data.status == true) {
            $('#ok').css('display','none');
            if((this.localdata.class == 'admin') ){
           $('#redirect_subs').css('display','block');
            }
            // console.log(this.url+'/school-names/')

            // $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">User Info');
            $('#errortext').html(data.message);
              
            localStorage.setItem('set_subscribeduser', JSON.stringify(''));//clear session 
            // $('#hrefcont').html('<a  data-dismiss="modal" (click)="redirect()"   class="btn common-btn green-btn  mr-4" >Ok</a>');
            this.form.reset();
            // 
          }
        }, err => {
          $('.pageloader').hide();
        })
      }
    // } 
    // else {
    //   console.log('edit_api')
    //   if (this.first_name == false && this.last_name == false && this.email == false && this.username == false && this.user_class == false && this.update_id == false) {
    //     var value = this.form.getRawValue()
    //     console.log(value)
    //     $('.pageloader').show();
    //     this.http.post<any>(`${this.url}/manage_subscription`, value).subscribe(data => {
    //       $('.pageloader').hide();
    //       if (data.status == false) {
    //         $('#error-disp-btn').trigger('click');
    //         $('#modal_pass').html('<img src="assets/images/block.svg"> User Info');
    //         $('#errortext').html(data.message);
    //          localStorage.setItem('set_subscribeduser', JSON.stringify(''));//clear session 
    //       }
    //       else if (data.status == true) {
    //         $('#pass_pop').trigger('click');
    //         $('#error-disp-btn').trigger('click');
    //         $('#modal_pass').html('<img src="assets/images/success.svg">User Info');
    //         $('#errortext').html(data.message);
         
    //         localStorage.setItem('set_subscribeduser', JSON.stringify(''));//clear session  
    //         // this.form.reset();
    //         // 
    //       }
    //     }, err => {
    //       $('.pageloader').hide();
    //     })
    //   }
    // }

  }
}
//
 IsEmail(email) {
  var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(!regex.test(email)) {
     return false;
  }else{
     return true;
  }
}
}
