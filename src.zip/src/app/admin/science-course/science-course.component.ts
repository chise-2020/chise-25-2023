import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-science-course',
  templateUrl: './science-course.component.html',
  styleUrls: ['./science-course.component.css']
})
export class ScienceCourseComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  schoolList1: any = [];
  schoolList2: any = [];
  schoolList3: any = [];
  items = [];
  exe: any;
  cumulative1=0;
  cumulative2=0;
  cumulative3=0;
  pageOfItems: Array<any>;
  pageOfItems1: Array<any>;
  pageOfItems2: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#c1').trigger('click');
    // $('#s5').trigger('click');
    // $('.sdebar').css('display', 'none');
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.getDatas()
    localStorage.setItem('set_schoolcourse', JSON.stringify(''));
  }
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      course:'Science',
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/school_course`, type).subscribe(data => {
      $('.pageloader').hide();
      this.schoolList2 = data.science
      $('#showcount2').html(data.science.length);
      this.cumulative1=data.science.length;
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2')) {
        this.exe = 1;
      } else {
        this.exe = 0;
      }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  //to edit page
  previewPage(data) {
    console.log(data)
    localStorage.setItem('set_schoolcourse', JSON.stringify(data));//storing data in session
    this.router.navigate(['edit-school-course/']);

  }
  //
  //deleting schools
  deleteData(data) {

    $('#deletebttn').trigger('click');
    var user = {
      tablename: 'school_tracks',
      fieldid: data.track_id,
      fieldname: 'track_id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));

  }
  //
  //setting value of filter
  setval(type, val2) {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.' + type).addClass('active');
  }
  //
  //search function
  search() {
    var searchval = $('#value').val();
    if (searchval == '') {
      var search = 0;
      $('#ff').html('Filter Unselected');
    }
    else
      var search = 1;
    var user_id = {
      type: $('#type').val(),
      search: search,
      value: $('#value').val(),
      course:'Science',
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/school_course`, user_id).subscribe(data => {
      $('.pageloader').hide();
      this.schoolList2 = data.science
      $('#showcount2').html(data.science.length);
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2')) {
        this.exe = 1;
      } else {
        this.exe = 0;
      }
    }, err => {
      $('.pageloader').hide();
    })
  }

  //
  //exporting the selected data as csv
  export_data() {
      var selected_array = ['track_name'];
      var header_array = ['School Course'];
      this.api.downloadFile(this.schoolList2, selected_array, header_array, 'science_courses');
  }
  

  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  
}

