import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScienceCourseComponent } from './science-course.component';

describe('ScienceCourseComponent', () => {
  let component: ScienceCourseComponent;
  let fixture: ComponentFixture<ScienceCourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScienceCourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScienceCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
