import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddeditTeacherassignmentComponent } from './admin-addedit-teacherassignment.component';

describe('AdminAddeditTeacherassignmentComponent', () => {
  let component: AdminAddeditTeacherassignmentComponent;
  let fixture: ComponentFixture<AdminAddeditTeacherassignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddeditTeacherassignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddeditTeacherassignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
