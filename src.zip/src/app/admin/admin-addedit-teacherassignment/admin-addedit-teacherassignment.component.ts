import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-admin-addedit-teacherassignment',
  templateUrl: './admin-addedit-teacherassignment.component.html',
  styleUrls: ['./admin-addedit-teacherassignment.component.css']
})
export class AdminAddeditTeacherassignmentComponent implements OnInit {
  UserData: any = [];
  url = this.api.geturl();
  teacherdata: any = [];
  form: FormGroup;//initializing form
  academic_term = false
  academic_year = false
  grade=false
  program=false
  teacher=false
  update_id = false
  programs=false
  grades=false
  academic_terms=false
  academic_years=false
  teachers=false
  error = false
  years=false
  
  novalue1=null
  novalue2 = null
  novalue3 = null
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('.sdebar').css('display','none');
    this.UserData  = JSON.parse(localStorage.getItem('loginData'));
    this.teacherdata = JSON.parse(localStorage.getItem('set_teacher_assignment'));
    this.getStudent();
    console.log(localStorage.getItem("set_teacher_assignment") )

    if (localStorage.getItem("set_teacher_assignment") === null) {
      $('#c5').trigger('click');
      $('#headdyn').html("Assign Teachers to Tracks");
    $('#addt_7').addClass('active');
    }else
    {

      if (localStorage.getItem('set_teacher_assignment') == null) {
        $('#c5').trigger('click');
        $('#headdyn').html("ASSIGN TEACHERS TO TRACKS");
        $('#addt_7').addClass('active');
      } else {
        $('#c1').trigger('click');
        $('#s4').trigger('click');
        $('#e8').css('display', 'block');
        $('#schoolcourse').addClass('active');
        $('#headdyn').html("ASSIGN TEACHERS TO TRACKS");
        if(this.teacherdata.length!=0)
        {
        this.form.get('update_id').setValue(this.teacherdata.assign_id);
        this.form.get('academic_term').setValue(this.teacherdata.academic_term);
      this.form.get('academic_year').setValue(this.teacherdata.academic_year);
        this.form.get('grade').setValue(this.teacherdata.grade);
        this.form.get('program').setValue(this.teacherdata.track_id);
        this.form.get('teacher').setValue(this.teacherdata.teacher_id);
        
        }
      }

    }
  
  }
    //creating form
    createForm() {
      this.form = this.fb.group({
        update_id: new FormControl(),
        grade: new FormControl('', [Validators.required,]),
        program: new FormControl('', [Validators.required,]),
        academic_year: new FormControl('', [Validators.required,]),
        academic_term: new FormControl('', [Validators.required,]),
        teacher: new FormControl('', [Validators.required,]),
      });
    }
    //
    //submitting function
    submit() {
      this.error = false;
      var path = localStorage.setItem('set_editpath', JSON.stringify('teacherassignment'));
      this.academic_term = this.academic_year = this.grade = this.program = this.teacher  = false;
  
      if (this.form.getRawValue().academic_term == '') {
        this.academic_term = true
        this.error = true
      }
      if (this.form.getRawValue().program == '') {
        this.program = true
        this.error = true
      }
      // if (this.form.getRawValue().grade == '') {
      //   this.grade = true
      //   this.error = true
      // }
      if (this.form.getRawValue().academic_year == '') {
        this.academic_year = true
        this.error = true
      }
      if (this.form.getRawValue().teacher == '')
      {
        this.teacher = true
        this.error = true
      }
  //  alert(this.error);
      if (this.error == false) {
        console.log('entered')
       
        var value = this.form.getRawValue();
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_techerassignment`, value).subscribe(data => {
          $('.pageloader').hide();
          // console.log(data.status)
          if (data.status == false)
            $('#modal_pass').html('<img src="assets/images/block.svg">Track Assignment');
          else
            $('#modal_pass').html('<img src="assets/images/success.svg">Track Assignment');
          
          $('#errortext').html(data.message);
          $('#error-disp-btn').trigger('click');
          localStorage.setItem('set_teacher_assignment', JSON.stringify(''));
        }, err => {
          $('.pageloader').hide();
        })
      }
  
    }
    //
    getStudent(){
      if (localStorage.getItem('set_teacher_assignment') != null)
      {
        var academic_term =  this.teacherdata.academic_term;
      }else
      var academic_term = $('#academicterm').val();

      // alert(academic_term)
      var user_id = {
      user_id : this.UserData.user_id,
      group_id : this.UserData.family_code,
      term:academic_term
    }
     $('.pageloader').show();
       this.http.post<any>(`${this.url}/drop_lists`,user_id).subscribe(data => {
        $('.pageloader').hide();
        console.log(data.program)
        this.programs = data.program
        this.grades = data.grade
        this.academic_terms=data.academic_term
        this.academic_years=data.academic_year  
        this.teachers=data.teacher
        this.years = data.year
      }, err => {
        $('.pageloader').hide();
      })
   
  }
  get_year(){
    var academic_term = $('#academic_term').val();
    // alert(academic_term)
    
      var user_id = {
      user_id : this.UserData.user_id,
      group_id : this.UserData.family_code,
      term:academic_term
    }
   $('.pageloader').show();
     this.http.post<any>(`${this.url}/drop_lists`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.years = data.year
    }, err => {
      $('.pageloader').hide();
    })
  }

}
