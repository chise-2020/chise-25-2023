import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-contact-number',
  templateUrl: './contact-number.component.html',
  styleUrls: ['./contact-number.component.css']
})
export class ContactNumberComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('.sdebar').css('display','none');
    // $('#c8').trigger('click');
    
    $('#dropdownMenu15').addClass('active');// menu highlight
    this.getDatas()
    
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
    var user_id = {
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/contact_details_email`,  user_id   ).subscribe(data => {
      this.list = data.user;
      $('#showcount').html(data.count);
      $('.pageloader').hide();
    }, err => {
      $('.pageloader').hide();
    })
  }
  getDatas() {
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/contact_details_email`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.user;
      $('#showcount').html(data.count);
      this.cumulative=data.user.length;
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

//deleting schools
deleteData(data) {
 
  $('#deletebttn').trigger('click');
  var user = {
    tablename : 'students_old',
    fieldid: data.student_id,
    fieldname: 'student_id'
  }
  localStorage.setItem('delete_item', JSON.stringify(user));
}
//

//exporting the selected data as csv
export_data() {
    var selected_array=['user_class','name','guard1_contact_no'];
    var header_array=['User Class','Full Name', 'Contact Number'];
    this.api.downloadFile(this.list,selected_array,header_array, 'contact_number');
}
//


 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}

