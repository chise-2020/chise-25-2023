import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-schoolinfo-certificates',
  templateUrl: './admin-schoolinfo-certificates.component.html',
  styleUrls: ['./admin-schoolinfo-certificates.component.css']
})
export class AdminSchoolinfoCertificatesComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  certificateList: any = [];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('#c1').trigger('click');
    $('#s6').trigger('click');
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.getDatas()
  }
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/certificate`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.certificateList = data.user
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }


 //setting value of filter
 setval(type)
 {
  
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
   var user_id = {
     type : $('#type').val(),
     search : 1,
     value : $('#value').val(),
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/certificate`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.certificateList = data.user
   }, err => {
     $('.pageloader').hide();
   })
 }
 //
}
