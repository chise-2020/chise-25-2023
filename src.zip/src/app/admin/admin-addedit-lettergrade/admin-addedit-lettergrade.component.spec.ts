import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddeditLettergradeComponent } from './admin-addedit-lettergrade.component';

describe('AdminAddeditLettergradeComponent', () => {
  let component: AdminAddeditLettergradeComponent;
  let fixture: ComponentFixture<AdminAddeditLettergradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddeditLettergradeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddeditLettergradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
