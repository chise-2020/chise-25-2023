import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-admin-addedit-lettergrade',
  templateUrl: './admin-addedit-lettergrade.component.html',
  styleUrls: ['./admin-addedit-lettergrade.component.css']
})
export class AdminAddeditLettergradeComponent implements OnInit {
  UserData: any = [];
  student: any = [];
  url = this.api.geturl();
  lettergradedata: any = [];
  h_schools: any = [];
  form: FormGroup;//initializing form
  full_names = false
  register_email = false
  academic_year = false
  grade = false
  math_track = false
  math_grade = false
  science_track = false
  science_grade = false
  cs_track = false
  cs_grade = false
  school_name = false
  register_year = false
  program_name = false
  user_student_id = false
  academic_term = false
  update_id = false
  error = false
  programs = false
  maths = false
  sciences = false
  comp_sc = false
  letter_grades=false
  grades = false
  schools = false
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('.sdebar').css('display', 'none');
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    this.lettergradedata = JSON.parse(localStorage.getItem('set_lettergrade'));
    console.log(this.lettergradedata)
    this.getStudent()
    if (this.lettergradedata.length == 0) {
      $('#c5').trigger('click');
      // $('#addt_3').addClass('active');
      $('#headdyn').html("Add LETTER GRADE");
    } else {
      $('#c1').trigger('click');
      $('#s5').trigger('click');
      $('#e9').css('display', 'block');
      $('#full_names').css({ 'cursor': "none" });
      // $('#lettergrade').addClass('active');
      // removeClass
      $('#headdyn').html("ASSIGN LETTER GRADE");

      if (this.lettergradedata.length != 0) {
        // alert();
        this.form.get('update_id').setValue(this.lettergradedata.regids);
        this.form.get('full_names').setValue(this.lettergradedata.user_student_id);
        this.form.get('register_email').setValue(this.lettergradedata.register_email);
        this.form.get('grade').setValue(this.lettergradedata.grade);
        this.form.get('academic_year').setValue(this.lettergradedata.academic_year);
        this.form.get('math_track').setValue(this.lettergradedata.math_track);
        this.form.get('math_grade').setValue(this.lettergradedata.math_grade);
        this.form.get('science_track').setValue(this.lettergradedata.science_track);
        this.form.get('science_grade').setValue(this.lettergradedata.science_grade);
        this.form.get('cs_track').setValue(this.lettergradedata.cs_track);
        this.form.get('cs_grade').setValue(this.lettergradedata.cs_grade);
        this.form.get('school_name').setValue(this.lettergradedata.school_name);
        this.form.get('academic_term').setValue(this.lettergradedata.academic_term);
        this.form.get('program_name').setValue(this.lettergradedata.program_id);
        this.form.get('user_student_id').setValue(this.lettergradedata.user_student_id);
      }

    }
  }
  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      register_email: new FormControl('', [Validators.required,]),
      grade: new FormControl('', [Validators.required,]),
      full_names: new FormControl('', [Validators.required,]),
      academic_year: new FormControl('', [Validators.required,]),
      math_track: new FormControl('', [Validators.required,]),
      math_grade: new FormControl('', [Validators.required,]),
      science_track: new FormControl('', [Validators.required,]),
      science_grade: new FormControl('', [Validators.required,]),
      cs_track: new FormControl('', [Validators.required,]),
      cs_grade: new FormControl('', [Validators.required,]),
      school_name: new FormControl('', [Validators.required,]),
      academic_term: new FormControl('', [Validators.required,]),
      program_name: new FormControl('', [Validators.required,]),
      user_student_id: new FormControl('', [Validators.required,]),
    });
  }
  //
  //submitting function
  submit() {
    this.error = false;
    var path = localStorage.setItem('set_editpath', JSON.stringify('lettergrade'));
    this.academic_term = this.user_student_id = this.program_name = this.full_names = this.grade = this.register_email = this.academic_year = this.math_track = this.math_grade = this.science_track = this.science_grade = this.cs_track = this.cs_grade = this.school_name = this.register_year = false;

    if (this.form.getRawValue().full_names == '') {
      this.full_names = true
      this.error = true
    }
   

    if (this.form.getRawValue().academic_year == '') {
      this.academic_year = true
      this.error = true
    }
    if (this.form.getRawValue().math_track == '') {
      this.math_track = true
      this.error = true
    }

    if (this.form.getRawValue().math_grade == '') {
      this.math_grade = true
      this.error = true
    }
    if (this.form.getRawValue().science_track == '') {
      this.science_track = true
      this.error = true
    }
    if (this.form.getRawValue().science_grade == '') {
      this.science_grade = true
      this.error = true
    }
    if (this.form.getRawValue().cs_track == '') {
      this.cs_track = true
      this.error = true
    }
    if (this.form.getRawValue().cs_grade == '') {
      this.cs_grade = true
      this.error = true
    }
    if (this.form.getRawValue().school_name == '') {
      this.school_name = true
      this.error = true
    }
    if (this.form.getRawValue().register_year == '') {
      this.register_year = true
      this.error = true
    }

    if (this.form.getRawValue().academic_term == '') {
      this.academic_term = true
      this.error = true
    }
  
// alert(this.error)
    if (this.error == false) {
      var value = this.form.getRawValue();
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/manage_lettergrade`, value).subscribe(data => {
        $('.pageloader').hide();
        // console.log(data.status)
        if (data.status == false) {
          $('#modal_pass').html('<img src="assets/images/block.svg">LETTER GRADE');
        }

        else {
          $('#modal_pass').html('<img src="assets/images/success.svg">LETTER GRADE');

        }

        $('#errortext').html(data.message);
        $('#error-disp-btn').trigger('click');
        localStorage.setItem('set_lettergrade', JSON.stringify(''));
      }, err => {
        $('.pageloader').hide();
      })
    }

  }
  //
  getStudent() {
    var user_id = {
      user_id: this.UserData.user_id,
      group_id: this.UserData.family_code
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, user_id).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.student = data.students
      this.programs = data.track_id_list
      this.maths = data.math
      this.sciences = data.science
      this.comp_sc = data.cs
      this.grades = data.grade
      this.schools = data.school
      this.h_schools = data.home_school
      this.letter_grades = data.letter_grade
    }, err => {
      $('.pageloader').hide();
    })

  }
}
