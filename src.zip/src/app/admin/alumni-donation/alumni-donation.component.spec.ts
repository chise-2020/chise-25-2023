import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlumniDonationComponent } from './alumni-donation.component';

describe('AlumniDonationComponent', () => {
  let component: AlumniDonationComponent;
  let fixture: ComponentFixture<AlumniDonationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlumniDonationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlumniDonationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
