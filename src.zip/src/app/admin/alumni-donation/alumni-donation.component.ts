import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-alumni-donation',
  templateUrl: './alumni-donation.component.html',
  styleUrls: ['./alumni-donation.component.css']
})
export class AlumniDonationComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  subscriptionList: any = [];
  items = [];
  cumulative=0;
  exe=0;
  pageOfItems: Array<any>;
  year: any;
  alumni: any;
  chise_event=false;
  alumni_name=false;
  contri_amt=false;
  error=false;
  form: FormGroup;//initializing form
  chise_events:  any = [];
  years=false;
  contributed_list: any = [];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private fb: FormBuilder,) { 
this.createForm();
  }

  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    if(this.data.class!='admin')
    {
      this.exe =1;
    }
    this.getdetails();
    this.getData();
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
  }
  //creating form
createForm() {
  this.form = this.fb.group({
    chise_event: new FormControl('', [Validators.required,]),
    alumni_name: new FormControl('', [Validators.required,]),
    contri_amt: new FormControl('', [Validators.required,]),
    years: new FormControl('', [Validators.required,]),
  });
}
//
  getdetails() {
    var userid = {
      user_id: '',
      edit_track:''
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, userid).subscribe(data => {
      $('.pageloader').hide();
     this.year=data.list_year;
  this.alumni=data.alumni_list;
  this.chise_events=data.chiseevent;
    }, err => {
      $('.pageloader').hide();
    })
  }
  submit(){
    if (!($('#alumni_name').val())) {
      $('#alumni_name').addClass('error');
      this.error = true;
    } else {
      $('#alumni_name').removeClass('error');
      this.error = false;
    }
     if (!($('#chise_event').val())) {
      $('#chise_event').addClass('error');
      this.error = true;
    } else {
      $('#chise_event').removeClass('error');
      this.error = false;
    }
    if (!($('#contri_amt').val())) {
      $('#contri_amt').addClass('error');
      this.error = true;
    } else {
      $('#contri_amt').removeClass('error');
      this.error = false;
    }
    if (!($('#years').val())) {
      $('#years').addClass('error');
      this.error = true;
    } else {
      $('#years').removeClass('error');
      this.error = false;
    }
      if (this.error == false) {
       
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/add_alumni_contributions`,this.form.value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            //this.oldPassword= true
            $('#new-pop').trigger('click');
            $('#new_pop_text').html('<img src="assets/images/block.svg">Alumni Contributions');
            $('#new_pop_html').html(data.message);
            this.form.reset();
          }
          else if (data.status == true) {
      
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">Alumni Contributions');
            $('#errortext').html(data.message);
            this.form.reset();
          }
        }, err => {
          $('.pageloader').hide();
        }
        )
      }
  }
    //setting value of filter
    setval(type,val2)
    {
      $('#ff').html(val2);
      $('#type').val(type);
      $('.dropdown-item').removeClass('active');
      $('.'+type).addClass('active');
    }
    
   search(){
     var searchval=$('#value').val();
     if(searchval=='')
     {
       var search=0;
       $('#ff').html('Filter Unselected');
     }
     else
     var search=1;
     var user_id = {
       user_id :'',
       group_id :'',
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
       merged_stat:0
     }
     $('.pageloader').show();
      this.http.post<any>(`${this.url}/get_alumni_contributions`,  user_id   ).subscribe(data => {
       $('.pageloader').hide();
       this.contributed_list=data.contri_list;
       $('#showcount').html(data.contri_list.length);
     }, err => {
       $('.pageloader').hide();
     })
   }
  getData(){
    var userid = {
      user_id: '',
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_alumni_contributions`, userid).subscribe(data => {
      $('.pageloader').hide();
     this.contributed_list=data.contri_list;
     $('#showcount1').html(data.total_contribution);
     $('#showamt').html(data.total_sum);
     $('#showtotalcount').html(data.alumni_count);
     $('#showcount').html(data.contri_list.length);
     this.cumulative=data.contri_list.length;
    }, err => {
      $('.pageloader').hide();
    })
  }

    //exporting the selected data as csv
    export_data() {
      var selected_array=['alumni_name', 'event_name','year','contributed_amt'];
      var header_array=['Alumnus Name', 'Event Name','Year','$$'];
     this.api.downloadFile(this.contributed_list,selected_array,header_array, 'Alumni Donations');
  }
  //
}

