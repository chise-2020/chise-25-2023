import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-userinfo-userprofile',
  templateUrl: './admin-userinfo-userprofile.component.html',
  styleUrls: ['./admin-userinfo-userprofile.component.css']
})
export class AdminUserinfoUserprofileComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  profileList: any = [];
  exe=0;
  items = [];
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#c1').trigger('click');
    // $('#s1').trigger('click');
    // $('#edits').css('display','none');
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.getDatas()

  }
    getDatas() {
      console.log(this.data.user_id)
      var type = {
        type: ""// request post data
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/user_profileinfo`, type).subscribe(data => {
        console.log(data)
        $('.pageloader').hide();
        this.profileList = data.user
        $('#showcount').html(data.count);
        this.cumulative=data.user.length;
        if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
          this.exe =1;
        }else{
          this.exe =0; 
        }
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
    }
  //to edit page
  previewPage(data) {
    console.log(data)
    localStorage.setItem('set_userprofile', JSON.stringify(data));//storing data in session
    this.router.navigate(['edit-user-profile/']);

  }
  //
  
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
     }
     $('.pageloader').show();
      this.http.post<any>(`${this.url}/user_profileinfo`,  user_id   ).subscribe(data => {
       $('.pageloader').hide();
       this.profileList = data.user
       $('#showcount').html(data.count);
       if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
     }, err => {
       $('.pageloader').hide();
     })
   }
   //}
 //exporting the selected data as csv
 export_data() {
  // alert('yes')
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
  var user_id = {
    type : $('#type').val(),
    search : search,
    value : $('#value').val(),
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/user_profileinfo`, user_id).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
    // this.list = data.user;
    var selected_array=['name','access_level','username'];
    var header_array=['Full Name','User Class','Username'];
    this.api.downloadFile(data.user,selected_array,header_array, 'user_profile');
    
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
//
   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

}
