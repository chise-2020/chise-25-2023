import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUserinfoUserprofileComponent } from './admin-userinfo-userprofile.component';

describe('AdminUserinfoUserprofileComponent', () => {
  let component: AdminUserinfoUserprofileComponent;
  let fixture: ComponentFixture<AdminUserinfoUserprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminUserinfoUserprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserinfoUserprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
