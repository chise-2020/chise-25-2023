import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecDataAnalyticsComponent } from './exec-data-analytics.component';

describe('ExecDataAnalyticsComponent', () => {
  let component: ExecDataAnalyticsComponent;
  let fixture: ComponentFixture<ExecDataAnalyticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExecDataAnalyticsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExecDataAnalyticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
