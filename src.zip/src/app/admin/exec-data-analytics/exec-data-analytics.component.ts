import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
declare var google: any;
@Component({
  selector: 'app-exec-data-analytics',
  templateUrl: './exec-data-analytics.component.html',
  styleUrls: ['./exec-data-analytics.component.css']
})
export class ExecDataAnalyticsComponent implements OnInit {
  url = this.api.geturl();
  piedata: any;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.getchartdata();

    //     google.charts.load('current', {packages: ['corechart', 'bar']});
    // google.charts.setOnLoadCallback(this.drawAxisTickColors);//bar

    // google.charts.load('current', {packages: ['corechart']});
      

    google.charts.load("current", { packages: ["corechart"] });
    // google.charts.setOnLoadCallback(this.drawCharttrend);//trendline

    // google.charts.setOnLoadCallback(this.drawCharts);
  }
  getchartdata() {
    var user_id = {
      user_id: ''
    }
    this.http.post<any>(`${this.url}/get_chartdata`, user_id).subscribe(data => {
      if (data.status == true) {
        //  this.notifications=data.list;
        // this.piedata=data.pie_chart
        localStorage.setItem('piedata', JSON.stringify(data.pie_chart));
        localStorage.setItem('bardata', JSON.stringify(data.bar_chart));

        localStorage.setItem('trendlinedata', JSON.stringify(data.trendline));
        localStorage.setItem('alumniarray', JSON.stringify(data.alumniarray));
        localStorage.setItem('schoolarray', JSON.stringify(data.schoolarray));

        localStorage.setItem('reg_trend', JSON.stringify(data.reg_trend));
        localStorage.setItem('alumni_trend', JSON.stringify(data.alumni_trend));
        localStorage.setItem('school_trend', JSON.stringify(data.school_trend));
      }

    })
  }

  getchart() {
    var chart_name = $('#chart_name').val();
    var chart_data = $('#chart_data').val();
    if (chart_data == "total_reg") {
      if (chart_name == 'ScatterChart') {
        var dataAsArrays = localStorage.getItem('reg_trend');
        var dataAsArray = $.parseJSON(dataAsArrays);
        var data = google.visualization.arrayToDataTable(dataAsArray);
      } else {
        var dataAsArrays = localStorage.getItem('trendlinedata');
        var dataAsArray = $.parseJSON(dataAsArrays);
        var data = google.visualization.arrayToDataTable(dataAsArray);
      }

    }
    if (chart_data == "total_alumni") {
      if (chart_name == 'ScatterChart') {
        var dataAsArrays = localStorage.getItem('alumni_trend');
        var dataAsArray = $.parseJSON(dataAsArrays);
        var data = google.visualization.arrayToDataTable(dataAsArray);
      } else {
        var dataAsArrays = localStorage.getItem('alumniarray');
        var dataAsArray = $.parseJSON(dataAsArrays);
        // var exdata=[
        //   ['No : of students ', 'Year'],
        //      [8, 37], [4, 19.5], [11, 52], [4, 22], [3, 16.5], [6.5, 32.8], [14, 72]];
        var data = google.visualization.arrayToDataTable(dataAsArray);
      }
    }
    if (chart_data == "total_school") {
      if (chart_name == 'ScatterChart') {
        var dataAsArrays = localStorage.getItem('school_trend');
        var dataAsArray = $.parseJSON(dataAsArrays);
        var data = google.visualization.arrayToDataTable(dataAsArray);
      } else {
      var dataAsArrays = localStorage.getItem('schoolarray');
      var dataAsArray = $.parseJSON(dataAsArrays);
      var data = google.visualization.arrayToDataTable(dataAsArray);
      }
    }



    if (chart_name == 'LineChart') {
      // alert('sc');
      var chart3 = new google.visualization.LineChart(document.getElementById('selected_chart'));
      if (chart_data == "total_reg") {
        var option = {
          title: 'Total Registrations in each year',
          hAxis: { title: 'Year ' },
          vAxis: { title: '# of students' },
          
        };
      } else if (chart_data == "total_alumni") {
        var option = {
          title: 'Total Alumni in each year',
          hAxis: { title: 'Year' },
          vAxis: { title: '# of students ' },
     
        };
      } else if (chart_data == "total_school") {
        var option = {
          title: 'Total School in each year',
          hAxis: { title: ' Year' },
          vAxis: { title: '# of schools' },
         
        };
      }
      chart3.draw(data, option);
      // console.log(chart3.getImageURI())
      document.getElementById('selected_png').innerHTML = ' <div class="nav mt-5 clearfix justify-content-center d-flex align-items-center"><a download="img.png"  class="tab-button next pull-right" href="' + chart3.getImageURI() + '  ">Save Chart</a></div>';
    }
    if (chart_name == 'ScatterChart') {
      
      // alert('sc');
      var chart = new google.visualization.ScatterChart(document.getElementById('selected_chart'));
      if (chart_data == "total_reg") {
        var option_s = {
          title: 'Total Registrations in each year',
          hAxis: { title: ' Year' },
          vAxis: { title: '# of students' },
         
          trendlines: { 0: {} }    // Draw a trendline for data series 0.
        };
      } else if (chart_data == "total_alumni") {
        var option_s = {
          title: 'Total Alumni in each year',
          hAxis: { title: 'Year' },
          vAxis: { title: '# of students' },
       
          trendlines: { 0: {} }    // Draw a trendline for data series 0.
        };
      } else if (chart_data == "total_school") {
        var option_s = {
          title: 'Total School in each year',
          hAxis: { title: 'Year' },
          vAxis: { title: '# of schools ' },
          
          trendlines: { 0: {} }    // Draw a trendline for data series 0.
        };
      }
      chart.draw(data, option_s);
      // console.log(chart.getImageURI())
      document.getElementById('selected_png').innerHTML = ' <div class="nav mt-5 clearfix d-flex justify-content-center align-items-center"><a download="img.png"  class="tab-button next pull-right" href="' + chart.getImageURI() + '  ">Save Chart</a></div>';
    }
    if (chart_name == 'BarChart') {
      // alert('bc');
      var chart1 = new google.visualization.BarChart(document.getElementById('selected_chart'));
      if (chart_data == "total_reg") {
        var options = {
          title: 'Total Registrations in each year',
          hAxis: { title: '# of students ' },
          vAxis: { title: 'Year' },
          chartArea: { width: '100px', height: '500px' },
        };
      } else if (chart_data == "total_alumni") {
        var options = {
          title: 'Total Alumni in each year',
          hAxis: { title: '# of students' },
          vAxis: { title: 'Year' },
          chartArea: { width: '100px', height: '500px' },
        };
      } else if (chart_data == "total_school") {
        var options = {
          title: 'Total School in each year',
          hAxis: { title: '# of schools ' },
          vAxis: { title: 'Year' },
          chartArea: { width: '100px', height: '200px' },
        };
      }
      chart1.draw(data, options);
      // console.log(chart1.getImageURI())
      document.getElementById('selected_png').innerHTML = ' <div class="nav mt-5 clearfix d-flex justify-content-center align-items-center"><a download="img.png"  class="tab-button next pull-right" href="' + chart1.getImageURI() + '  ">Save Chart</a></div>';
    }
    if (chart_name == 'PieChart') {
      // alert('pc');
      var chart2 = new google.visualization.PieChart(document.getElementById('selected_chart'));
      if (chart_data == "total_reg") {
      var opt = {
        title: 'Total Registrations Per Year (Fall+Spring+Summer) ',
        
        is3D: true,
      };
    }else if (chart_data == "total_alumni") {
      var opt = {
        title: 'Total Alumni Per Year (Fall+Spring+Summer) ',
        
        is3D: true,
      };
    }else if (chart_data == "total_school") {
       var opt = {
        title: 'Total Schools participated Per Year (Fall+Spring+Summer) ',
        
        is3D: true,
      };
    }
      chart2.draw(data, opt);
      // console.log(chart2.getImageURI())
      document.getElementById('selected_png').innerHTML = ' <div class="nav mt-5 clearfix justify-content-center d-flex align-items-center"><a download="img.png"  class="tab-button next pull-right" href="' + chart2.getImageURI() + '  ">Save Chart</a></div>';
    }



  }
 
}
