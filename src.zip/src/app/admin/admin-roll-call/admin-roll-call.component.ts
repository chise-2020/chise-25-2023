import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-admin-roll-call',
  templateUrl: './admin-roll-call.component.html',
  styleUrls: ['./admin-roll-call.component.css']
})
export class AdminRollCallComponent implements OnInit {
  url = this.api.geturl();
  parent:any[];
 record_suggestion: any = [];
 student_details: any = [];
 pageOfItems: any = [];
 pageOfItems1: any = [];
 yourArray: any = [];
 yourArray1: any = [];
 exe=0;
 data: any = [];
  constructor(private api: ApiService,private fb: FormBuilder,private router: Router,private http: HttpClient ,) {
    
  }

  ngOnInit(): void {
    // $('.sdebar').css('display','none');
    // $('#ca_3').trigger('click');
    $('#dropdownMenu13').addClass('active');//menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    
    this.getrecords()
  }
  cnfrm_present(data){
    // alert('enter_present');
console.log(data)
$('#error-disp-btn').trigger('click');
$('#modal_pass').html('<img src="assets/images/alert.svg">Student Roll Call');
$('#errortext').html('Are you sure you want to award the Student Certificate to '+data.full_names+'?');
$('#ok').css('display','none');
$('#yesbtn').css('display','block');
$('#ok_btn').css('display','block');
var value={
  ids:data.student_id,
  roll_call:1
}
localStorage.setItem('set_rollcall', JSON.stringify(value));
}
  cnfrm_absent(data){
    // alert('enter_absent');
    $('#error-disp-btn').trigger('click');
    $('#modal_pass').html('<img src="assets/images/alert.svg">Student Roll Call');
    $('#errortext').html('Are you sure you want to remove '+data.full_names );
    $('#ok').css('display','none');
    $('#yesbtn').css('display','block');
    $('#ok_btn').css('display','block');
    var value={
      ids:data.student_id,
      roll_call:0
    }
    localStorage.setItem('set_rollcall', JSON.stringify(value));

  }
  awrd_certificate()
  {
    var yourArray=[];
    $("input:checkbox[name=mrge]:checked").each(function(){
      yourArray.push($(this).val());
  });
    var value={
      ids: yourArray,
      // parentid: $('#parent').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/student_rollcall`,  value).subscribe(data => {
      $('.pageloader').hide();
      this.getrecords()
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/success.svg">Student Roll Call');
      $('#errortext').html('Successfully toggled the Certificate.');
      }, err => {
        $('.pageloader').hide();
      })
  }

 
  getrecords()
  {
    var value={
      parentid:'',
    }
    //  $('#parent').val()
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/student_list`,  value).subscribe(data => {
      $('.pageloader').hide();
      // this.record_suggestion = data.record_suggestion
      $('#stud_head').html(data.term_and_year);
      this.student_details = data.student_details
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      // $('#guarddata').html(data.html)
      }, err => {
        $('.pageloader').hide();
      })

  }

//to edit page
// previewPage(data) {
//   console.log(data)
//   localStorage.setItem('set_edit_oldreg', JSON.stringify(data));//storing data in session
//   this.router.navigate(['edit-old-registration-records/']);

// }
//
//setting value of filter
setval(type,val2)
{
  $('#ff').html(val2);
  $('#type').val(type);
  $('.dropdown-item').removeClass('active');
  $('.'+type).addClass('active');
}
//
//search function
search(){
 var searchval=$('#value').val();
 if(searchval=='')
 {
   var search=0;
   $('#ff').html('Filter Unselected');
 }
 else
 var search=1;
  var user_id = {
    type : $('#type').val(),
    search : search,
    value : $('#value').val(),
    // parentid: $('#parent').val(),
  }
  $('.pageloader').show();
   this.http.post<any>(`${this.url}/student_list`,  user_id   ).subscribe(data => {
    $('.pageloader').hide();
    this.student_details = data.student_details
    if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
    $('#guarddata').html(data.html)
  }, err => {
    $('.pageloader').hide();
  })
}
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

onChangePage1(pageOfItems1: Array<any>) {
  // update current page of items
  this.pageOfItems1 = pageOfItems1;
}

}
