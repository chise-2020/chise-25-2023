import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRollCallComponent } from './admin-roll-call.component';

describe('AdminRollCallComponent', () => {
  let component: AdminRollCallComponent;
  let fixture: ComponentFixture<AdminRollCallComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminRollCallComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminRollCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
