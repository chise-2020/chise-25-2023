import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-admin-registration-flyer',
  templateUrl: './admin-registration-flyer.component.html',
  styleUrls: ['./admin-registration-flyer.component.css']
})
export class AdminRegistrationFlyerComponent implements OnInit {
  url = this.api.geturl();
  progForm: FormGroup;
  start_date = false;
  end_date = false;
  welcome_message = false;
  error: boolean;
  public Editor = ClassicEditor;
  public sourceData: string;
  acad_yr:any;
  acad_term :any;
  getdata:any;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    $('#dropdownMenu13').addClass('active');
    this.acad_yr = JSON.parse(localStorage.getItem('acad_yr'));
    this.acad_term = JSON.parse(localStorage.getItem('acad_term'));
this.getflyer();
  
this.sourceData = '';
    this.progForm = this.formBuilder.group({
      start_date: new FormControl('', [Validators.required,]),
      end_date: new FormControl('', [Validators.required,]),
      welcome_message: new FormControl('', [Validators.required,]),
    })
  }
  submit() {
    this.error = false;
    if (!($('#start_date').val())) {
      $('#start_date').addClass('error');
      this.error = true;
    }
    if (!($('#end_date').val())) {
      $('#end_date').addClass('error');
      this.error = true;
    }
  
    if (this.error == false) {

      $('.pageloader').show();
      this.http.post<any>(`${this.url}/program_configuration`, this.progForm.value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#alerttitle').html('<img src="assets/images/block.svg">Registration Flyer');
          $('#alerttext').html(data.message);
          $('#alertbtn').trigger('click');
        }
        else if (data.status == true) {
          $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">Registration Flyer');
          $('#errortext').html(data.message);
        }
      }, err => {
        console.log(err);
      })
    }
  }

  sendflyer() {
    var userid = {
      flyer: 1
    }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/program_configuration`, userid).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#alerttitle').html('<img src="assets/images/block.svg">Registration Flyer');
          $('#alerttext').html(data.message);
          $('#alertbtn').trigger('click');
        }
        else if (data.status == true) {
          $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">Registration Flyer');
          $('#errortext').html(data.message);
        }
      }, err => {
        console.log(err);
      })
    
  }
  getflyer(){
    var userid = {
      user_id: ''
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_flyer`, userid).subscribe(data => {
      $('.pageloader').hide();
      if(data.status==true)
      {
        $('#reg_flyer_content').html(data.html);
        this.getdata = data.html;
        
        $('#flyerdisplay').html(data.html);
        $('#welcome_message').val(data.html);
        $('#end_date').val(data.end_date);
        this.progForm.get('start_date').setValue(data.start_date);
        this.progForm.get('end_date').setValue(data.end_date);
        //this.sourceData =  this.getdata;
      }
     
      else
      {
        this.sourceData = 'Welcome, ChiS&E Families!';
      }
  }, err => {
      $('.pageloader').hide();
    })
  }
 
}
