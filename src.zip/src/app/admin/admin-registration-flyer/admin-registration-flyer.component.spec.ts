import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRegistrationFlyerComponent } from './admin-registration-flyer.component';

describe('AdminRegistrationFlyerComponent', () => {
  let component: AdminRegistrationFlyerComponent;
  let fixture: ComponentFixture<AdminRegistrationFlyerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminRegistrationFlyerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminRegistrationFlyerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
