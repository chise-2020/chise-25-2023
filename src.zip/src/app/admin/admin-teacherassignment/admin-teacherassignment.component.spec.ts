import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTeacherassignmentComponent } from './admin-teacherassignment.component';

describe('AdminTeacherassignmentComponent', () => {
  let component: AdminTeacherassignmentComponent;
  let fixture: ComponentFixture<AdminTeacherassignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTeacherassignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminTeacherassignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
