import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-add-edit-school-sections',
  templateUrl: './add-edit-school-sections.component.html',
  styleUrls: ['./add-edit-school-sections.component.css']
})
export class AddEditSchoolSectionsComponent implements OnInit {
  form: FormGroup;
  section = false;
  editdata :any;
  url = this.api.geturl();
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation

  }
  ngOnInit(): void { 
    var path=localStorage.setItem('set_editpath', JSON.stringify('schoolsection'));
    this.editdata = JSON.parse(localStorage.getItem('set_editsections'));
    if(this.editdata.length==0)
    {
      $('#headdyn').html('ADD A SECTION IN A CHIS&E TRACK');
      $('#iinfo').html('Enter/type a name to define/create a new section on a ChiS&E Track');
    }else
    {
      $('#headdyn').html('Edit School Section');
      $('#iinfo').html('Update a section on a ChiS&E Track');
    }
    this.form.get('editid').setValue(this.editdata.section_id);
    this.form.get('section').setValue(this.editdata.section_name);
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('#c5').trigger('click');
    $('#addt_3').addClass('active');
  }
  createForm() {
    this.form = this.fb.group({
      editid: new FormControl(),
      section: new FormControl('', [Validators.required,]),
    });
  }
submit(){
  this.section =false;
  if (this.form.getRawValue().section == '')
    this.section = true
    if (this.section == false) {
      var pwd = {
        section: this.form.value.section,
        editid: this.form.value.editid,
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/update_school_sections`, pwd).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg">School Section');
          $('#errortext').html(data.message);
          this.form.reset();
        }
        else if (data.status == true) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">School Section');
            $('#errortext').html(data.message);
          localStorage.setItem('set_editsections', JSON.stringify(''));
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}
}

