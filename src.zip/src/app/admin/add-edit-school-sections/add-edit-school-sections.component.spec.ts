import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSchoolSectionsComponent } from './add-edit-school-sections.component';

describe('AddEditSchoolSectionsComponent', () => {
  let component: AddEditSchoolSectionsComponent;
  let fixture: ComponentFixture<AddEditSchoolSectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditSchoolSectionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditSchoolSectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
