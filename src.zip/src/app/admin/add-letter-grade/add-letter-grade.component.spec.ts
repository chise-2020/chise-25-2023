import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLetterGradeComponent } from './add-letter-grade.component';

describe('AddLetterGradeComponent', () => {
  let component: AddLetterGradeComponent;
  let fixture: ComponentFixture<AddLetterGradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddLetterGradeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLetterGradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
