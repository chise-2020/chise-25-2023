import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-add-letter-grade',
  templateUrl: './add-letter-grade.component.html',
  styleUrls: ['./add-letter-grade.component.css']
})
export class AddLetterGradeComponent implements OnInit {
  form: FormGroup;
  letter_grade = false;
  editdata :any;
  url = this.api.geturl();
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation

  }
  ngOnInit(): void { 
    this.editdata = JSON.parse(localStorage.getItem('set_editlettergrade'));
    if(this.editdata.length==0)
    {
      $('#headdyn').html('Add Letter Grade');
    }else
    {
      $('#headdyn').html('Edit Letter Grade');
    }
    this.form.get('editid').setValue(this.editdata.id);
    this.form.get('letter_grade').setValue(this.editdata.letter_grade);
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('#c5').trigger('click');
    $('#addt_3').addClass('active');
  }
  createForm() {
    this.form = this.fb.group({
      editid: new FormControl(),
      letter_grade: new FormControl('', [Validators.required,]),
    });
  }
submit(){
  this.letter_grade =false;
  if (this.form.getRawValue().letter_grade == '')
    this.letter_grade = true
    if (this.letter_grade == false) {
      var pwd = {
        letter_grade: this.form.value.letter_grade,
        editid: this.form.value.editid,
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/add_lettergrade`, pwd).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          //this.oldPassword= true
          $('#pass_pop').trigger('click');
          $('#new-pop').trigger('click');
          $('#new_pop_text').html('<img src="assets/images/block.svg">  Letter Grade ');
          $('#new_pop_html').html(data.message);
          this.form.reset();
        }
        else if (data.status == true) {
          $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          localStorage.setItem('set_editlettergrade', JSON.stringify(''));
          $('#modal_pass').html('<img src="assets/images/success.svg"> Letter Grade ');
          $('#errortext').html(data.message);
          this.form.reset();
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}
}
