import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-alumni-overview',
  templateUrl: './alumni-overview.component.html',
  styleUrls: ['./alumni-overview.component.css']
})
export class AlumniOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    $('#c1').trigger('click');
    $('#s3').trigger('click');
    $('.sdebar').css('display','none');
  }

}
