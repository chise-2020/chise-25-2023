import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-admin-addedit-schoolname',
  templateUrl: './admin-addedit-schoolname.component.html',
  styleUrls: ['./admin-addedit-schoolname.component.css']
})
export class AdminAddeditSchoolnameComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  schooldata: any = [];
  form: FormGroup;//initializing form
  school_name = false
  school_code = false
  school_type=false
  update_id = false
  error = false
  text=''
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
   
    console.log(localStorage.getItem('set_schoolname'))
    this.schooldata = JSON.parse(localStorage.getItem('set_schoolname'));
    
    if (this.schooldata.length==0){
    // if ((localStorage.getItem('set_schoolname') == null) || (localStorage.getItem('set_schoolname') == ' ')  )  {
      $('#c5').trigger('click');
      $('#addt_5').addClass('active');
      
      $('#headdyn').html("Add School Name ");
      this.text='Add';
    } else {
      this.text='Edit';
      $('#c1').trigger('click');
      $('#s5').trigger('click');
      $('#e11').css('display', 'block');
      $('#schoolname').addClass('active');
      $('#headdyn').html("Edit School Name ");
      this.form.get('update_id').setValue(this.schooldata.school_id);
      this.form.get('school_name').setValue(this.schooldata.school_name);
      this.form.get('school_type').setValue(this.schooldata.school_type);
    }
  }
  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      school_name: new FormControl('', [Validators.required,]),
      school_type: new FormControl('', [Validators.required,]),
    });
  }
  //
  //submitting function
  submit() {
    var path=localStorage.setItem('set_editpath', JSON.stringify('school_name'));
    this.error = this.school_name = this.school_code = false;
    if (this.form.getRawValue().school_name == '')
    {
      this.school_name = true
      this.error = true
    }
    if (this.form.getRawValue().school_type == '')
    {
      this.school_type = true
      this.error = true
    }
      if (this.error == false) {
        var value = this.form.getRawValue()
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_schoolname`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg">School Name');
            $('#errortext').html(data.message);
            localStorage.setItem('set_schoolname', JSON.stringify(''));
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">School Name');
            $('#errortext').html(data.message);
            localStorage.setItem('set_schoolname', JSON.stringify(''));
          }
        }, err => {
          $('.pageloader').hide();
        })
      }
  }
  //

}
