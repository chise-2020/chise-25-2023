import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddeditSchoolnameComponent } from './admin-addedit-schoolname.component';

describe('AdminAddeditSchoolnameComponent', () => {
  let component: AdminAddeditSchoolnameComponent;
  let fixture: ComponentFixture<AdminAddeditSchoolnameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddeditSchoolnameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddeditSchoolnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
