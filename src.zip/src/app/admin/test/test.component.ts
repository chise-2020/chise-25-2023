import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

import { IDropdownSettings} from 'ng-multiselect-dropdown';
declare var $: any;
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};

  dataset: any = [];
  data: any =[];
  url = this.api.geturl();
  fakeArray: any;
  constructor(private api: ApiService, private fb: FormBuilder,private http: HttpClient,private router: Router,) 
  { 
    // this.createForm();
  }

  ngOnInit(): void {

    this.dropdownList = [
      { item_id: 1, item_text: 'Mumbai' },
      { item_id: 2, item_text: 'Bangaluru' },
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' },
      { item_id: 5, item_text: 'New Delhi' }
    ];
    this.selectedItems = [
      { item_id: 3, item_text: 'Pune' },
      { item_id: 4, item_text: 'Navsari' }
    ];
   
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };   


// this.chat();
    $(".filter-option-inner-inner").click(function () {
      $(".dropdown-menu").toggle();
      //              $(".dropdown-menu").css(""display": "none"");
  });
  //          $('.file-upload').file_upload();




  $(".labels").click(function () {
      $(".side-menu").toggleClass("side-menuzz");
  });

  $(".close-btn").click(function () {
      $(".side-menu").toggleClass("side-menuzz");

  });

  $(".controls").click(function () {
      $("input").addClass("block");
  });




  /**/
  $(document).ready(function () {
      $('#stepa').trigger('click');
  })
  function move(id, id2) {
      $('#' + id + '').trigger('click');
      $('#' + id2 + '').css('background-color', '#72b96c');
  }
  function move1(id, id2) {
      $('#' + id + '').trigger('click');
      $('#' + id2 + '').css('background-color', '#d9e3f7');
  }
  const tabs = document.querySelectorAll('[data-tab-target]')
  const tabContents = document.querySelectorAll('[data-tab-content]')

  // tabs.forEach(tab => {
  //     tab.addEventListener('click', () => {
  //         const target = document.querySelector(tab.dataset.tabTarget)
  //         tabContents.forEach(tabContent => {
  //             tabContent.classList.remove('active')
  //         })
  //         tabs.forEach(tab => {
  //             tab.classList.remove('active')
  //         })
  //         tab.classList.add('active')
  //         target.classList.add('active')
  //     })
  // })
  }
changes(){
  // alert($('#session_num').val());
  var sess= $('#session_num').val();
  this.setsession(sess);
  
}
setsession(sess){
  this.fakeArray = Array(parseInt(sess));
  for (let i = 0; i < sess; i++) {
   
            }
}
chat(){
  var type = {
    user_id:''// request post data
  }
 
  // $('.pageloader').show();
  this.http.post<any>(`${this.url}/chat`, type).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    this.data =  data
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
 
onItemSelect(item: any) {
  console.log(item);
}
onSelectAll(items: any) {
  console.log(items);
}

}
