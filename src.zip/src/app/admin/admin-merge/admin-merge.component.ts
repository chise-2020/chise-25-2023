import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-admin-merge',
  templateUrl: './admin-merge.component.html',
  styleUrls: ['./admin-merge.component.css']
})
export class AdminMergeComponent implements OnInit {
  url = this.api.geturl();
  parent:any[];
 record_suggestion: any = [];
 merged_record: any = [];
 pageOfItems: any = [];
 pageOfItems1: any = [];
 yourArray: any = [];
 yourArray1: any = [];
  constructor(private api: ApiService,private fb: FormBuilder,private router: Router,private http: HttpClient ,) {
    
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    // $('.sdebar').css('display','none');
    // $('#c4').trigger('click');
    $('#dropdownMenu16').addClass('active');// menu highlight
    // this.getrequest()
    this.getrecords()
  }
  getrequest()
  {
    var value={
      parentid: '',
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`,  value).subscribe(data => {
      $('.pageloader').hide();
      this.parent = data.parent
      }, err => {
        $('.pageloader').hide();
      })
  }

  merge_record()
  {
    var yourArray=[];
    $("input:checkbox[name=mrge]:checked").each(function(){
      yourArray.push($(this).val());
  });
    var value={
      ids: yourArray,
      parentid: $('#parent').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/merge_record`,  value).subscribe(data => {
      $('.pageloader').hide();
      this.getrecords()
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/success.svg"> Merge Record');
      $('#errortext').html('Successfully merged old registration record.');
      $('.pageloader').hide();
      }, err => {
        $('.pageloader').hide();
      })
  }

  unmerge_record()
  {
    var yourArray1=[];
    $("input:checkbox[name=unmrge]:checked").each(function(){
      yourArray1.push($(this).val());
  });
    var value={
      ids:yourArray1,
      parentid: $('#parent').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/unmerge_record`,  value).subscribe(data => {
      $('.pageloader').hide();
      this.getrecords()
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/success.svg"> Unmerge Record');
      $('#errortext').html('Successfully unmerged old registration record.');
      $('.pageloader').hide();
      }, err => {
        $('.pageloader').hide();
      })
  }
  getrecords()
  {
    var value={
      parentid:'',
    }
    //  $('#parent').val()
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/merge_unmerge`,  value).subscribe(data => {
      $('.pageloader').hide();
      // this.record_suggestion = data.record_suggestion
      this.merged_record = data.merged_record
      // $('#guarddata').html(data.html)
      }, err => {
        $('.pageloader').hide();
      })

  }

//to edit page
previewPage(data) {
  console.log(data)
  localStorage.setItem('set_edit_oldreg', JSON.stringify(data));//storing data in session
  this.router.navigate(['edit-old-registration-records/']);

}
//
//setting value of filter
setval(type,val2)
{
  $('#ff').html(val2);
  $('#type').val(type);
  $('.dropdown-item').removeClass('active');
  $('.'+type).addClass('active');
}
//
//search function
search(){
 var searchval=$('#value').val();
 if(searchval=='')
 {
   var search=0;
   $('#ff').html('Filter Unselected');
 }
 else
 var search=1;
  var user_id = {
    type : $('#type').val(),
    search : search,
    value : $('#value').val(),
    parentid: $('#parent').val(),
  }
  $('.pageloader').show();
   this.http.post<any>(`${this.url}/merge_unmerge`,  user_id   ).subscribe(data => {
    $('.pageloader').hide();
    this.merged_record = data.merged_record
    $('#guarddata').html(data.html)
  }, err => {
    $('.pageloader').hide();
  })
}
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

onChangePage1(pageOfItems1: Array<any>) {
  // update current page of items
  this.pageOfItems1 = pageOfItems1;
}

}
