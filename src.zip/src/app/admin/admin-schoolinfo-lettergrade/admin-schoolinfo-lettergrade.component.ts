import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-schoolinfo-lettergrade',
  templateUrl: './admin-schoolinfo-lettergrade.component.html',
  styleUrls: ['./admin-schoolinfo-lettergrade.component.css']
})
export class AdminSchoolinfoLettergradeComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  lettergradeList: any = [];
  items = [];
  years= [];
  exe=0;
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
   
  }

  get_year() {
    var academic_term = $('#academic_term').val();
    var user_id = {
      term: academic_term
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, user_id).subscribe(data => {
      $('.pageloader').hide();
      $('#termyear').css('display', '');
      $('#actdetails').css('display', 'none');
      this.years = data.year
    }, err => {
      $('.pageloader').hide();
    })
  }
    getDatas() {
      console.log(this.data.user_id)
      var type = {
        term: $('#academic_term').val(),
        year: $('#academic_year').val(),
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/letter_grades`, type).subscribe(data => {
        $('.pageloader').hide();
        this.lettergradeList = data.user
        $('#showcount').html(data.count);
        this.cumulative=data.user.length;
        if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
          this.exe =1;
        }else{
          this.exe =0; 
        }
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
    }
  //to edit page
  previewPage(data) {
    console.log(data)
    localStorage.setItem('set_lettergrade', JSON.stringify(data));//storing data in session
    console.log('data from list')
    this.router.navigate(['edit-letter-grade/']);

  }
  //
  //deleting users
  deleteData(data) {
    $('#deletebttn').trigger('click');
    var user = {
      tablename : 'students',
      fieldid: data.student_id,
      fieldname: 'student_id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
       term: $('#academic_term').val(),
       year: $('#academic_year').val(),
     }
     $('.pageloader').show();
      this.http.post<any>(`${this.url}/letter_grades`,  user_id   ).subscribe(data => {
       $('.pageloader').hide();
       this.lettergradeList = data.user
       $('#showcount').html(data.count);
       if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
     }, err => {
       $('.pageloader').hide();
     })
   }
   //
 //exporting the selected data as csv
 export_data() {
    var selected_array=['full_names','academic_year','grade','school_name','program_name'];
    var header_array=['Student','Year','Grade','School','ChiS&E Track'];
    this.api.downloadFile(this.lettergradeList,selected_array,header_array, 'letter_grades');
}
//
get_lettergradedetails(data){
  localStorage.setItem('set_student_id', JSON.stringify(data.student_id));//storing data in session
  this.router.navigate(['letter-grades-details/']);

}
   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}
}
