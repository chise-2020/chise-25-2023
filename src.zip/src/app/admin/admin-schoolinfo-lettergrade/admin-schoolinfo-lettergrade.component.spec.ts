import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoLettergradeComponent } from './admin-schoolinfo-lettergrade.component';

describe('AdminSchoolinfoLettergradeComponent', () => {
  let component: AdminSchoolinfoLettergradeComponent;
  let fixture: ComponentFixture<AdminSchoolinfoLettergradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoLettergradeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoLettergradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
