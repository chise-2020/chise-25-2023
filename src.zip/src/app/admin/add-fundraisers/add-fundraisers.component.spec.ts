import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFundraisersComponent } from './add-fundraisers.component';

describe('AddFundraisersComponent', () => {
  let component: AddFundraisersComponent;
  let fixture: ComponentFixture<AddFundraisersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddFundraisersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFundraisersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
