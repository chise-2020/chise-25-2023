import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-add-fundraisers',
  templateUrl: './add-fundraisers.component.html',
  styleUrls: ['./add-fundraisers.component.css']
})
export class AddFundraisersComponent implements OnInit {
  url = this.api.geturl();
  form: FormGroup;//initializing form
  UserData: any;
  chise_events: any;
  chise_event=false;
  target=false;
  raised_so_far=false;
  error=false;
  fund_list: any=[];
  exe: number;
  
  logdata: any=[];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }
  ngOnInit(): void {
    var path=localStorage.setItem('set_editpath', JSON.stringify('fundraiser'));

    this.getData()
     $('#dropdownMenu29').addClass('active');
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
      $('#dropdownMenu29').addClass('active');
    this.logdata = JSON.parse(localStorage.getItem('set_fundid'));
    if (this.logdata == '') {
      $('#tp_section').html("Add CHIS&E FUNDRAISERS");
    } else {
      $('#tp_section').html("Edit CHIS&E FUNDRAISERS ");
    }
      this.form.get('fundid').setValue(this.logdata.id);
    this.form.get('chise_event').setValue(this.logdata.event_id);
    this.form.get('target').setValue(this.logdata.target);
    this.form.get('raised_so_far').setValue(this.logdata.raised_so_far);
     
  }

  getData(){
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_events`,this.form.value).subscribe(data => {
      $('.pageloader').hide();
  this.chise_events=data.events
    }, err => {
      $('.pageloader').hide();
    }
    )
  }
//creating form
createForm() {
  this.form = this.fb.group({
    chise_event: new FormControl('', [Validators.required,]),
    target: new FormControl('', [Validators.required,]),
    raised_so_far: new FormControl('', [Validators.required,]),
    fundid: new FormControl('', [Validators.required,]),
  });
}
//
Onsubmit(){
  if (!($('#chise_event').val())) {
    $('#chise_event').addClass('error');
    this.error = true;
  } else {
    $('#chise_event').removeClass('error');
    this.error = false;
  }
   if (!($('#target').val())) {
    $('#target').addClass('error');
    this.error = true;
  } else {
    $('#target').removeClass('error');
    this.error = false;
  }
  if (!($('#raised_so_far').val())) {
    $('#raised_so_far').addClass('error');
    this.error = true;
  } else {
    $('#raised_so_far').removeClass('error');
    this.error = false;
  }
 
    if (this.error == false) {
     
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/add_fundraised`,this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          //this.oldPassword= true
          $('#new-pop').trigger('click');
          $('#new_pop_text').html('<img src="assets/images/block.svg">ChiS&E Fundraisers');
          $('#new_pop_html').html(data.message);
        }
        else if (data.status == true) {
    
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">ChiS&E Fundraisers');
          $('#errortext').html(data.message);
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}

}
