import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
@Component({
  selector: 'app-add-events',
  templateUrl: './add-events.component.html',
  styleUrls: ['./add-events.component.css']
})
export class AddEventsComponent implements OnInit {
  url = this.api.geturl();
  public Editor = ClassicEditor;
  public sourceData: string;
  form: FormGroup;//initializing form
  UserData: any;
  title=false;
  cumulative1=0;
  cumulative=0;
  phone_number=false;
  start_date=false;
  email=false;
  details=false;
  place=false;
  error= false;
  end_date=false;
  logdata: any=[];
 event_list: any=[];
  exe: number;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }
  ngOnInit(): void {
    var path=localStorage.setItem('set_editpath', JSON.stringify('events'));

    this.sourceData = '';
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
  
    this.form.get('user_id').setValue(this.UserData.user_id);
    $('#dropdownMenu29').addClass('active');
    this.logdata = JSON.parse(localStorage.getItem('set_evenid'));
    if (this.logdata =="") {
      $('#tp_section').html("Add CHIS&E EVENTS");
    } else {
      $('#tp_section').html("Edit CHIS&E EVENTS ");
      this.form.get('event_id').setValue(this.logdata.id);
    this.form.get('title').setValue(this.logdata.title);
    this.form.get('phone_number').setValue(this.logdata.phone_number);
    this.form.get('email').setValue(this.logdata.email);
    this.form.get('place').setValue(this.logdata.place);
    this.form.get('start_date').setValue(this.logdata.start_date);
    this.form.get('end_date').setValue(this.logdata.end_date);
    this.sourceData=this.logdata.details;
    }
  }
//creating form
createForm() {
  this.form = this.fb.group({
    title: new FormControl('', [Validators.required,]),
    phone_number: new FormControl('', [Validators.required,]),
    place: new FormControl('', [Validators.required,]),
    email: new FormControl('', [Validators.required,]),
    start_date: new FormControl('', [Validators.required,]),
    details: new FormControl('', [Validators.required,]),
    user_id: new FormControl('', [Validators.required,]),
    end_date: new FormControl('', [Validators.required,]),
    event_id:new FormControl('', ),
  });
}
//
submit(){
  if (!($('#title').val())) {
    $('#title').addClass('error');
    this.error = true;
  } else {
    $('#title').removeClass('error');
    this.error = false;
  }
   if (!($('#phone_number').val())) {
    $('#phone_number').addClass('error');
    this.error = true;
  } else {
    $('#phone_number').removeClass('error');
    this.error = false;
  }
  if (!($('#place').val())) {
    $('#place').addClass('error');
    this.error = true;
  } else {
    $('#place').removeClass('error');
    this.error = false;
  }
  if (!($('#start_date').val())) {
    $('#start_date').addClass('error');
    this.error = true;
  } else {
    $('#start_date').removeClass('error');
    this.error = false;
  }
  if (!($('#email').val())) {
    $('#email').addClass('error');
    this.error = true;
  } else {
    $('#email').removeClass('error');
    this.error = false;
  }
  if (!($('#details').val())) {
    $('#details').addClass('error');
    this.error = true;
  } else {
    $('#details').removeClass('error');
    this.error = false;
  }
  if (!($('#end_date').val())) {
    $('#end_date').addClass('error');
    this.error = true;
  } else {
    $('#end_date').removeClass('error');
    this.error = false;
  }
  
    if (this.error == false) {
     
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/add_events`,this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          //this.oldPassword= true
          $('#new-pop').trigger('click');
          $('#new_pop_text').html('<img src="assets/images/block.svg">ChiS&E Events');
          $('#new_pop_html').html(data.message);
          this.router.navigate(['list-events/']);

          
        }
        else if (data.status == true) {
    
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">ChiS&E Events');
          $('#errortext').html(data.message);
          this.form.reset();
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}

changes(){
      //guardian validation
      var inputVal = ($('#phone_number').val());
      // $('#phone' + id).replace(/[^0-9\.]/g,'');
      var regExp = /[a-zA-Z]/g;
      if (regExp.test(inputVal)) {
        //letters found
        $('#phone_number').addClass('error');
        this.error = true;
      } else {
        $('#phone_number').removeClass('error');
        this.error = false;
      }
  
      $('#phone_number').val($('#phone_number').val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));
  
  
}


}
