import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-alumniinfo-details',
  templateUrl: './admin-alumniinfo-details.component.html',
  styleUrls: ['./admin-alumniinfo-details.component.css']
})
export class AdminAlumniinfoDetailsComponent  implements OnInit {
  data: any = [];
  url = this.api.geturl();
  alumniList: any = [];
  items = [];
  exe=0;
  pageOfItems: Array<any>;
  alumnidata: any;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#c1').trigger('click');
    // $('#s3').trigger('click');
    // $('.sdebar').css('display','none');
    localStorage.setItem('set_alumnilist', JSON.stringify(''));
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.alumnidata = JSON.parse(localStorage.getItem('set_alumniid'));
    this.getDatas()
  }
  
  
  getDatas() {
   
      console.log(this.alumnidata)
      var type = {
        user_id: this.alumnidata// request post data
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/alumni_details`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.alumniList = data.user
      $('#showcount').html(data.count);
      $('#showname').html(data.full_name);
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
//to edit page
previewPage(data) {
  console.log(data)
  localStorage.setItem('set_alumnilist', JSON.stringify(data));//storing data in session
  this.router.navigate(['admin-alumini-records/']);

}
//

 //setting value of filter
 setval(type,val2)
 {
   $('#ff').html(val2);
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
   var user_id = {
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
     user_id: this.alumnidata
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/alumni_details`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.alumniList = data.user
     $('#showcount').html(data.count);
     $('#showname').html(data.full_name);
     if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
   }, err => {
     $('.pageloader').hide();
   })
 }
 //
 //exporting the selected data as csv
 export_data() {
  // alert('yes')
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
  var user_id = {
    type : $('#type').val(),
    search : search,
    value : $('#value').val(),
    user_id: this.alumnidata
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/alumni_details`, user_id).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
    // this.list = data.user;
    var selected_array=['track','academic_term','academic_year','school_name','grade','math_track','math_grade','science_track','science_grade','parent_name','phone'];
    var header_array=['Track','Academic Term','Academic Year','School Name','Grade','Math Track','Math Grade','Science Track','Science Grade','Registered Parent','Phone'];
    this.api.downloadFile(data.user,selected_array,header_array, 'alumni_record_details');
    
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
//

 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}
