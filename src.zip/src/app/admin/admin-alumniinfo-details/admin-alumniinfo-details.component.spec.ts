import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAlumniinfoDetailsComponent } from './admin-alumniinfo-details.component';

describe('AdminAlumniinfoDetailsComponent', () => {
  let component: AdminAlumniinfoDetailsComponent;
  let fixture: ComponentFixture<AdminAlumniinfoDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAlumniinfoDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAlumniinfoDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
