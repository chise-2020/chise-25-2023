import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminChiseStatusComponent } from './admin-chise-status.component';

describe('AdminChiseStatusComponent', () => {
  let component: AdminChiseStatusComponent;
  let fixture: ComponentFixture<AdminChiseStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminChiseStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminChiseStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
