import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-chise-status',
  templateUrl: './admin-chise-status.component.html',
  styleUrls: ['./admin-chise-status.component.css']
})
export class AdminChiseStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    // $('.penicon').css('display','none');
    $('.penicon').css('display','none');
    $('#chise_stat').addClass('active');// menu highlight
  }

}
