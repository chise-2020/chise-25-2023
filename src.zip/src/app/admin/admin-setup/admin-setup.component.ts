import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-admin-setup',
  templateUrl: './admin-setup.component.html',
  styleUrls: ['./admin-setup.component.css']
})
export class AdminSetupComponent implements OnInit {
  url = this.api.geturl();
  isChecked: false;
  logdata: any = [];
  academicform: FormGroup;
  academicterm:false;
  academicyear:false;
  years: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {
    // this.academicform = this.fb.group({
    //   academicterm: new FormControl('', [Validators.required,]),
    //   academicyear: new FormControl('', [Validators.required,]),
    // });


  }

  ngOnInit(): void {
    this.getregsettings();
    localStorage.setItem('online_reg', JSON.stringify(''));
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if (this.logdata.class == 'executive 1') {
      $('.custom-radio').css('pointer-events', 'none');
      $('.termcheck').addClass('textback');
      $('#current').attr("disabled", true);
      $('#next').attr("disabled", true);
      $('#c_current').attr("disabled", true);
      $('.slider').addClass('greyed-slider');
      $('#cradio').addClass('greyed-radio');
    }
  }


  get_year() {
    var academic_term = $('#academicterm').val();
    var user_id = {
      term: academic_term
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, user_id).subscribe(data => {
      $('.pageloader').hide();
      //$('#academic_year').html('');

      this.years = data.year
    }, err => {
      $('.pageloader').hide();
    })
  }

  saveval()
  {
    var value={
      academicterm:$('#academicterm').val(),
      academicyear:$('#academic_year').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/save_terms`,value).subscribe(data => {
      localStorage.setItem('acad_yr', JSON.stringify($('#academicterm').val()));
        localStorage.setItem('acad_term', JSON.stringify($('#academic_year').val()));
      if (data.status == false) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/block.svg">Registration Settings');
        $('#errortext').html('Oops!  Save failed!<br/> Please try again!');
  
      }
      else if (data.status == true) {
        $('#pass_pop').trigger('click');
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Registration Settings');
        $('#errortext').html('Successfully saved!');
      }
      $('.pageloader').hide();
    }, err => {
      $('.pageloader').hide();
    })
    

  }
  getregsettings()
  {
    var value='';
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_online_stat`, value).subscribe(data => {
      $('.pageloader').hide();
      localStorage.setItem('acad_yr', JSON.stringify(data.academic_year));
      localStorage.setItem('acad_term', JSON.stringify(data.academic_term));

     $('#academicterm').val(data.academic_term);
     this.years =[data.academic_year];
     $('#academic_year').val(data.academic_year);
      if (data.regstatus == 1) {
        $('#regclosed:checkbox').prop('checked','true');
        $('#regstat').html('<span class="op">OPEN<span>');
      }else
      {
        //$('#regclosed:checkbox').prop('checked','false');
        $('#regstat').html('<span class="clo" style="font-size: revert !important;padding-left: 20px;">CLOSED<span>');
      }

      var value = {
        term: 'current',
        activate: data.onlinereg_status,
        type: 'save',
        section: 'regi'
      }
      localStorage.setItem('online_reg', JSON.stringify(value));
    }, err => {
      $('.pageloader').hide();
    })

  }


setval()
{
  $('#cnfrmtitle').html('<img src="assets/images/alert.svg"> Online Registration');
  $('#regbutton').trigger('click');
  if($('#regclosed:checkbox:checked').length > 0)
  {
    $('#modelcontent').html('With this selected switch position, you will allow ChiS&E Registrations until you stop it again!<br><br>Are you sure of this?');
    var active=1;
    $('#regstat').html('<span class="op">OPEN<span>');
  }
  else
  {
    var active=0;
    $('#modelcontent').html('With this selected switch position, you will stop ChiS&E Registrations until you start it again!<br><br>Are you sure of this?');
    $('#regstat').html('<span class="clo" style="font-size: revert !important;padding-left: 20px;">CLOSED<span>');
  }
  var value = {
    term: 'current',
    activate: active,
    type: 'save',
    section: 'regi'
  }
  localStorage.setItem('online_reg', JSON.stringify(value));
}

  send_flyermail(){
    $('#cnfrmtitle').html('<img src="assets/images/alert.svg">Registration Flyer');
    $('#regbutton').trigger('click');
    $('#modelcontent').html('With this selected switch position, the system will automatically send all ChiS&E Users Registration Flyer email notifications.<br><br>Are you sure of this?');
    $('#cnfrm_mail').css('display', 'none');
    $('#cnfrm_reg').css('display', 'none');
     $('#cnfrm_flyermail').css('display', 'block');
  }
}
