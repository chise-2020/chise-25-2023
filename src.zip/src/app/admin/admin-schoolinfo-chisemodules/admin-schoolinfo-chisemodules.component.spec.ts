import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoChisemodulesComponent } from './admin-schoolinfo-chisemodules.component';

describe('AdminSchoolinfoChisemodulesComponent', () => {
  let component: AdminSchoolinfoChisemodulesComponent;
  let fixture: ComponentFixture<AdminSchoolinfoChisemodulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoChisemodulesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoChisemodulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
