import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
declare var $: any;
@Component({
  selector: 'app-test-table',
  templateUrl: './test-table.component.html',
  styleUrls: ['./test-table.component.css']
})
export class TestTableComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  registerList: any = [];
  items = [];
  exe=0;
  pageOfItems: Array<any>;
  column: any;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  testform: FormGroup;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
    this.testform = this.fb.group({
      table_name: new FormControl('', [Validators.required,]),
      attributes: new FormControl('', [Validators.required,]),
    })
    // this.getDatas()
    
    this.dropdownList = [
      // { item_id: 1, item_text: 'Mumbai' },
      // { item_id: 2, item_text: 'Bangaluru' },
      // { item_id: 3, item_text: 'Pune' },
      // { item_id: 4, item_text: 'Navsari' },
      // { item_id: 5, item_text: 'New Delhi' }
    ];
    // this.selectedItems = [
    //   { item_id: 3, item_text: 'Pune' },
    //   { item_id: 4, item_text: 'Navsari' }
    // ];
   
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };   

  }
  
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      type : "",
      search : 0,
      value : "",// request post data
      table_name:$('#table_name').val()
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_table`, type).subscribe(data => {
      // console.log(data)
      $('.pageloader').hide();
      // this.registerList = data.user
      // this.column=data.columns
      this.dropdownList=data.columns;
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  OnSubmit() {
    console.log(this.testform.value.attributes)
    
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_tabledata`, this.testform.value).subscribe(data => {
      // console.log(data)
      $('.pageloader').hide();
      this.registerList = data.user
      this.column=data.columns
      // this.dropdownList=data.columns;
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  // change_table(items: any) {
  // console.log(items);
  // $('.show').css('display','none');
  // $('.'+items).css('display','block');
  // }
  export_data(){
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_tabledata`, this.testform.value).subscribe(data => {
      // console.log(data)
      $('.pageloader').hide();
      this.registerList = data.user
      this.column=data.columns
      // this.dropdownList=data.columns;
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      $('#showcount').html(data.count);
      let arr = data.user;
      let arr1 = data.columns;
      for (var val of arr) {
        // console.log(val); // prints values: 10, 20, 30, 40
        for (var val1 of arr1) {
          console.log(val[val1]);
        }
      }
      var selected_array = data.columns;
      var header_array = [data.columns];
      this.api.downloadFile(data.user, selected_array, header_array, 'table_Datas');
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
}
