import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-list-survey',
  templateUrl: './list-survey.component.html',
  styleUrls: ['./list-survey.component.css']
})
export class ListSurveyComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  subscriptionList: any = [];
  items = [];
  cumulative=0;
  exe=0;
  survey_list: any=[];
  UserData: any=[];
  cumulative1=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }


  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    if(this.data.class!='admin')
    {
      this.exe =1;
      
    }
    this.getData();
  }
  getData(){
    var type = {
      id: ''// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_survey`,type).subscribe(data => {
      $('.pageloader').hide();
      this.survey_list=data.survey_list
      this.cumulative1=data.survey_list.length;
      this.cumulative=data.survey_list.length;
      
    }, err => {
      $('.pageloader').hide();
    }
    )
  }
    reset_user() {
      localStorage.setItem('set_survey', JSON.stringify(''));
      this.router.navigate(['add-services/']);
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

 


    export_data() {
      var selected_array=['title','phone_num','date','place','email','details'];
      var header_array=['Title','Contact Number','Date', 'Place','Email','Details'];
      this.api.downloadFile(this.survey_list,selected_array,header_array, 'ChiS&E Events');
   }

   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){

    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
     }
     $('.pageloader').show();
     this.http.post<any>(`${this.url}/get_survey`,user_id).subscribe(data => {
       $('.pageloader').hide();
       this.survey_list=data.survey_list
       this.cumulative1=data.survey_list.length;
     
    }, err => {
      $('.pageloader').hide();
    }
    )
   }

   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

  //to edit page
  previewPage(data) {
    localStorage.setItem('set_survey', JSON.stringify(data));//storing data in session
    this.router.navigate(['add-services/']);

  }

  deleteData(data){
    $('#deletebttn').trigger('click');
    var user = {
      tablename : 'chise_survey',
      fieldid: data.id,
      fieldname: 'id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));
  }
  //
  }




