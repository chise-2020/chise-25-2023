import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProgramReviewComponent } from './admin-program-review.component';

describe('AdminProgramReviewComponent', () => {
  let component: AdminProgramReviewComponent;
  let fixture: ComponentFixture<AdminProgramReviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminProgramReviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminProgramReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
