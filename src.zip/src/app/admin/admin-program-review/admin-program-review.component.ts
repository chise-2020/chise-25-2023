import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder,FormArray, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-admin-program-review',
  templateUrl: './admin-program-review.component.html',
  styleUrls: ['./admin-program-review.component.css']
})
export class AdminProgramReviewComponent implements OnInit {
  url = this.api.geturl();
  track_id_list: any; 
  track_session: any;
  trackForm: FormGroup;
  materialForm: FormGroup;
  officeForm: FormGroup;
  sessionForm: FormGroup;
  fakeArray: any[];
  acad_yr :any;
  acad_term :any;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    this.acad_yr = JSON.parse(localStorage.getItem('acad_yr'));
    this.acad_term = JSON.parse(localStorage.getItem('acad_term'));
    this.getdetails();
    localStorage.setItem('edit_track', JSON.stringify(0));
    $('#edit_track').attr('disabled', true);
    $('#edit_track').addClass('textback'); 
    $('#delete_track').attr('disabled', true);
    $('#delete_track').addClass('textback');
  }
  getdetails() {
    var userid = {
      user_id: ''
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.track_id_list = data.track_id_list
    }, err => {
      $('.pageloader').hide();
    })
  }
  get_track() {
    var userid = {
      trackid: $('#trackids').val()
    }
    // alert($('#trackids').val());
    // $('#track_head').html( $('#trackids').val());
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_tracks`, userid).subscribe(data => {
      $('.pageloader').hide();
      $('#edit_track').attr('disabled', false);
      $('#delete_track').attr('disabled', false);
      $('#edit_track').removeClass('textback');
      $('#delete_track').removeClass('textback');
      $('.track-scroll').html(data.html)
      //$('#track_module').html(data.list.program_name)
      //$('#track_slots').html(data.list.track_slot)
      // $('#material_distribution').html(data.list.material_distribution) 
      //  $('#assigned_teachers').html(data.list.assigned_teacher) 
      //  this.track_session = data.list.track_sessions

    }, err => {
      $('.pageloader').hide();
    })
  }
  edit_track(){
    var editval=$('#trackids').val();
        localStorage.setItem('edit_trackid', JSON.stringify(editval));
        window.location.reload();
       
  }
  delete_track(){
    var userid = {
      trackid: $('#trackids').val()
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/delete_track`, userid).subscribe(data => {
      $('.pageloader').hide();
      if (data.status == false) {
        $('#alerttitle').html('<img src="assets/images/block.svg">Program Review');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      else if (data.status == true) {
        $('#pass_pop').trigger('click');
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Program Review');
        $('#errortext').html(data.message);
      }
  }, err => {
      $('.pageloader').hide();
    })
  }
}
