import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAllregistrationRecordsComponent } from './admin-allregistration-records.component';

describe('AdminAllregistrationRecordsComponent', () => {
  let component: AdminAllregistrationRecordsComponent;
  let fixture: ComponentFixture<AdminAllregistrationRecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAllregistrationRecordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAllregistrationRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
