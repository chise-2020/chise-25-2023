import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-list-events',
  templateUrl: './list-events.component.html',
  styleUrls: ['./list-events.component.css']
})
export class ListEventsComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  subscriptionList: any = [];
  items = [];
  cumulative=0;
  exe=0;
  event_list: any=[];
  UserData: any=[];
  cumulative1=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }


  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    if(this.data.class!='admin')
    {
      this.exe =1;
      
    }
    this.getData();
  }
    getData(){
      var type = {
        id: ''// request post data
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/list_events`,type).subscribe(data => {
        $('.pageloader').hide();
        this.event_list=data.events
        this.cumulative=data.events.length;
        this.cumulative1=data.events.length;
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
    reset_user() {
      localStorage.setItem('set_evenid', JSON.stringify(''));
      this.router.navigate(['add-events/']);
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

    deleteData(data){
      $('#deletebttn').trigger('click');
      var user = {
        tablename : 'chise_events',
        fieldid: data.id,
        fieldname: 'id'
      }
      localStorage.setItem('delete_item', JSON.stringify(user));
    }

    export_data() {
      var selected_array=['title','phone_num','date','place','email','details'];
      var header_array=['Title','Contact Number','Date', 'Place','Email','Details'];
      this.api.downloadFile(this.subscriptionList,selected_array,header_array, 'ChiS&E Events');
   }

   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){

    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
     }
     this.http.post<any>(`${this.url}/list_events`,user_id).subscribe(data => {
      $('.pageloader').hide();
      this.event_list=data.events
      this.cumulative1=data.events.length;
     }, err => {
       $('.pageloader').hide();
     })
   }

   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

  //to edit page
  previewPage(data) {
    localStorage.setItem('set_evenid', JSON.stringify(data));//storing data in session
    this.router.navigate(['add-events/']);

  }
  //
  }




