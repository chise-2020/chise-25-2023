import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-supports',
  templateUrl: './admin-supports.component.html',
  styleUrls: ['./admin-supports.component.css']
})
export class AdminSupportsComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('.sdebar').css('display','none');
    this.getDatas()
  }

  getsuport(id) {
    var type = {
      id: id// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_admin_suport`, type).subscribe(data => {
      $('.pageloader').hide();
      $('#dynamictitle').html('<img src="assets/images/alert.svg"> TICKET DETAILS');
      $('#review').html(data.html);
      $('#yesbutton').css('display','none');
      $('#nobutton').css('display','none'); 
      $('#reviewbtn').trigger('click');
    }, err => {
      $('.pageloader').hide();
    })
  
  }
  add_response(id){
    $('#support_id').val(id);
    // if((admin_res)!=" "){
    //   $('#admin_response').val(admin_res);
    // }
    $('#responsebtn').trigger('click');

  }
  add_responses(data) {
    // console.log(data)
    $('#support_id').val(data.suportid);
    $('#admin_response').val(data.admin_response);
    $('#responsebtn').trigger('click');
  }
  getDatas() {
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/admin_suport`, type).subscribe(data => {
      $('.pageloader').hide();
      this.list = data.user
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
    })
  }

//deleting schools
deleteData(data) {
 
  $('#deletebttn').trigger('click');
  var user = {
    tablename : 'admin_support',
    fieldid: data.school_id,
    fieldname: 'suportid'
  }
  localStorage.setItem('delete_item', JSON.stringify(user));
}
//
 //setting value of filter
 setval(type,val2)
 {
   $('#ff').html(val2);
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
   var user_id = {
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
   }
   $('.pageloader').show();
   this.http.post<any>(`${this.url}/admin_suport`, user_id).subscribe(data => {
     console.log(data)
     $('.pageloader').hide();
     this.list = data.user
     $('#showcount').html(data.count);
   }, err => {
     $('.pageloader').hide();
     console.log(err);
   })
 }

 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}

}
