import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSupportsComponent } from './admin-supports.component';

describe('AdminSupportsComponent', () => {
  let component: AdminSupportsComponent;
  let fixture: ComponentFixture<AdminSupportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSupportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSupportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
