import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewMergedRegistrationRecordsComponent } from './new-merged-registration-records.component';

describe('NewMergedRegistrationRecordsComponent', () => {
  let component: NewMergedRegistrationRecordsComponent;
  let fixture: ComponentFixture<NewMergedRegistrationRecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewMergedRegistrationRecordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewMergedRegistrationRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
