import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-new-merged-registration-records',
  templateUrl: './new-merged-registration-records.component.html',
  styleUrls: ['./new-merged-registration-records.component.css']
})
export class NewMergedRegistrationRecordsComponent implements OnInit {
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  dropDownForm:FormGroup;
  data: any = [];
  url = this.api.geturl();
  registerList: any = [];
  items = [];
  exe=0;
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
    localStorage.setItem('set_allregisterrecord', JSON.stringify(''));
    this.dropdownList = [
      { item_id: 'full_names', item_text: 'Student Name' },
      { item_id: 'academic_term', item_text: 'Academic Term' },
      { item_id:'academic_year', item_text: 'Academic Year' },
      { item_id: 'parent_name', item_text: 'Full Name of Registering Guardian'},
      { item_id: 'registered_on', item_text:'Date of Registration' }
    ];
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
    };   
    this.dropDownForm = this.fb.group({
      myItems: [this.selectedItems]
  });
  
    // $('#c1').trigger('click');
    // $('#s2').trigger('click');
    // $('.sdebar').css('display','none');
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.getDatas()
  }
  //filter dropdown actions
  onItemSelect(item: any) {
    if (!($('#type').val())) {
      $('#type').val(item.item_id);
    }else{
      var filter_type=$('#type').val()+','+item.item_id;
      $('#type').val(filter_type);
    }
    
}
onItemDeSelect(item: any) {
  if (!($('#type').val())) {
    $('#type').val("");
  }else{
   var str=$('#type').val();
   var final_str=str.replace(item.item_id, ""); 
   $('#type').val(final_str);
  }
}
onSelectAll(items: any) {
  // alert(items[0].item_id)
  console.log('onSelectAll', items);
  var final_str=items[0].item_id+','+items[1].item_id+','+items[2].item_id+','+items[3].item_id+','+items[4].item_id;
  $('#type').val(final_str);
}
onUnSelectAll() {
  console.log('onUnSelectAll fires');
  $('#type').val("");
}
//end
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      type : "",
      search : 0,
      value : "",// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/all_registration`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.registerList = data.user
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      $('#showcount').html(data.count);
      this.cumulative=data.user.length;
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
//to edit page
previewPage(data) {
  console.log(data)
  localStorage.setItem('set_allregisterrecord', JSON.stringify(data));//storing data in session
  this.router.navigate(['register-student-team/']);

}
//

 //setting value of filter
 setval(type,val2)
 {
   $('#ff').html(val2);
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
   var user_id = {
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/all_registration`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.registerList = data.user
     $('#showcount').html(data.count);
   }, err => {
     $('.pageloader').hide();
   })
 }
 //
  //exporting the selected data as csv
  export_data() {
      var selected_array=['track','full_names','academic_term','academic_year','grade','school_name','parent_name','registered_on'];
      var header_array=['Track','Student Name','Academic Term','Academic Year','Grade','School','Full Name of Registering Guardian','Date of Registration'];
      this.api.downloadFile(this.registerList,selected_array,header_array, 'all_registrations');
      
  }
  //
 get_filter(){
  //  alert('yes')
   
   var ftrack=$('#filter_track').val();
   var fname=$('#filter_full_name').val();
   var ac_term=$('#filter_term').val();
   var ac_year=$('#filter_year').val();
   var sname=$('#filter_school').val();
   var gr=$('#filter_grade').val();
   var parent=$('#filter_parent').val();
   var reg_on=$('#filter_regon').val();
   var type = {
    type : "notempty",
    search : 1,
    filter_type : $('#type').val(),
    value : $('#value').val(),
track:ftrack,
fullname:fname,
academic_term:ac_term,
academic_year:ac_year,
grade:gr,
school_name:sname,
parent_name:parent,
registered_on:reg_on,
  }
  // $('.pageloader').show();
  this.http.post<any>(`${this.url}/all_registration`, type).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    this.registerList = data.user
    if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
    $('#showcount').html(data.count);
    // $('#filter_track').val(ftrack);
    // $('#filter_full_name').val(fname);
  //   $('#filter_term').val(ac_term);
  //   $('#filter_year').val(ac_year);
  //  $('#filter_school').val(sname);
  //   $('#filter_name').val(gr);
  //  $('#filter_parent').val(parent);
  // $('#filter_regon').val(reg_on);
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
 }
 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}
