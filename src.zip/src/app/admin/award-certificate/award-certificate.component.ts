import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-award-certificate',
  templateUrl: './award-certificate.component.html',
  styleUrls: ['./award-certificate.component.css']
})
export class AwardCertificateComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  logdata : any = [];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('.sdebar').css('display','none');
    // $('#ca_3').trigger('click');
    $('#dropdownMenu13').addClass('active');//menu highlight
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if ((this.logdata.class == 'executive 1') || (this.logdata.class == 'executive 2') )
     {
      $('#student').attr("disabled", true);
      $('#teacher').attr("disabled", true);
      $('#student').css("pointer-events", 'none');
      $('.slider').addClass('greyed-slider');
      // $('#c_current').attr("disabled", true);
      // $('.slider').addClass('greyed-slider');
    //    $('#ca_3').trigger('click');
     }
    
  }



  saveval(vals)
  {
    if($('#'+vals+':checkbox:checked').length > 0)
    {
      var value={
        type:vals
      }
      localStorage.setItem('set_awards', JSON.stringify(value));
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/alert.svg">Award Certificate');
      $('#error-body').html('<span style="font-size:19px;">With this selected switch position, the system will automatically award all the ChiS&E Certificates now?<br><br>Are you sure of this?</span>' );
      $('#ok').css('display','none');
      // alert(vals)
      if(vals=='student'){
$('#review_btns').css('display','block');

      }else{
        $('#ok').css('display','block');
        $('#ok').html('No');
        $('#ok').removeClass('green-btn');
        $('#ok').addClass('violet-btn');
        $('#award_yesbtn').addClass('green-btn');
        $('#award_yesbtn').removeClass('violet-btn');
      }
      
      $('#award_yesbtn').css('display','block');
      // $('.pageloader').show();
      // this.http.post<any>(`${this.url}/award_certificate`,  value).subscribe(data => {
      //   $('.pageloader').hide();
        
      //   }, err => {
      //     $('.pageloader').hide();
      //   })
    }
    
  }

}
