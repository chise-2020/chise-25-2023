import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificateStudentComponent } from './certificate-student.component';

describe('CertificateStudentComponent', () => {
  let component: CertificateStudentComponent;
  let fixture: ComponentFixture<CertificateStudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificateStudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificateStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
