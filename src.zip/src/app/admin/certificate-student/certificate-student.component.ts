import { Component, OnInit, ElementRef ,ViewChild} from '@angular/core';  
import jsPDF from 'jspdf'; 
import html2canvas from 'html2canvas'; 
  declare var $: any;
@Component({
  selector: 'app-certificate-student',
  templateUrl: './certificate-student.component.html',
  styleUrls: ['./certificate-student.component.css']
})
export class CertificateStudentComponent implements OnInit {
  student_certificate: any = [];
  constructor() { }

  ngOnInit(): void {
    this.student_certificate = JSON.parse(localStorage.getItem('student_certificate'));
 console.log(this.student_certificate)
 $('#fname').html(this.student_certificate.full_names);
 $('#pname').html(this.student_certificate.program);
 $('#grade').html(this.student_certificate.program_grade);
 $('#generated').html(this.student_certificate.generated_at);
 $('#teacher').html(this.student_certificate.teacher_name);
  }
  public captureScreen()  
  {  
    var data = document.getElementById('pdfTable');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 210;   
      var pageHeight = 300;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('Certificate.pdf'); // Generated PDF   
    });  
  }  
 

}
