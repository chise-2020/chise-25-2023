import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { SlowBuffer } from 'buffer';
import { empty } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-summary-table',
  templateUrl: './summary-table.component.html',
  styleUrls: ['./summary-table.component.css']
})
export class SummaryTableComponent implements OnInit {
  url = this.api.geturl();
  val :any;
  data_all :any = [];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
    this.get_all();
  }
  
  get_all()
  {
    var datalist=
    {
    };
       $('.pageloader').show();
       this.http.post<any>(`${this.url}/get_total_count`, datalist).subscribe(data => {
        this.data_all=data.lists;
         $('.pageloader').hide();
       }, err => {
         $('.pageloader').hide();
         console.log(err);
       })

  }

  export_data(val,txt){
    var datalist=
    {
     generate_id:val,
    };
       $('.pageloader').show();
       this.http.post<any>(`${this.url}/get_all_count`, datalist).subscribe(data => {
         if(data.values.length!=0)
         this.api.downloadFile(data.values, data.selected_array, data.header_array,txt);
         $('.pageloader').hide();
       }, err => {
         $('.pageloader').hide();
         console.log(err);
       })
   }
}