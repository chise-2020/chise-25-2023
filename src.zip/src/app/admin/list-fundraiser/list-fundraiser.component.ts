import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-list-fundraiser',
  templateUrl: './list-fundraiser.component.html',
  styleUrls: ['./list-fundraiser.component.css']
})
export class ListFundraiserComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  subscriptionList: any = [];
  items = [];
  cumulative=0;
  exe=0;
  fund_list: any=[];
  UserData: any=[];
  cumulative1=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }


  ngOnInit(): void {
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    if(this.data.class!='admin')
    {
      this.exe =1;
      
    }
    this.getData();
  }
  getData(){
    // alert('in')
    var type = {
      id: ''// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_fundraisers`,type).subscribe(data => {
      $('.pageloader').hide();
      this.fund_list=data.fund_list
      this.cumulative=data.fund_list.length;
      this.cumulative1=data.fund_list.length;
      
    }, err => {
      $('.pageloader').hide();
    }
    )
  }
    reset_user() {
      localStorage.setItem('set_fundid', JSON.stringify(''));
      this.router.navigate(['add-fundraisers/']);
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    }

 

    export_data() {
      var selected_array=['title','phone_num','date','place','email','details'];
      var header_array=['Title','Contact Number','Date', 'Place','Email','Details'];
      this.api.downloadFile(this.fund_list,selected_array,header_array, 'ChiS&E Events');
   }

   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){

    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
     }
     $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_fundraisers`,user_id).subscribe(data => {
      $('.pageloader').hide();
      this.fund_list=data.fund_list
      this.cumulative1=data.fund_list.length;
     
    }, err => {
      $('.pageloader').hide();
    }
    )
   }

   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}

  //to edit page
  previewPage(data) {
    localStorage.setItem('set_fundid', JSON.stringify(data));//storing data in session
    this.router.navigate(['add-fundraisers/']);

  }

  deleteData(data){
    $('#deletebttn').trigger('click');
    var user = {
      tablename : 'chise_raised',
      fieldid: data.id,
      fieldname: 'id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));
  }
  //
  }




