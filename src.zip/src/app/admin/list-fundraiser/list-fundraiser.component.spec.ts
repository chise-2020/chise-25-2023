import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListFundraiserComponent } from './list-fundraiser.component';

describe('ListFundraiserComponent', () => {
  let component: ListFundraiserComponent;
  let fixture: ComponentFixture<ListFundraiserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListFundraiserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListFundraiserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
