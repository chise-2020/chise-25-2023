import { Component, OnInit } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { Router } from '@angular/router';
  import { ApiService } from '../../api.service';
  declare var $: any;
  
  @Component({
    selector: 'app-school-sections',
    templateUrl: './school-sections.component.html',
    styleUrls: ['./school-sections.component.css']
  })
  export class SchoolSectionsComponent implements OnInit {
    data: any = [];
    url = this.api.geturl();
    lettergradeList: any = [];
    items = [];
    exe=0;
    cumulative=0;
    cumulative1=0;
    pageOfItems: Array<any>;
    constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }
  
    ngOnInit(): void {
      localStorage.setItem('set_editsections', JSON.stringify(''));
      this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
      this.getDatas()
    }
  
    getDatas() {
      var type = {
        type: ""// request post data
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/get_school_sections`, type).subscribe(data => {
        $('.pageloader').hide();
        this.lettergradeList = data.list
        $('#showcount').html(data.count);
        this.cumulative=data.list.length;
        this.cumulative1=data.list.length;
        if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
          this.exe =1;
        }else{
          this.exe =0; 
        }
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
    }
  //to edit page
  previewPage(data) {
    localStorage.setItem('set_editsections', JSON.stringify(data));//storing data in session
    this.router.navigate(['add-edit-school-sections/']);
  
  }
  //
  //deleting users
  deleteData(data) {
    $('#deletebttn').trigger('click');
    var user = {
      tablename : 'chise_sections',
      fieldid: data.section_id,
      fieldname: 'section_id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
     }
     $('.pageloader').show();
      this.http.post<any>(`${this.url}/get_school_sections`,  user_id   ).subscribe(data => {
       $('.pageloader').hide();
       this.lettergradeList = data.list
       this.cumulative1=data.list.length;
       if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
     }, err => {
       $('.pageloader').hide();
     })
   }
   //
  //exporting the selected data as csv
  export_data() {
    var selected_array=['section_name'];
    var header_array=['Sections'];
    this.api.downloadFile(this.lettergradeList,selected_array,header_array, 'section_name');
  }
  
   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  
  
  }
  