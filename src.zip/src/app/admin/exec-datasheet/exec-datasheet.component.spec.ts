import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecDatasheetComponent } from './exec-datasheet.component';

describe('ExecDatasheetComponent', () => {
  let component: ExecDatasheetComponent;
  let fixture: ComponentFixture<ExecDatasheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExecDatasheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExecDatasheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
