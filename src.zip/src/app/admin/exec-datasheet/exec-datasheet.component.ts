import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { SlowBuffer } from 'buffer';
import { empty } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-exec-datasheet',
  templateUrl: './exec-datasheet.component.html',
  styleUrls: ['./exec-datasheet.component.css']
})
export class ExecDatasheetComponent implements OnInit {
  error = false;
  data: any = [];
  url = this.api.geturl();
  registerList: any = [];
  items = [];
  exe=0;
  cumulative: any ;
  cumulative2: any ;
  pageOfItems: Array<any>;
  column: any;
  columns: any;
  listnames= [];
  dropdownList = [];
  alumnilist= [];
  userlist= [];
  studentlist= [];
  selectedItems = [];
  familylist= [];
  dropdownSettings = {};
  profilename= 'nils';
  vals=[];
  dataavail=0;
  testform: FormGroup;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private fb: FormBuilder) { }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.testform = this.fb.group({
      table_name: new FormControl('', [Validators.required,]),
      attributes: new FormControl('', [Validators.required,]),
    })

    this.userlist = [
      { item_id: 'first_name', item_text: 'First Name' },
      { item_id: 'last_name', item_text: 'Last Name' },
      { item_id: 'user_class', item_text: 'User Class' },
      { item_id: 'email', item_text: 'Email' },
      { item_id: 'phone', item_text: 'Phone' },
      { item_id: 'street', item_text: 'Street' },
      { item_id: 'city', item_text: 'City' },
      { item_id: 'state', item_text: 'State' }];
  
    
 this.alumnilist=[
  { item_id: 'alumni_name', item_text: 'Alumni Name' },
  { item_id: 'guard_email', item_text: 'Guardian Email' },
  { item_id: 'current_email', item_text: 'Current Email' },
  { item_id: 'current_number', item_text: 'Current Number' },
  { item_id: 'yo_hs_graduation', item_text: 'Year of Graduation' },
  { item_id: 'hs_name', item_text: 'Highschool Name' },
  { item_id: 'first_enrollment', item_text: 'First Enrollment' },
  { item_id: 'planned_major', item_text: 'Planned Major' },
  { item_id: 'minor', item_text: 'Planned Minor' },
  { item_id: 'collage_name', item_text: 'University / College' },
  { item_id: 'expected_yo_graduation', item_text: 'Expected Year of Graduation' }
];
    this.studentlist = [
      { item_id: 'full_names', item_text: 'Full Name' },
      { item_id: 'register_email', item_text: 'Email' },
      { item_id: 'academic_term', item_text: 'Academic Term' },
      { item_id: 'academic_year', item_text: 'Academic Year' },
      { item_id: 'school_name', item_text: 'School Name' },
      { item_id: 'grade', item_text: 'Grade' },
      { item_id: 'program_name', item_text: 'Track' },
      { item_id: 'math_track', item_text: 'Math Track' },
      { item_id: 'math_grade', item_text: 'Math Grade' },
      { item_id: 'science_track', item_text: 'Science Track' },
      { item_id: 'science_grade', item_text: 'Science Grade' },
      { item_id: 'cs_track', item_text: 'CS Track' },
      { item_id: 'cs_grade', item_text: 'CS Grade' },
      { item_id: 'parent_name', item_text: 'Guardian Name' },
      { item_id: 'registered_on', item_text: 'Registered On' },
      { item_id: 'phoneno', item_text: 'Phone Number' },
      { item_id: 'emergency_contact', item_text: 'Emergency Contact'}];
   
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true
    };   

  }
  
  getDatas() {
    this.selectedItems = []; 
    var list=$('#table_name').find(':selected').data('id');
    this.profilename=$('#table_name').find(':selected').data('id');
    if((list=='user') || (list=='family'))
    {
      this.columns=this.dropdownList=this.userlist;

    }else if(list=='student')
    {
      this.columns= this.dropdownList=this.studentlist;
    }
    else if(list=='alumni')
    {
      this.columns=this.dropdownList=this.alumnilist;
    }
      //this.dropdownList=this.listnames;
      //this.columns=this.listnames
  }
  search(){
    if (!($('#table_name').val())) {
      $('#table_name').addClass('error');
      this.error = true;
    } else {
      $('#table_name').removeClass('error');
      this.error = false;
    }
      var attrib=this.testform.value.attributes;
      var IDs = [];
      attrib.forEach( (element) => {
        IDs.push(element.item_id);
    });

    var IDsw = [];
      attrib.forEach( (element) => {
        IDsw.push(element.item_text);
    });

    // if(empty(attrib))
    // {
    //   this.error = true;
    //   $('#attributes').addClass('error');
    // }

  var attri=IDs;
    var datalist = {
      type : $('#type').val(),
      search : 1,
      value : $('#value').val(),
      merged_stat:0,
      table_name:$('#table_name').val(),
      fields:attri,
      cols:IDsw,
    }
   
    if (this.error == false) {
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/get_tabledata`, datalist).subscribe(data => {
        $('#showcount').html(data.count);
        $('#export_csv').removeClass('textback');
        $('#export_csv').removeClass('disabled');
        $('.pageloader').hide();
        this.registerList = data.user
        this.column=IDsw
        this.vals=attri
        this.dataavail=1;
        this.cumulative2=data.count;
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
      }
  }

  OnSubmit() {
    if (!($('#table_name').val())) {
      $('#table_name').addClass('error');
      this.error = true;
    } else {
      $('#table_name').removeClass('error');
      this.error = false;
    }

    
      var attrib=this.testform.value.attributes;
      var IDs = [];
      attrib.forEach( (element) => {
        IDs.push(element.item_id);
    });
    // if(empty(attrib))
    // {
    //   this.error = true;
    //   $('#attributes').addClass('error');
    // }

    var IDsw = [];
      attrib.forEach( (element) => {
        IDsw.push(element.item_text);
    });

  var attri=IDs;
    var datalist = {
      type : $('#type').val(),
      search : '',
      value : $('#value').val(),
      merged_stat:0,
      table_name:$('#table_name').val(),
      fields:attri,
      cols:IDsw,
    }
   
    if (this.error == false) {
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/get_tabledata`, datalist).subscribe(data => {
        $('#showcount').html(data.count);
        $('#export_csv').removeClass('textback');
        $('#export_csv').removeClass('disabled');
        $('.pageloader').hide();
        this.registerList = data.user
        this.column=IDsw
        this.vals=attri
        this.dataavail=1;
        this.cumulative=data.user.length
        this.cumulative2=data.count;
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
      }

  }

  
  export_data(){
    var attrib=this.testform.value.attributes;
      var IDs =[];
      var IDs1 =[];
      attrib.forEach( (element) => {
        IDs.push(element.item_text);
        IDs1.push(element.item_id);
    });
    IDs.push('#');
      var selected_array = IDs1;
      var header_array = IDs;
      var list=$('#table_name').find(':selected').data('id');
    if(list=='user')
    var tablename='User Data';
    if(list=='family')
    var tablename='Family  Data';
    else if(list=='student')
    var tablename='Registration Data';
    else if(list=='alumni')
    var tablename='Alumni Data';
    else
    var tablename='Record Lists';
      this.api.downloadFile(this.registerList, selected_array, header_array, tablename);
  }
  setval(type,val2){
    console.log();
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }

}

