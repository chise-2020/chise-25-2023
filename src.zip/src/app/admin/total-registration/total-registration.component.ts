import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
@Component({
  selector: 'app-total-registration',
  templateUrl: './total-registration.component.html',
  styleUrls: ['./total-registration.component.css']
})
export class TotalRegistrationComponent implements OnInit {
  logdata: any = [];
  url = this.api.geturl();
  list: any = [];
  years: any;
  error: boolean;
  pageOfItems: any[];
  sc_list: any = [];
  cs_list: any = [];
  pageOfItems1: any[];
  pageOfItems2: any[];
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }
  

  ngOnInit(): void {
    this.getdata();
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
  }
  getdata(){
    var user_id = {
      user_id : ''
    }
     $('.pageloader').show();
       this.http.post<any>(`${this.url}/drop_lists`,user_id).subscribe(data => {
        $('.pageloader').hide();
        console.log(data.program)
        // this.programs = data.program
        // this.grades = data.grade
        // this.academic_terms=data.academic_term
        // this.academic_years=data.academic_year  
        // this.teachers=data.teacher
        this.years = data.list_year
      }, err => {
        $('.pageloader').hide();
      })
   
  }
  onSubmit(){
    if (!($('#year_1').val())) {
      $('#year_1').addClass('error');
      this.error = true;
    } else {
      $('#year_1').removeClass('error');
      this.error = false;
    }
    if (!($('#year_2').val())) {
      $('#year_2').addClass('error');
      this.error = true;
    } else {
      $('#year_2').removeClass('error');
      this.error = false;
    }

    if (this.error == false) {
      var type = {
        year_1: $('#year_1').val(),
        year_2:$('#year_2').val(),
        search : 0,
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/total_registration`, type).subscribe(data => {
        console.log(data)
        $('.pageloader').hide();
        this.list=data.list.math_list;
        this.sc_list=data.list.science_list;
        this.cs_list=data.list.cs_list;
        $('.total_count').css('display','block');
        $('#showcount_math').html(data.total_count);
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
    }
  }
  get_filter(){
    //  alert('yes')
     
     var ftrack=$('#filter_track').val();
     var fname=$('#filter_student').val();
     var fyear=$('#filter_year').val();
     var sname=$('#filter_school').val();
     var gr=$('#filter_grade').val();
     var math_course=$('#filter_mathcourse').val();
     var sc_course=$('#filter_sciencecourse').val();
     var cs_course=$('#filtercscourse').val();
     var type = {
      // type : "notempty",
      search : 1,
  track:ftrack,
  fullname:fname,
  grade:gr,
  school_name:sname,
  year:fyear,
  math_course:math_course,
  sc_course:sc_course,
  cs_course:cs_course,
    }
    // $('.pageloader').show();
    this.http.post<any>(`${this.url}/total_registration`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list=data.list.math_list;
      $('#showcount_math').html(data.total_count);
      // $('#filter_track').val(ftrack);
      // $('#filter_full_name').val(fname);
    //   $('#filter_term').val(ac_term);
    //   $('#filter_year').val(ac_year);
    //  $('#filter_school').val(sname);
    //   $('#filter_name').val(gr);
    //  $('#filter_parent').val(parent);
    // $('#filter_regon').val(reg_on);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
   }
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  onChangePage1(pageOfItems1: Array<any>) {
    // update current page of items
    this.pageOfItems1 = pageOfItems1;
  }
  onChangePage2(pageOfItems2: Array<any>) {
    // update current page of items
    this.pageOfItems2 = pageOfItems2;
  }
}
