import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSectionAssignmentComponent } from './edit-section-assignment.component';

describe('EditSectionAssignmentComponent', () => {
  let component: EditSectionAssignmentComponent;
  let fixture: ComponentFixture<EditSectionAssignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditSectionAssignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSectionAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
