import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ConditionalExpr } from '@angular/compiler';

declare var $: any;
@Component({
  selector: 'app-edit-section-assignment',
  templateUrl: './edit-section-assignment.component.html',
  styleUrls: ['./edit-section-assignment.component.css']
})
export class EditSectionAssignmentComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  programdata: any = [];
  form: FormGroup;//initializing form
  program_name = false
  update_id = false
  grade = false
  error = false
  novalue = null;
  novalue1 = null;
  option=0;
  sections : any = [];
  modules : any = [];
  moduleid : any = [];
  selected :any=[];
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'section_id',
      textField: 'sections',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 0,
      allowSearchFilter: true
    };
    
    this.getlists();
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
    this.programdata = JSON.parse(localStorage.getItem('set_section_assignment'));
    
   
      $('#c1').trigger('click');
      $('#e12').css('display', 'block');
      $('#e12').closest('a').addClass('active');
      this.form.get('update_id').setValue(this.programdata.program_id);
      this.form.get('program_name').setValue(this.programdata.program_name);
      $('#sectionassg').val(this.programdata.section_names);
      this.form.get('track_name').setValue(this.programdata.program_name +' - '+this.programdata.grade);
      var str = this.programdata.sections;
      if(str!='')
      {
        this.selectedItems =str.split(",");
        this.modules=this.programdata.section_names+',';
      }
    
  }


  onItemSelect(item: any) {
    var gettext=item.sections;
    this.modules+=gettext+',';
    $("#sectionassg").val(this.modules.substring(0,this.modules.length-1));
}

onItemDeSelect(item: any) {
  var gettext=item.sections+',';
  this.modules = this.modules.replace(gettext,'');
  $("#sectionassg").val(this.modules);
}

onSelectAll(items: any) {
  var getlength=items.length;
  if(getlength!=0)
  {
    for (let i = 0; i < getlength; i++) {
      this.modules+= items[i].sections+',';
    }
    $("#sectionassg").val(this.modules.substring(0,this.modules.length-1));

  }
}

onUnSelectAll() {
  this.modules=[];
  $("#sectionassg").val('');
}

  getlists(){
    var user_id = {
      user_id : '',
    }
   $('.pageloader').show();
     this.http.post<any>(`${this.url}/drop_lists`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.sections = data.sections
      this.dropdownList= data.sections

    }, err => {
      $('.pageloader').hide();
    })
 
}

  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      program_name: new FormControl('', [Validators.required,]),
      sections: new FormControl('', [Validators.required,]),
      track_name: new FormControl('', [Validators.required,]),
    });
  }
  //
  //submitting function
  submit() {
    var path=localStorage.setItem('set_editpath', JSON.stringify('section_assignment'));
    
    this.error=this.program_name=false;

    if((this.selectedItems.length)==0)
    {
      alert();
      $('#teach').addClass('error');
      this.error = true;
    }
      if (this.error == false) {
        var value = this.form.getRawValue();
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_section_assignment`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status=='nil') {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/info.svg">Section Assignment');
            $('#errortext').html(data.message);
            localStorage.setItem('section_assignment', JSON.stringify(''));
          }
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg">Section Assignment');
            $('#errortext').html(data.message);
            localStorage.setItem('setprogram_module', JSON.stringify(''));
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">Section Assignment');
            $('#errortext').html(data.message);
            localStorage.setItem('section_assignment', JSON.stringify(''));
          }
        
        }, err => {
          $('.pageloader').hide();
        })
      }
  }
  //
changes(){
$("#track_name").val($('#program_name').val()+' - '+$('#grade').val());
}
}
