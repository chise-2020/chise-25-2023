import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmploymentHistoryListComponent } from './employment-history-list.component';

describe('EmploymentHistoryListComponent', () => {
  let component: EmploymentHistoryListComponent;
  let fixture: ComponentFixture<EmploymentHistoryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmploymentHistoryListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmploymentHistoryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
