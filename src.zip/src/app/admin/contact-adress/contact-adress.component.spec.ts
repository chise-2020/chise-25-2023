import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactAdressComponent } from './contact-adress.component';

describe('ContactAdressComponent', () => {
  let component: ContactAdressComponent;
  let fixture: ComponentFixture<ContactAdressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactAdressComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactAdressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
