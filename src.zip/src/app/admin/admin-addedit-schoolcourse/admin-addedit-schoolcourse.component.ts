import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-admin-addedit-schoolcourse',
  templateUrl: './admin-addedit-schoolcourse.component.html',
  styleUrls: ['./admin-addedit-schoolcourse.component.css']
})
export class AdminAddeditSchoolcourseComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  schooldata: any = [];
  form: FormGroup;//initializing form
  track_name = false
  track_type = false
  update_id = false
  error = false
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
    this.schooldata = JSON.parse(localStorage.getItem('set_schoolcourse'));
    // alert(this.schooldata.length)
    if (this.schooldata == null) {
      // $('#c5').trigger('click');
      // $('#addt_4').addClass('active');
      $('#headdyn').html("Add School Course ");
    } else {
      if (this.schooldata.length!=0) {
      // $('#c1').trigger('click');
      // $('#s1').trigger('click');
      $('#e10').css('display', 'block');
      $('#schoolcourse').addClass('active');
      $('#headdyn').html("Edit School Course ");
      this.form.get('update_id').setValue(this.schooldata.track_id);
      this.form.get('track_name').setValue(this.schooldata.track_name);
      this.form.get('track_type').setValue(this.schooldata.track_type);
      }else{
        $('#headdyn').html("Add School Course ");
      }
    }
  }
  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      track_name: new FormControl('', [Validators.required,]),
      track_type: new FormControl('', [Validators.required,]),
    });
  }
  //
  //submitting function
  submit() {
    var path=localStorage.setItem('set_editpath', JSON.stringify('school_course'));
    this.track_name = this.track_type = this.error = false;
    if (this.form.getRawValue().track_name == '')
    {
      this.track_name = true;
      this.error = true;
    }
    if (this.form.getRawValue().track_type == '')
    {
      this.track_type = true
      this.error = true;
    }
      if (this.error == false ) {
        var value = this.form.getRawValue()
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_schoolcourse`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg">School Course');
            $('#errortext').html(data.message);
            localStorage.setItem('set_schoolcourse', JSON.stringify(''));
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">School Course');
            $('#errortext').html(data.message);
            localStorage.setItem('set_schoolcourse', JSON.stringify(''));
          }
        }, err => {
          $('.pageloader').hide();
        })
      }
  }
}
