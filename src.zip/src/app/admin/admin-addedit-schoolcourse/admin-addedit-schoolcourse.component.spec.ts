import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddeditSchoolcourseComponent } from './admin-addedit-schoolcourse.component';

describe('AdminAddeditSchoolcourseComponent', () => {
  let component: AdminAddeditSchoolcourseComponent;
  let fixture: ComponentFixture<AdminAddeditSchoolcourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAddeditSchoolcourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddeditSchoolcourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
