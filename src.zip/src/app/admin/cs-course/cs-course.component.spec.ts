import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CsCourseComponent } from './cs-course.component';

describe('CsCourseComponent', () => {
  let component: CsCourseComponent;
  let fixture: ComponentFixture<CsCourseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CsCourseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CsCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
