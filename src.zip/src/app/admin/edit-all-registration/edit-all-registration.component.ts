import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-edit-all-registration',
  templateUrl: './edit-all-registration.component.html',
  styleUrls: ['./edit-all-registration.component.css']
})
export class EditAllRegistrationComponent implements OnInit {
  UserData: any = [];
  form: FormGroup;
  url = this.api.geturl();
  schools: any = [];
  years: any = [];
  students: any = [];
  parent: any = [];
  maths: any = [];
  science: any = [];
  css: any = [];
  grades: any = [];
  programs: any = [];
  studentdata: any = [];
  name = false
  grade = false
  school = false
  program = false
  mathTrack = false
  scienceTrack = false
  cs_track = false
  emergency_contact = false
  user_id = false
  group_id = false
  date = false
  error = false
  emergencycontact: any = [];
  h_schools: any = [];
  classarray: any = [];

  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {
    this.createForm();
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    // $('.sdebar').css('display', 'none');
    $('#dropdownMenu16').addClass('active');// menu highlight
    this.UserData = JSON.parse(localStorage.getItem('loginData')); //forgot to close
    this.form.get('user_id').setValue(this.UserData.user_id);

    this.studentdata = JSON.parse(localStorage.getItem('set_all_registerrecord'));
    // if(this.studentdata != null)
    //     {var stdata = localStorage.getItem('set_all_registerrecord').replace('"', '');
    //     var stdatas = stdata.replace('"', '');
    //     console.log(stdatas);}else{
    //       stdatas=""
    //     }
    console.log('reg');
    var dt = new Date();
    var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    this.form.get('registered_on').setValue(time);
    this.getStudent()
    this.classarray = ['Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
    if (this.studentdata == null) {
      // alert('add')
      $('#name').css('display', 'block');
      $('#edit_name').css('display', 'none');
      $('#mcourse').css('pointer-events', 'none');
      $('#mcourse').addClass('textback');
      $('#scourse').css('pointer-events', 'none');
      $('#scourse').addClass('textback');
      $('#ccourse').css('pointer-events', 'none');
      $('#ccourse').addClass('textback');

    } else {
      // $('#c4').trigger('click');
      // $('#add_2').addClass('active');
      // alert('edit')
      // $('#c1').trigger('click');
      // $('#s2').trigger('click');
      // $('#allreg').addClass('active');
      // $('#allreg').closest('a').addClass('active'); 
      // $('#e5').css('display', 'block');

      if (this.studentdata.length != 0) {
        $('#add_section').css('display', 'none');
        $('#name').css('display', 'none');
        $('#edit_name').css('display', 'block');

        this.emergencycontact = this.studentdata.contact_list

        this.form.get('update_id').setValue(this.studentdata.student_id);
        this.form.get('name').setValue(this.studentdata.full_names);
        this.form.get('grade').setValue(this.studentdata.grade);
        this.form.get('school').setValue(this.studentdata.school_name);

        this.form.get('program').setValue(this.studentdata.program_name);
        this.form.get('mathTrack').setValue(this.studentdata.math_track);
        this.form.get('scienceTrack').setValue(this.studentdata.science_track);
        this.form.get('cs_track').setValue(this.studentdata.cs_track);
        this.form.get('aterm').setValue(this.studentdata.academic_term);
        this.form.get('ayear').setValue(this.studentdata.academic_year);
        this.form.get('emergency_contact').setValue(this.studentdata.emergency_contact);

        if (jQuery.inArray(this.studentdata.grade, this.classarray) !== -1) {
          //remove grayout
          $('#mcourse').css('pointer-events', '');
          $('#mcourse').removeClass('textback');
          $('#scourse').css('pointer-events', '');
          $('#scourse').removeClass('textback');
          $('#ccourse').css('pointer-events', '');
          $('#ccourse').removeClass('textback');
        } else {
          //grayout
          $('#mcourse').css('pointer-events', 'none');
          $('#mcourse').addClass('textback');
          $('#scourse').css('pointer-events', 'none');
          $('#scourse').addClass('textback');
          $('#ccourse').css('pointer-events', 'none');
          $('#ccourse').addClass('textback');
        }

      } else {
        $('#add_section').css('display', 'block');
        $('#mcourse').css('pointer-events', 'none');
        $('#mcourse').addClass('textback');
        $('#scourse').css('pointer-events', 'none');
        $('#scourse').addClass('textback');
        $('#ccourse').css('pointer-events', 'none');
        $('#ccourse').addClass('textback');
      }

    }






  }
  checkval() {
    var grade = this.form.getRawValue().grade;
    // If the element was not found, -1 will be returned
    if (jQuery.inArray(grade, this.classarray) !== -1) {
      $('#mcourse').css('pointer-events', '');
      $('#mcourse').removeClass('textback');
      $('#scourse').css('pointer-events', '');
      $('#scourse').removeClass('textback');
      $('#ccourse').css('pointer-events', '');
      $('#ccourse').removeClass('textback');
      this.mathTrack = this.scienceTrack = this.cs_track = false;
      this.form.get('mathTrack').setValue(this.studentdata.math_track);
      this.form.get('scienceTrack').setValue(this.studentdata.science_track);
      this.form.get('cs_track').setValue(this.studentdata.cs_track);
    } else {

      $('#mcourse').css('pointer-events', 'none');
      $('#mcourse').addClass('textback');
      $('#scourse').css('pointer-events', 'none');
      $('#scourse').addClass('textback');
      $('#ccourse').css('pointer-events', 'none');
      $('#ccourse').addClass('textback');
      this.form.get('mathTrack').setValue('');
      this.form.get('scienceTrack').setValue('');
      this.form.get('cs_track').setValue('');
      $('#mcourse').removeClass('error');
      $('#scourse').removeClass('error');
      $('#ccourse').removeClass('error');
    }
  }
  getstudent() {
    this.form.reset();
    var pid = $('#parent').val();
    var value = {
      parentid: pid,
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/getstudents_parent`, value).subscribe(data => {
      $('.pageloader').hide();
      this.students = data.students
      this.form.get('r_family_code').setValue(data.family_code);
      this.schools = data.school
      this.h_schools = data.home_school
      this.grades = data.grade
      this.programs = data.program
      this.maths = data.math
      this.science = data.science
      this.css = data.cs
      this.emergencycontact = data.emergncy_contact
      var dt = new Date();
      var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
      this.form.get('user_id').setValue(data.user_id);
      this.form.get('aterm').setValue(data.academic_term);
      this.form.get('ayear').setValue(data.academic_year);
      this.form.get('email').setValue(data.email);
      this.form.get('r_family_code').setValue(data.family_code);
      this.form.get('registered_on').setValue(time);

      $('#actdetails').html(data.academic_text);
    }, err => {
      $('.pageloader').hide();
    })
  }

  submit() {
    var path = localStorage.setItem('set_editpath', JSON.stringify('register_student'));
    this.error = this.name = this.grade = this.school = this.program = this.mathTrack = this.scienceTrack = this.cs_track = false;
    if (!($('#parent').val())) {
      $('#parent').addClass('error');
      this.error = true;
    } else {
      this.error = false;
    }
    if (!($('#edit_name').val())) {
      if (!($('#name').val())) {
        $('#name').addClass('error');
        this.error = true;
        this.name = true;
      }
    } else {
      this.error = false;
      this.name = false;
    }
    if (!($('#track').val())) {
      $('#track').addClass('error');
      this.error = true;
      this.program = true;
    }
    if (!($('#dino-select').val())) {
      $('#dino-select').addClass('error');
      this.error = true;
      this.school = true;
    }
    if (!($('#grade').val())) {
      $('#grade').addClass('error');
      this.error = true;
      this.grade = true;
    }
    // alert($('#emergency_contact').val());
    if (!($('#emergency_contact').val())) {
      $('#emergency_contact').addClass('error');
      this.error = true;
      this.emergency_contact = true;
    }

    var grade = this.form.getRawValue().grade;
    if (jQuery.inArray(grade, this.classarray) !== -1) {
      if (this.form.getRawValue().mathTrack == '')
        this.mathTrack = true
      if (this.form.getRawValue().scienceTrack == '')
        this.scienceTrack = true
      if (this.form.getRawValue().cs_track == '')
        this.cs_track = true
      // this.error = true;
    } else {
      $('#mcourse').css('pointer-events', 'none');
      $('#mcourse').addClass('textback');
      $('#scourse').css('pointer-events', 'none');
      $('#scourse').addClass('textback');
      $('#ccourse').css('pointer-events', 'none');
      $('#ccourse').addClass('textback');
      this.form.get('mathTrack').setValue('');
      this.form.get('scienceTrack').setValue('');
      this.form.get('cs_track').setValue('');
      $('#mcourse').removeClass('error');
      $('#scourse').removeClass('error');
      $('#ccourse').removeClass('error');
      // this.mathTrack=this.scienceTrack=this.cs_track=false;
      // this.error = false;
    }
    if (($('#grade').val())) {
      if (jQuery.inArray(($('#grade').val()), this.classarray) !== -1) {
        if (!($('#mcourse').val())) {
          $('#mcourse').addClass('error');
          this.error = true;
          this.mathTrack = true;
        }
        if (!($('#scourse').val())) {
          $('#scourse').addClass('error');
          this.error = true;
          this.scienceTrack = true;
        }
        if (!($('#ccourse').val())) {
          $('#ccourse').addClass('error');
          this.error = true;
          this.cs_track = true;
        }
      }
    }
    // alert(this.error)
    if (this.error == false) {
      var value = this.form.getRawValue();

      $('.pageloader').show();
      this.http.post<any>(`${this.url}/manage_allregister`, value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg"> Register');
          $('#errortext').html(data.message);
          localStorage.setItem('set_all_registerrecord', JSON.stringify(''));
        }
        else if (data.status == true) {
          $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg"> Register ');
          $('#errortext').html(data.message);
          this.form.reset();
          localStorage.setItem('set_all_registerrecord', JSON.stringify(''));
        }
      }, err => {
        $('.pageloader').hide();
      })
    }
  }



  createForm() {
    this.form = this.fb.group({
      name: new FormControl('', [Validators.required,]),
      grade: new FormControl('', [Validators.required,]),
      school: new FormControl('', [Validators.required,]),
      program: new FormControl('', [Validators.required,]),
      mathTrack: new FormControl('', [Validators.required,]),
      scienceTrack: new FormControl('', [Validators.required,]),
      cs_track: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
      date: new FormControl('', [Validators.required,]),
      aterm: new FormControl('', [Validators.required,]),
      ayear: new FormControl('', [Validators.required,]),
      email: new FormControl('', [Validators.required,]),
      r_family_code: new FormControl('', [Validators.required,]),
      registered_on: new FormControl('', [Validators.required,]),
      update_id: new FormControl('', [Validators.required,]),
      emergency_contact: new FormControl('', [Validators.required,]),
    });
  }

  getvals() {
    this.form.value
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_reg_details`, this.form.value).subscribe(data => {
      $('.pageloader').hide();
      $('#reviewbtn').trigger('click');
      $('#yesbutton').css('display', 'none');
      $('#nobutton').css('display', 'none');
      $('#okbutton').css('display', 'none');
      $('#okbtn').css('display', 'block');
      $('#dynamictitle').html('<img src="assets/images/alert.svg"> REGISTER STUDENT');
      $('#review').html(data.html);
    }, err => {
      $('.pageloader').hide();
    })
  }

  getStudent() {
    this.studentdata = JSON.parse(localStorage.getItem('set_all_registerrecord'));
    if (this.studentdata == null) {

      var userid = {
        user_id: ''
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/drop_lists`, userid).subscribe(data => {
        $('.pageloader').hide();
        this.schools = data.school
        this.h_schools = data.home_school
        // this.students = data.students
        this.grades = data.grade

        this.programs = data.program
        this.maths = data.math
        this.science = data.science
        this.css = data.cs
        this.parent = data.parent
        // this.emergencycontact = data.emergncy_contact

        var dt = new Date();
        var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();

        this.form.get('aterm').setValue(data.academic_term);
        this.form.get('ayear').setValue(data.academic_year);
        this.form.get('registered_on').setValue(time);

        $('#actdetails').html(data.academic_text);

      }, err => {
        $('.pageloader').hide();
      })

    } else {
      var user_id = {
        user_id: this.studentdata.student_id,
        family_code: this.studentdata.family_code
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/drop_lists`, user_id).subscribe(data => {
        $('.pageloader').hide();
        this.schools = data.school
        this.h_schools = data.home_school
        // this.students = data.students
        this.grades = data.grade

        this.programs = data.program
        this.maths = data.math
        this.science = data.science
        this.css = data.cs
        this.parent = data.parent
        // this.emergencycontact = data.emergncy_contact

        var dt = new Date();
        var time = dt.getFullYear() + "-" + (dt.getMonth() + 1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        this.form.get('user_id').setValue(this.studentdata.student_id);
        this.form.get('aterm').setValue(data.academic_term);
        this.form.get('ayear').setValue(data.academic_year);
        this.form.get('email').setValue(this.studentdata.email);
        this.form.get('r_family_code').setValue(this.studentdata.family_code);
        this.form.get('registered_on').setValue(time);

        $('#actdetails').html(data.academic_text);

      }, err => {
        $('.pageloader').hide();
      })

    }
    console.log(this.studentdata)
    console.log('data')

  }
  set_year() {
    var academic_term = $('#academic_term').val();
    var academic_year = $('#academic_year').val();
    this.form.get('aterm').setValue(academic_term);
    this.form.get('ayear').setValue(academic_year);
    $('#sc_year').html(academic_year);
  }
  get_year() {
    var academic_term = $('#academic_term').val();
    // alert(academic_term)

    var user_id = {
      // user_id : this.UserData.user_id,
      // group_id : this.UserData.family_code,
      term: academic_term
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, user_id).subscribe(data => {
      $('.pageloader').hide();
      this.years = data.year
      // alert(data.academic_year)
      $('#sc_term').html(academic_term);
      $('#sc_year').html(data.academic_year);
      $('#termyear').css('display', '');
      $('#actdetails').css('display', 'none');
      this.form.get('aterm').setValue(academic_term);
      this.form.get('ayear').setValue(data.academic_year);
    }, err => {
      $('.pageloader').hide();
    })
  }

}
