import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAllRegistrationComponent } from './edit-all-registration.component';

describe('EditAllRegistrationComponent', () => {
  let component: EditAllRegistrationComponent;
  let fixture: ComponentFixture<EditAllRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAllRegistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAllRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
