import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListLetterGradesComponent } from './list-letter-grades.component';

describe('ListLetterGradesComponent', () => {
  let component: ListLetterGradesComponent;
  let fixture: ComponentFixture<ListLetterGradesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListLetterGradesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListLetterGradesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
