import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

declare var $: any;
@Component({
  selector: 'app-admin-addedit-programmodule',
  templateUrl: './admin-addedit-programmodule.component.html',
  styleUrls: ['./admin-addedit-programmodule.component.css']
})
export class AdminAddeditProgrammoduleComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  programdata: any = [];
  form: FormGroup;//initializing form
  program_name = false
  update_id = false
  grade = false
  error = false
  novalue = null;
  novalue1 = null;
  grades : any = [];
  modules : any = [];
  selected :any=[];
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.dropdownSettings= 
    {
      singleSelection: false,
      idField: 'module',
      textField: 'module',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    
    this.getlists();
    $('.sdebar').css('display','none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
    this.programdata = JSON.parse(localStorage.getItem('setprogram_module'));
    
    if (this.programdata.length==0) {
      $('#c5').trigger('click');
      $('#addt_6').addClass('active');
      $('#headdyn').html("ADD A NEW CHIS&E TRACK");
      $('#iinfo').html('Enter a module name and select a grade,in order to define a Track.');
    } else {
      $('#c1').trigger('click');
      $('#e12').css('display', 'block');
      $('#e12').closest('a').addClass('active');
      $('#headdyn').html("Edit ChiS&E Tracks ");
      $('#iinfo').html('Edit the module name and/or the grade.');
      console.log(this.programdata)
      this.form.get('update_id').setValue(this.programdata.program_id);
      this.form.get('program_name').setValue(this.programdata.program_name);
      this.form.get('track_name').setValue(this.programdata.program_name +' - '+this.programdata.grade);
      var str = this.programdata.grade;
      this.selected =str.split(",");
    }
  }


  getlists(){
    var user_id = {
      user_id : '',
    }
   $('.pageloader').show();
     this.http.post<any>(`${this.url}/drop_lists`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.grades = data.allgrade
      this.modules =  data.modules
      this.dropdownList = data.modules 
    }, err => {
      $('.pageloader').hide();
    })
 
}

  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      program_name: new FormControl('', [Validators.required,]),
      grade: new FormControl('', [Validators.required,]),
      track_name: new FormControl(),
    });
  }
  //
  //submitting function
  submit() {
    var path=localStorage.setItem('set_editpath', JSON.stringify('program_module'));
    
    this.error=this.program_name = this.grade = false;
    if (this.form.getRawValue().program_name == '')
    {
      this.program_name = true
      this.error=true
    }
    if (this.form.getRawValue().grade == '')
    {
      this.grade = true
      this.error=true
    }
      if (this.error == false) {
        var value = this.form.getRawValue()
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/manage_program`, value).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/block.svg">ChiS&E Track');
            $('#errortext').html(data.message);
            localStorage.setItem('setprogram_module', JSON.stringify(''));
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg">ChiS&E Track');
            $('#errortext').html(data.message);
            localStorage.setItem('setprogram_module', JSON.stringify(''));
          }
        }, err => {
          $('.pageloader').hide();
        })
      }
  }
  //
changes(){
// alert($('#program_name').val())
  // var a=$('.grade option:selected').last();
  // // alert("SelectedItem Index: " + a.index());
  // var str='';
  // var i;
  // for(i=0;i<a.length;i++){
  //     str+=$('.grade option:selected:eq('+i+')').index()+",";
  // }

  // alert("all selected :"+str);

$("#track_name").val($('#program_name').val()+' - '+$('#grade').val());
}
}
