import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminProgramConfigComponent } from './admin-program-config.component';

describe('AdminProgramConfigComponent', () => {
  let component: AdminProgramConfigComponent;
  let fixture: ComponentFixture<AdminProgramConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminProgramConfigComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminProgramConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
