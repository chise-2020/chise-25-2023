import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-admin-program-config',
  templateUrl: './admin-program-config.component.html',
  styleUrls: ['./admin-program-config.component.css'],
})
export class AdminProgramConfigComponent implements OnInit {
  url = this.api.geturl();

  isChecked: false;
  programList: any = [];
  cumulative1=0;
  cumulative=0;
  acad_yr='';
  acad_term='';
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {


  }
  ngOnInit(): void {
    this.acad_yr = JSON.parse(localStorage.getItem('acad_yr'));
    this.acad_term = JSON.parse(localStorage.getItem('acad_term'));
    localStorage.setItem('set_trackconfig', JSON.stringify(''))
    $('#dropdownMenu13').addClass('active');
    this.getdetails();
  }
  

  getdetails() {
    var userid = {
      user_id: '',
      acad_yr:this.acad_yr,
      acad_term:this.acad_term,

    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/gettracks_config`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.programList = data.list
      this.cumulative= data.list.length
      this.cumulative1= data.list.length
    }, err => {
      $('.pageloader').hide();
    })
  }



  deleteData(data) {

    $('#deletebttn').trigger('click');
    var user = {
      tablename: 'track_config',
      fieldid: data.track_id,
      fieldname: 'track_id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));

  }
  go_config(data)
  {
    localStorage.setItem('set_session_config', JSON.stringify(data));//storing data in session
    this.router.navigate(['add-sessions/']);
  }

   //setting value of filter
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
 //

 previewPage(data) {
  console.log(data)
  localStorage.setItem('set_trackconfig', JSON.stringify(data));//storing data in session
  this.router.navigate(['configure_track/']);

}

  search()
  {
     var user_id = {
     type : $('#type').val(),
     search : 1,
     value : $('#value').val(),
     acad_yr:this.acad_yr,
      acad_term:this.acad_term,
   }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/gettracks_config`, user_id).subscribe(data => {
      $('.pageloader').hide();
      this.programList = data.list
      this.cumulative1= data.list.length
    }, err => {
      $('.pageloader').hide();
    })
  }
}
