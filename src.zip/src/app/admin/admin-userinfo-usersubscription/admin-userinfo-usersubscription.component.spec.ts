import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUserinfoUsersubscriptionComponent } from './admin-userinfo-usersubscription.component';

describe('AdminUserinfoUsersubscriptionComponent', () => {
  let component: AdminUserinfoUsersubscriptionComponent;
  let fixture: ComponentFixture<AdminUserinfoUsersubscriptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminUserinfoUsersubscriptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserinfoUsersubscriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
