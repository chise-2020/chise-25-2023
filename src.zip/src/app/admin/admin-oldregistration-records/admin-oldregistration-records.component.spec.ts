import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminOldregistrationRecordsComponent } from './admin-oldregistration-records.component';

describe('AdminOldregistrationRecordsComponent', () => {
  let component: AdminOldregistrationRecordsComponent;
  let fixture: ComponentFixture<AdminOldregistrationRecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminOldregistrationRecordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOldregistrationRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
