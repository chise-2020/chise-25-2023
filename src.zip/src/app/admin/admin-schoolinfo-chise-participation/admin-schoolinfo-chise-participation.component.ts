import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-schoolinfo-chise-participation',
  templateUrl: './admin-schoolinfo-chise-participation.component.html',
  styleUrls: ['./admin-schoolinfo-chise-participation.component.css']
})
export class AdminSchoolinfoChiseParticipationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
