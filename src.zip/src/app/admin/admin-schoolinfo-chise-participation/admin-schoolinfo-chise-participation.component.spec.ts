import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoChiseParticipationComponent } from './admin-schoolinfo-chise-participation.component';

describe('AdminSchoolinfoChiseParticipationComponent', () => {
  let component: AdminSchoolinfoChiseParticipationComponent;
  let fixture: ComponentFixture<AdminSchoolinfoChiseParticipationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoChiseParticipationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoChiseParticipationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
