import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-contact',
  templateUrl: './admin-contact.component.html',
  styleUrls: ['./admin-contact.component.css']
})
export class AdminContactComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    this.getDatas()
  }


  getDatas() {
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/contact_details`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.user
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

//deleting schools
deleteData(data) {
  var user = {
    tablename : 'students_old',
    fieldid: data.student_id,
    fieldname: 'student_id'
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/delete_record`, user).subscribe(data => {
    console.log(data)
    if (data.status == true) {
      $('.pageloader').hide();
      this.getDatas()
    } else if (data.status == false) {
      $('.pageloader').hide();
    }
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
//
 //setting value of filter
 setval(type)
 {
  
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
   var user_id = {
     type : $('#type').val(),
     search : 1,
     value : $('#value').val(),
   }
   $('.pageloader').show();
   this.http.post<any>(`${this.url}/contact_details`, user_id).subscribe(data => {
     console.log(data)
     $('.pageloader').hide();
     this.list = data.user
   }, err => {
     $('.pageloader').hide();
     console.log(err);
   })
 }


 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}
