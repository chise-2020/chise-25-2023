import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { empty } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-admin-alumini-records',
  templateUrl: './admin-alumini-records.component.html',
  styleUrls: ['./admin-alumini-records.component.css']
})
export class AdminAluminiRecordsComponent implements OnInit {

  data: any = [];
  url = this.api.geturl();
  alumnidata: any = [];
  form: FormGroup;//initializing form
  alumni_name = false
  current_email = false
  current_number = false
  yo_hs_graduation = false
  expected_yo_graduation = false
  hs_name = false
  // collage_major_minor = false
  collage_name = false
  collage_prgrm = false
  company_name = false
  first_enrollment = false
  collage_minor=false
  planned_major = false
  university=false
  salary = false
  start_work = false
  yo_graduation = false
  update_id = false
  error = false
  username=false
  user_class=false
  years: any;
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }

  ngOnInit(): void {
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('.sdebar').css('display', 'none');
    this.data = JSON.parse(localStorage.getItem('loginData'));
    this.alumnidata = JSON.parse(localStorage.getItem('set_alumnilist'));
    // console.log(this.alumnidata)
this.getdata();
    if ((this.alumnidata == null) || (this.alumnidata == "")) {
      $('#c6').trigger('click');
      $('#addt_8').addClass('active');

      $('#headdyn').html("ADD ALUMINUS RECORD");
      $('.sdebar').css('display', 'none');
    } else {
      $('#c1').trigger('click');
      $('#s3').trigger('click');
      $('#e7').css('display', 'block');
      $('#alumni').addClass('active');
$('#yo_hs_graduation').addClass('textback');
$('#hs_name').addClass('textback');
// $('#expected_yo_graduation').addClass('textback');
      $('#headdyn').html("EDIT ALUMINUS RECORD");
      this.form.get('update_id').setValue(this.alumnidata.alumni_id);
      this.form.get('alumni_name').setValue(this.alumnidata.alumni_name);
      this.form.get('current_email').setValue(this.alumnidata.current_email);
      this.form.get('current_number').setValue(this.alumnidata.current_number);
      this.form.get('hs_name').setValue(this.alumnidata.hs_name);
      this.form.get('first_enrollment').setValue(this.alumnidata.first_enrollment);
      this.form.get('collage_prgrm').setValue(this.alumnidata.collage_prgrm);
      this.form.get('planned_major').setValue(this.alumnidata.planned_major);
      this.form.get('collage_name').setValue(this.alumnidata.collage_name);
      
      // this.form.get('university').setValue(this.alumnidata.university);
      this.form.get('collage_minor').setValue(this.alumnidata.collage_minor);

      this.form.get('start_work').setValue(this.alumnidata.start_work);
      this.form.get('company_name').setValue(this.alumnidata.company_name);
      this.form.get('salary').setValue(this.alumnidata.salary);
      this.form.get('yo_hs_graduation').setValue(this.alumnidata.yo_hs_graduation);
      this.form.get('yo_graduation').setValue(this.alumnidata.yo_graduation);
      this.form.get('expected_yo_graduation').setValue(this.alumnidata.expected_yo_graduation);

      this.form.get('username').setValue(this.alumnidata.username);
      this.form.get('user_class').setValue(this.alumnidata.user_class);
    }
  }
  //creating form
  createForm() {
    this.form = this.fb.group({
      update_id: new FormControl(),
      alumni_name: new FormControl('', [Validators.required,]),
      current_email: new FormControl('', [Validators.required,]),
      current_number: new FormControl('', [Validators.required,]),
      hs_name: new FormControl('', [Validators.required,]),
      first_enrollment: new FormControl('', [Validators.required,]),
      collage_prgrm: new FormControl('', [Validators.required,]),
      planned_major: new FormControl('', [Validators.required,]),
      collage_name: new FormControl('', [Validators.required,]),
      // collage_major_minor: new FormControl('', [Validators.required,]),
      start_work: new FormControl('', [Validators.required,]),
      yo_hs_graduation: new FormControl('', [Validators.required,]),
      company_name: new FormControl('', [Validators.required,]),
      salary: new FormControl('', [Validators.required,]),
      expected_yo_graduation: new FormControl('', [Validators.required,]),
      yo_graduation: new FormControl('', [Validators.required,]),
      // university: new FormControl('', [Validators.required,]),
      collage_minor: new FormControl('', [Validators.required,]),
      username: new FormControl('', [Validators.required,]),
      user_class: new FormControl('', [Validators.required,]),
    });
  }
  //
  getdata(){
    var user_id = {
      user_id : ''
    }
     $('.pageloader').show();
       this.http.post<any>(`${this.url}/drop_lists`,user_id).subscribe(data => {
        $('.pageloader').hide();
        // console.log(data.list_year)
        this.years = data.list_year
      }, err => {
        $('.pageloader').hide();
      })
   
  }
  //submitting function
  submit() {
    var path = localStorage.setItem('set_editpath', JSON.stringify('alumni'));
    console.log(path)
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
   

    // this.alumni_name = this.current_email = this.current_number = this.hs_name = this.first_enrollment = this.collage_prgrm = this.planned_major = this.collage_name = this.collage_major_minor = this.start_work = this.yo_hs_graduation = this.company_name = this.salary = this.expected_yo_graduation = this.yo_graduation = false;
    if (this.form.getRawValue().alumni_name == '') {
      this.alumni_name = true
      this.error = true
    }else{
      $('#alumni_name').removeClass('error');
      this.alumni_name = false
      this.error = false
    }
    if (this.form.getRawValue().current_number == '') {
      this.current_number = true
      this.error = true
    }

    if (this.form.getRawValue().current_email == ''){
      this.current_email = true
      this.error = true
    }else{
      // if (($('#current_email').val())) {
        if (!regex.test($('#current_email').val())) {
          this.current_email = true
          $('#current_email').addClass('error');
          this.error = true;
        } else {
          this.current_email = false;
          $('#current_email').removeClass('error');
          this.error = false;
        }
      // }
    }

    if (this.form.getRawValue().hs_name == '') {
      this.hs_name = true
      this.error = true
    }

    if (this.form.getRawValue().first_enrollment == '') {
      this.first_enrollment = true
      this.error = true
    }

    // if (this.form.getRawValue().collage_prgrm == '') {
    //   this.collage_prgrm = true
    //   this.error = true
    // }

    
    if (!($('#planned_major').val())) {
      this.planned_major = true
      $('#planned_major').addClass('error');
      this.error = true
    }else{
      $('#planned_major').removeClass('error');
       this.planned_major = false
      this.error = false
    }
    
    if (!($('#collage_name').val())) {
      this.collage_name = true
      $('#collage_name').addClass('error');
      this.error = true
    }else{
      $('#collage_name').removeClass('error');
       this.collage_name = false
      this.error = false
    }

    // if (this.form.getRawValue().collage_minor == '') {
    //   this.collage_minor = true
    //   this.error = true
    // }
    // if (this.form.getRawValue().university == '') {
    //   this.university = true
    //   this.error = true
    // }
   
    if (!($('#start_work').val())) {
      this.start_work = true
      $('#start_work').addClass('error');
      this.error = true
    }else{
      $('#start_work').removeClass('error');
       this.start_work = false
      this.error = false
    }
    if (!($('#yo_hs_graduation').val())) {
      this.yo_hs_graduation = true
      $('#yo_hs_graduation').addClass('error');
      this.error = true
    }else{
      $('#yo_hs_graduation').removeClass('error');
       this.yo_hs_graduation = false
      this.error = false
    }
    if (!($('#company_name').val())) {
      this.company_name = true
      $('#company_name').addClass('error');
      this.error = true
    }else{
      $('#company_name').removeClass('error');
       this.company_name = false
      this.error = false
    }
    if (!($('#expected_yo_graduation').val())) {
      this.expected_yo_graduation = true
      $('#expected_yo_graduation').addClass('error');
      this.error = true
    }else{
      $('#expected_yo_graduation').removeClass('error');
       this.expected_yo_graduation = false
      this.error = false
    }
    if (!($('#yo_graduation').val())) {
      this.yo_graduation = true
      $('#yo_graduation').addClass('error');
      this.error = true
    }else{
      $('#yo_graduation').removeClass('error');
       this.yo_graduation = false
      this.error = false
    }
    if (!($('#salary').val())) {
      this.salary = true
      $('#salary').addClass('error');
      this.error = true
    }else{
      $('#salary').removeClass('error');
       this.salary = false
      this.error = false
    }
   

  


    if (this.form.getRawValue().update_id == '') {
      this.update_id = true
    }
// alert(this.error)
    // if (this.update_id == true) {
    // console.log('add_api')
    // && this.university == false
    if (this.planned_major == false  && this.alumni_name == false && this.current_email == false && this.current_number == false && this.hs_name == false && this.first_enrollment == false && this.collage_prgrm == false && this.planned_major == false && this.collage_name == false && this.collage_minor == false && this.start_work == false && this.yo_hs_graduation == false && this.company_name == false && this.salary == false && this.expected_yo_graduation == false && this.yo_graduation == false) {
      var value = this.form.getRawValue()
      console.log(value)
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/manage_alumni`, value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/block.svg">Alumnus records');
          $('#errortext').html(data.message);
          localStorage.setItem('set_alumnilist', JSON.stringify(''));
        }
        else if (data.status == true) {
          // console.log(this.url+'/school-names/')
          $('#pass_pop').trigger('click');
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">Alumnus records');
          $('#errortext').html(data.message);

          // localStorage.removeItem('set_schoolname');//clear session 
          localStorage.setItem('set_alumnilist', JSON.stringify(''));
          // $('#hrefcont').html('<a  data-dismiss="modal" (click)="redirect()"   class="btn common-btn green-btn  mr-4" >Ok</a>');
          // this.form.reset();
          // 
        }
      }, err => {
        $('.pageloader').hide();
      })
    }
    // } else {
    //   console.log('edit_api')
    //   if (this.alumni_name == false && this.current_email == false && this.current_number == false && this.hs_name == false && this.first_enrollment == false && this.collage_prgrm == false && this.planned_major == false && this.collage_name == false && this.collage_major_minor == false && this.start_work == false && this.yo_hs_graduation == false && this.company_name == false && this.salary == false && this.expected_yo_graduation == false && this.yo_graduation == false && this.update_id == false) {
    //     var value = this.form.getRawValue()
    //     console.log(value)
    //     $('.pageloader').show();
    //     this.http.post<any>(`${this.url}/manage_alumni`, value).subscribe(data => {
    //       $('.pageloader').hide();
    //       if (data.status == false) {
    //         $('#error-disp-btn').trigger('click');
    //         $('#modal_pass').html('<img src="assets/images/block.svg">Aluminus records');
    //         $('#errortext').html(data.message);
    //         localStorage.setItem('set_alumnilist', JSON.stringify(''));
    //       }
    //       else if (data.status == true) {
    //         $('#pass_pop').trigger('click');
    //         $('#error-disp-btn').trigger('click');
    //         $('#modal_pass').html('<img src="assets/images/success.svg">Aluminus records');
    //         $('#errortext').html(data.message);
    //         localStorage.setItem('set_alumnilist', JSON.stringify(''));
    //         // localStorage.removeItem('set_schoolname');//clear session   
    //         // this.form.reset();
    //         // 
    //       }
    //     }, err => {
    //       $('.pageloader').hide();
    //     })
    //   }
    // }
  }
  //
  change() {

    $('#current_number').val($('#current_number').val().replace(/^(\d{3})(\d{3})(\d+)$/, "($1) $2-$3"));

    var inputVal = ($('#current_number').val());
    // $('#phone' + id).replace(/[^0-9\.]/g,'');
    var regExp = /[a-zA-Z]/g;
    if (regExp.test(inputVal)) {
      //letters found
      $('#current_number').addClass('error');
      this.error = true;
      this.current_number = true;
    } else {
      $('#current_number').removeClass('error');
      this.error = false;
      this.current_number = false;
    }



  }
}
