import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAluminiRecordsComponent } from './admin-alumini-records.component';

describe('AdminAluminiRecordsComponent', () => {
  let component: AdminAluminiRecordsComponent;
  let fixture: ComponentFixture<AdminAluminiRecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAluminiRecordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAluminiRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
