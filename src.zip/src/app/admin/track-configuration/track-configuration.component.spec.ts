import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackConfigurationComponent } from './track-configuration.component';

describe('TrackConfigurationComponent', () => {
  let component: TrackConfigurationComponent;
  let fixture: ComponentFixture<TrackConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrackConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
