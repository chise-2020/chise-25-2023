
  import { Component, OnInit } from '@angular/core';
  import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
  import { HttpClient } from '@angular/common/http';
  import { Router } from '@angular/router';
  import { ApiService } from '../../api.service';
  declare var $: any;
  declare var jQuery: any;

@Component({
  selector: 'app-track-configuration',
  templateUrl: './track-configuration.component.html',
  styleUrls: ['./track-configuration.component.css']
})
export class TrackConfigurationComponent implements OnInit {
  url = this.api.geturl();
  isChecked: false;
  levels: any = [];
  program: any = [];
  error=false;
  getedit: any = [];
  sessionForm: FormGroup;
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    var path = localStorage.setItem('set_editpath', JSON.stringify('track_config'));
    this.getedit = JSON.parse(localStorage.getItem('set_trackconfig'));

    $('#dropdownMenu13').addClass('active');
    this.getdetails();

    this.sessionForm = this.formBuilder.group({
      edit_id: new FormControl(''),
      track_id: new FormControl(''),
      track_slot: new FormControl('', [Validators.required,]),
      session_nums: new FormControl('', [Validators.required,]),
      attendance_level: new FormControl('', [Validators.required,]),
      distribution_date: new FormControl('', [Validators.required,]),
      distribution_start: new FormControl('', [Validators.required,]),
      distribution_end: new FormControl('', [Validators.required,]),
    });

    if(this.getedit!='')
{
$('#session_num').val(this.getedit.session_num);
  this.sessionForm.get('edit_id').setValue(this.getedit.track_id);
  this.sessionForm.get('track_id').setValue(this.getedit.track);
  this.sessionForm.get('track_slot').setValue(this.getedit.track_slot);
  this.sessionForm.get('session_nums').setValue(this.getedit.session_num);
  this.sessionForm.get('attendance_level').setValue(this.getedit.attendance_level);
  this.sessionForm.get('distribution_date').setValue(this.getedit.distribution_date);
  this.sessionForm.get('distribution_start').setValue(this.getedit.distribution_start_time);
  this.sessionForm.get('distribution_end').setValue(this.getedit.distribution_end_time);
}
  }


  plus_function() {
    var $input = $('.plus').parent().find('input');
    var count=parseInt($input.val()) + 1;
    count = count > 20 ? 20 : count;
    //setting the max count, they number can be changed when the max is dynamic
    $input.val(count);
    // $input.val(parseInt($input.val()) + 1);
    $('#sess_num').val(count);
    this.sessionForm.get('session_nums').setValue(count);
    // $input.change();
    return false;
    
  }

  minus_fun () {
    var $input = $('.minus').parent().find('input');
    var count = parseInt($input.val()) - 1;
    count = count < 1 ? 1 : count;//setting count to minimum
    $input.val(count);
    $('#sess_num').val(count);
    this.sessionForm.get('session_nums').setValue(count);

    // $input.change();
    return false;
  }
  validate() {
    this.error = false;
    if (!($('#distribution_date').val())) {
      $('#distribution_date').addClass('error');
      this.error = true;
    }
    if (!($('#distribution_start').val())) {
      $('#distribution_start').addClass('error');
      this.error = true;
    }
    if (!($('#distribution_end').val())) {
      $('#distribution_end').addClass('error');
      this.error = true;
    }
    if (!($('#trackid').val())) {
        $('#trackid').addClass('error');
        this.error = true;
      }
      if (!($('#track_slot').val())) {
        $('#track_slot').addClass('error');
        this.error = true;
      }
      if (!($('#attendance_level').val())) {
        $('#attendance_level').addClass('error');
        this.error = true;
      }
   return this.error;
  }


  // getlevels()
  // {
  //   this.levels=[];
  //   this.sessionForm.get('attendance_level').setValue('');
  //   var session_count=$('#session_num').val();
  //   for (let i = 1; i <= session_count; i++) {
  //     var o=i+'/'+session_count;
  //   this.levels.push(o);
  //   }
  //   this.sessionForm.get('session_nums').setValue(session_count);
  // }
  submit() {
    
   var checkerr=this.validate();
    if (checkerr == false) {
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/session_configuration`, (this.sessionForm.getRawValue())).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          $('#alerttitle').html('<img src="assets/images/block.svg">Program Configuration');
          $('#alerttext').html(data.message);
          $('#alertbtn').trigger('click');
        }
        else if (data.status == true) {
          localStorage.setItem('set_trackconfig', JSON.stringify(0));
        $('#pass_pop').trigger('click');
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Program Configuration');
        $('#errortext').html(data.message);
        }
      }, err => {
        console.log(err);
      })
    }
  }

  getdetails() {
    var userid = {
      user_id: '',
      edit_track:(JSON.parse(localStorage.getItem('edit_trackid')))
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/drop_lists`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.program=data.program
  
    }, err => {
      $('.pageloader').hide();
    })
  }





}
