import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoSchoolnamesComponent } from './admin-schoolinfo-schoolnames.component';

describe('AdminSchoolinfoSchoolnamesComponent', () => {
  let component: AdminSchoolinfoSchoolnamesComponent;
  let fixture: ComponentFixture<AdminSchoolinfoSchoolnamesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoSchoolnamesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoSchoolnamesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
