import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-aluminiinfo',
  templateUrl: './admin-aluminiinfo.component.html',
  styleUrls: ['./admin-aluminiinfo.component.css']
})
export class AdminAluminiinfoComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  alumniList: any = [];
  items = [];
  exe=0;
  cumulative=0;
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    localStorage.setItem('set_alumnilist', JSON.stringify(''));
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
  
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    if(this.data.class!='admin')
    {
      this.exe =1;
    }
    this.getDatas()
  }
  checkalumni(){
    // console.log(this.data.user_id)
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/alumni_check`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
// console.log(data)
if (data.status == true) {
      $('#error-disp-btn').trigger('click');
      $('#modal_pass').html('<img src="assets/images/success.svg">GENERATE ALUMINI');
      $('#errortext').html(data.message);
    }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  sendMail(data){
    console.log(data.user_id)
    var type = {
      user_id: data.user_id// request post data
    }
    localStorage.setItem('send_mail_data', JSON.stringify(type));
    localStorage.setItem('online_reg', JSON.stringify('1'));
    $('#cnfrmtitle').html('<img src="assets/images/alert.svg"></i>LOGIN EMAIL');
    $('#regbutton').trigger('click');
    $('#modelcontent').html('If you click on YES, a Login Email will be sent to this User.<br><br>Are you sure of this?');
    $('#cnfrm_mail').css('display','block');
    $('#cnfrm_reg').css('display','none');
  }
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/alumni_info`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.alumniList = data.user
      this.cumulative=data.user.length;
      $('#showcount').html(data.count);
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
//to edit page
previewPage(data) {
  console.log(data)
  localStorage.setItem('set_alumnilist', JSON.stringify(data));//storing data in session
  this.router.navigate(['admin-alumini-records/']);

}
//

 //setting value of filter
 setval(type,val2)
 {
   $('#ff').html(val2);
   $('#type').val(type);
   $('.dropdown-item').removeClass('active');
   $('.'+type).addClass('active');
 }
 //
 //search function
 search(){
  var searchval=$('#value').val();
  if(searchval=='')
  {
    var search=0;
    $('#ff').html('Filter Unselected');
  }
  else
  var search=1;
   var user_id = {
     type : $('#type').val(),
     search : search,
     value : $('#value').val(),
   }
   $('.pageloader').show();
    this.http.post<any>(`${this.url}/alumni_info`,  user_id   ).subscribe(data => {
     $('.pageloader').hide();
     this.alumniList = data.user
     $('#showcount').html(data.count);
     if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
      this.exe =1;
    }else{
      this.exe =0; 
    }
   }, err => {
     $('.pageloader').hide();
   })
 }
 //
 //exporting the selected data as csv
 export_data() {
    var selected_array=['track','term','first_enrollment','alumni_name','hs_name','yo_hs_graduation','collage_name','collage_major_minor'];
    var header_array=['Track','Term','Year','Alumnus Name','High School (HS) Name','Year of HS Graduation','College / University','Major / Minor'];
    this.api.downloadFile(this.alumniList,selected_array,header_array, 'alumni_records');

}
//

 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
get_alumnidetails(data) {
  console.log(data)
  localStorage.setItem('set_alumniid', JSON.stringify(data.alumni_id));//storing data in session
  this.router.navigate(['alumini-info-details/']);

}
}
