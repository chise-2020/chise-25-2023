import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAluminiinfoComponent } from './admin-aluminiinfo.component';

describe('AdminAluminiinfoComponent', () => {
  let component: AdminAluminiinfoComponent;
  let fixture: ComponentFixture<AdminAluminiinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminAluminiinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAluminiinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
