import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificateTeacherComponent } from './certificate-teacher.component';

describe('CertificateTeacherComponent', () => {
  let component: CertificateTeacherComponent;
  let fixture: ComponentFixture<CertificateTeacherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificateTeacherComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificateTeacherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
