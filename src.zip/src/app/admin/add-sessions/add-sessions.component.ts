import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { empty } from 'rxjs';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-add-sessions',
  templateUrl: './add-sessions.component.html',
  styleUrls: ['./add-sessions.component.css']
})
export class AddSessionsComponent implements OnInit {
  url = this.api.geturl();

  isChecked: false;
  programList: any = [];
  cumulative1=0;
  cumulative=0;
  selectedItems = [];
  levels: any = [];
  getres:any = [];
  section:any = [];
  dropdownList:any = [];
  dropdownSettings = {};
  error = false;
  getedit:any = [];
  sessionForm: FormGroup;//initializing form
  constructor(private api: ApiService, private formBuilder: FormBuilder, private router: Router, private http: HttpClient,) {


  }
  ngOnInit(): void {
    this.sessionForm = this.formBuilder.group({
      session_no: new FormControl(''),
      program_location: new FormControl('', [Validators.required,]),
      session_date: new FormControl('', [Validators.required,]),
      session_type: new FormControl('', [Validators.required,]),
      section: new FormControl('', [Validators.required,]),
      teacher: new FormControl('', [Validators.required,]),
      start_time: new FormControl('', [Validators.required,]),
      end_time: new FormControl('', [Validators.required,]),
      track_id: new FormControl('', [Validators.required,]),
      edittrack_id: new FormControl('', [Validators.required,]),
      section_no: new FormControl('', [Validators.required,]),
    });

    
    localStorage.setItem('set_section', JSON.stringify(''))
    var path = localStorage.setItem('set_editpath', JSON.stringify('session_config'));
    this.getres = JSON.parse(localStorage.getItem('set_session_config'));
    this.sessionForm.get('track_id').setValue(this.getres.track_id);
    $('#dropdownMenu13').addClass('active');
    for (let i = 1; i <= this.getres.session_num; i++) {
      var o=i;
    this.levels.push(o);
    }
    this.getdetails();


    this.selectedItems = [
    ];

    this.dropdownSettings =
    {
      singleSelection: false,
      idField: 'id',
      textField: 'teacher_view',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 0,
      allowSearchFilter: true,
      // showSelectedItemsAtTop: false,
    };
  
  }


  
  validate() {
    this.error = false;
    if (!($('#session_no').val())) {
      $('#session_no').addClass('error');
      this.error = true;
    }else
    {
      $('#session_no').removeClass('error');
    }

    if (!($('#program_location').val())) {
      $('#program_location').addClass('error');
      this.error = true;
    }else
    {
      $('#program_location').removeClass('error');
    }

    if (!($('#session_date').val())) {
      $('#session_date').addClass('error');
      this.error = true;
    }else
    {
      $('#session_date').removeClass('error');
    }

    if (!($('#session_type').val())) {
        $('#session_type').addClass('error');
        this.error = true;
      }
      else
    {
      $('#session_type').removeClass('error');
    }

      if (!($('#section').val())) {
        $('#section').addClass('error');
        this.error = true;
      }
      else
    {
      $('#section').removeClass('error');
    }
      if((this.selectedItems.length)==0) {
        $('#teacher').addClass('error');
        this.error = true;
      }
      else
    {
      $('#teacher').removeClass('error');
    }
      if (!($('#start_time').val())) {
        $('#start_time').addClass('error');
        this.error = true;
      }
      else
    {
      $('#start_time').removeClass('error');
    }
      if (!($('#end_time').val())) {
        $('#end_time').addClass('error');
        this.error = true;
      }else
      {
        $('#end_time').removeClass('error');
      }
   return this.error;
  }

//to edit page
previewPage(data) {
  console.log(data);
  localStorage.setItem('set_section', JSON.stringify(data));
  this.getedit = JSON.parse(localStorage.getItem('set_section'));
  this.sessionForm.get('session_no').setValue(this.getedit.session_num);
  this.sessionForm.get('program_location').setValue(this.getedit.program_location);
  this.sessionForm.get('session_date').setValue(this.getedit.session_date);
  this.sessionForm.get('session_type').setValue(this.getedit.session_type);
  this.sessionForm.get('section').setValue(this.getedit.section);
  this.sessionForm.get('section_no').setValue(this.getedit.section_no);
  
  var str=this.getedit.teachersid;
  this.selectedItems=str.split(",");
  this.sessionForm.get('start_time').setValue(this.getedit.section);
  this.sessionForm.get('start_time').setValue(this.getedit.session_time);
  this.sessionForm.get('end_time').setValue(this.getedit.end_time);
  this.sessionForm.get('edittrack_id').setValue(this.getedit.sessionids);
  
   document.getElementById('spage').scrollIntoView()
  
  

 
}
//

  
  deleteData(data) {

    $('#deletebttn').trigger('click');
    var user = {
      tablename: 'session_config',
      fieldid: data.sessionids,
      fieldname: 'section_no'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));

  }

  submit() {
    
    var checkerr=this.validate();
     if (checkerr == false) {
       $('.pageloader').show();
       this.http.post<any>(`${this.url}/add_sessions`, (this.sessionForm.getRawValue())).subscribe(data => {
         $('.pageloader').hide();
         if (data.status == false) {
           $('#alerttitle').html('<img src="assets/images/block.svg">Session Configuration');
           $('#alerttext').html(data.message);
           $('#alertbtn').trigger('click');
         }
         else if (data.status == true) {
          localStorage.setItem('set_section', JSON.stringify(''))
         $('#pass_pop').trigger('click');
         $('#error-disp-btn').trigger('click');
         $('#modal_pass').html('<img src="assets/images/success.svg">Session Configuration');
         $('#errortext').html(data.message);
         }
       }, err => {
         console.log(err);
       })
     }
   }
  

  getdetails() {
    var userid = {
      configid: this.getres.track_id,
      trackid: this.getres.track
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/getsession_sections`, userid).subscribe(data => {
      $('.pageloader').hide();
      this.programList = data.list
      this.dropdownList = data.teachers
      this.section= data.sections
      this.cumulative= data.list.length
      this.cumulative1= data.list.length
    }, err => {
      $('.pageloader').hide();
    })
  }


   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
  //


  search()
  {
     var userid = {
     type : $('#type').val(),
     search : 1,
     value : $('#value').val(),
     configid: this.getres.track_id,
     trackid: this.getres.track,
   }
   $('.pageloader').show();
   this.http.post<any>(`${this.url}/getsession_sections`, userid).subscribe(data => {
     $('.pageloader').hide();
     this.programList = data.list
     this.dropdownList = data.teachers
     this.section= data.sections
     this.cumulative= data.list.length
     this.cumulative1= data.list.length
   }, err => {
     $('.pageloader').hide();
   })
  }
}
