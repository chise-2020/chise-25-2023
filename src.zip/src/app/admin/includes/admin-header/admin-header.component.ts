import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../../api.service';
declare var $: any;
@Component({
    selector: 'app-admin-header',
    templateUrl: './admin-header.component.html',
    styleUrls: ['./admin-header.component.css']
  })
  export class AdminHeaderComponent implements OnInit {
  logdata:any;
  url = this.api.geturl();
  notifications= [];
  UserData: any;
  PasswordForm: FormGroup;
  newPassword = false;
  oldPassword = false;
  confirmPassword = false;
  constructor(private api: ApiService,private fb: FormBuilder,private router: Router,private http: HttpClient ,) {
    this.createPasswordForm();
  }


  ngOnInit(): void {
    // localStorage.setItem("add_click", JSON.stringify('0')); 
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    $(document).on('click', '.toggle-password', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input = $("#oldPassword");
      input.attr('type') === 'password' ? input.attr('type', 'text') : input.attr('type', 'password')

    });

    $(document).on('click', '.togglepassword', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input1 = $("#newPassword");
      input1.attr('type') === 'password' ? input1.attr('type', 'text') : input1.attr('type', 'password')
    });

    $(document).on('click', '.togglepasswords', function () {

      $(this).toggleClass("fa-eye fa-eye-slash");

      var input2 = $("#confirmPassword");
      input2.attr('type') === 'password' ? input2.attr('type', 'text') : input2.attr('type', 'password')
    });
  
   
    $(document).on('click', '.mobile-menu-button', function () {
      $(".mega-menu").toggleClass("open");
     });
     $(document).on('click', '.close-menu', function () {
      $(".mega-menu").toggleClass("open");
     });
    //  
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
    if((this.UserData.class == 'teacher') || (this.UserData.class == 'executive 1') || (this.UserData.class == 'executive 2')){
$('#settings').css('display','none');
$('.parents').css('display','block');
$('#bellicon').css('display','none');
    }
    this.checkuser()
    this.getnotification()
    this.studentcerti_crone()
  }
  studentcerti_crone(){
    var user_id = {
      user_id : ''
    }
    this.http.post<any>(`${this.url}/studentcerti_crone`,user_id).subscribe(data => {
      // if(data.status==false)
      // {
     
      // }
     
      })
  }
  getnotification(){
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    var user_id = {
      user_id : this.logdata.user_id
    }
    this.http.post<any>(`${this.url}/get_notification`,user_id).subscribe(data => {
      if(data.status==true)
      {
     this.notifications=data.list;
      }
     
      })
  }

  passwordSubmit() {
    var number = /([0-9])/;
    var alphabets = /([a-zA-Z])/;
    var special_characters = /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/;
    this.oldPassword = this.newPassword = this.confirmPassword = false;
    if (this.PasswordForm.getRawValue().oldPassword == '')
      this.oldPassword = true
    if (this.PasswordForm.getRawValue().newPassword == '')
      this.newPassword = true
    if (this.PasswordForm.getRawValue().confirmPassword == '')
      this.confirmPassword = true

    if (this.oldPassword == false && this.newPassword == false && this.confirmPassword == false) {
      if (this.PasswordForm.getRawValue().newPassword.length < 8) {
        this.newPassword = true
        $('#pass_pop').trigger('click');
        $('#new-pop').trigger('click');
        $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
        $('#new_pop_html').html('Password should be atleast 8 characters.')
        return;
      }
      if (this.PasswordForm.getRawValue().newPassword != this.PasswordForm.getRawValue().confirmPassword) {
        this.confirmPassword = true
        $('#pass_pop').trigger('click');
        $('#new-pop').trigger('click');
        $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
        $('#new_pop_html').html('Password mismatch.');
        return;
      }
      // if (this.PasswordForm.getRawValue().newPassword.match(/[a-z]/g) && this.PasswordForm.getRawValue().newPassword.match(/[A-Z]/g) && this.PasswordForm.getRawValue().newPasswordtr.match(/[0-9]/g) && this.PasswordForm.getRawValue().newPassword.match(/[^a-zA-Z\d]/g) && this.PasswordForm.getRawValue().newPassword.length >= 8) {
        var pwd = {
          oldpass: this.PasswordForm.value.oldPassword,
          newpass: this.PasswordForm.value.newPassword,
          user_id: this.logdata.user_id
        }
        $('.pageloader').show();
        this.http.post<any>(`${this.url}/changepassword`, pwd).subscribe(data => {
          $('.pageloader').hide();
          if (data.status == false) {
            //this.oldPassword= true
            $('#pass_pop').trigger('click');
            $('#new-pop').trigger('click');
            $('#new_pop_text').html('<img src="assets/images/block.svg"> Password');
            $('#new_pop_html').html(data.message);
          }
          else if (data.status == true) {
            $('#pass_pop').trigger('click');
            $('#error-disp-btn').trigger('click');
            $('#modal_pass').html('<img src="assets/images/success.svg"> Password ');
            $('#errortext').html(data.message);
          }
        }, err => {
          $('.pageloader').hide();
        })
  

    }

  }

  createPasswordForm() {
    this.PasswordForm = this.fb.group({
      oldPassword: new FormControl('', [Validators.required,]),
      newPassword: new FormControl('', [Validators.required,]),
      confirmPassword: new FormControl('', [Validators.required,]),
      user_id: new FormControl('', [Validators.required,]),
    });
  }
  checkuser()
  {
    if(localStorage.getItem('loginData') === null)
    {
      // this.router.navigate(['login/']);
      // localStorage.clear();
    }else
    {
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id : this.logdata.user_id
      }
      this.http.post<any>(`${this.url}/check_user`,user_id).subscribe(data => {
        if(data.status==false)
        {
          this.router.navigate(['login/']);
          localStorage.clear();
        }
        if(data.onlinereg_status==1){
          $('#faicon').addClass('green2');
        }else{
          $('#faicon').addClass('redhead');
          $('#faicon').css('background','red !important');
            $('#faicon').html('ONLINE REGISTRATION CLOSED');
        }
       
        })
    }


  }

  test_str() {
    // alert('in')
    var str = $('#newPassword').val();
    // alert(str)
    if (str.match(/[a-z]/g) && str.match(/[A-Z]/g) && str.match(/[0-9]/g) && str.match(/[^a-zA-Z\d]/g) && str.length >= 8) {
      $('#newPassword').removeClass('error');
      $('#error_title').html('');
     }
    else {
      $('#newPassword').addClass('error');
      $('#error_title').html('( Password must must contain at least one number and one uppercase and lowercase letter,and one special character and at least 8 or at most 12 characters )')
   
    }


  }

  faq(){
    // alert(window.location.href);
      var url =window.location.href;
      const lastSegment = url.substring(url.lastIndexOf("/") + 1);
      // alert(lastSegment)
      localStorage.setItem('previous_url',JSON.stringify(lastSegment));
  }
  logout() {
    localStorage.clear();
      this.router.navigate(['login/']);
  }
 
  notification() {
    // alert('working')
    if (localStorage.getItem('loginData') === null) {
      this.router.navigate(['login/']);
      localStorage.clear();



    } else {
      
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id: ''
      }
      this.http.post<any>(`${this.url}/check_online`, user_id).subscribe(data => {
          $('#notipop').html(data.message);
        $('#noti_button').trigger('click');

      })
     
    }


  }
}
