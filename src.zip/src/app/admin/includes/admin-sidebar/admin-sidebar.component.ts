import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../api.service';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.css']
})
export class AdminSidebarComponent implements OnInit {
  url = this.api.geturl();
  logdata: any = [];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {

  }

  ngOnInit(): void {
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if (localStorage.getItem("loginData") != null) {

    
      if ((this.logdata.class == 'executive 1')) {

        $('#c-7').css('display', 'none');
        $('#c_7').css('display', 'block');
        $('#admin_award').css('display', 'none');
        $('#exce_award').css('display', 'block');
        $('#user_confg').css('display', 'none');
        $('.teach').css('display', 'none');
        $('.add_button').css('display', 'none');
        $('.exec').css('display', 'block');
        $('.exec1').css('display', 'none');
      }
      if (this.logdata.class == 'executive 2') {
        $('.exec2').css('display', 'none');
      }
      if (this.logdata.class == 'data manager') {
        $('.dm').css('display', 'none');
      }


      

      if ((this.logdata.class == 'teacher')) {
        $('.teach').css('display', 'block');
        $('.admin').css('display', 'none');
      }
      if ((this.logdata.class == 'admin')) {
        $('.teach').css('display', 'none');
        $('.admin').css('display', 'block');
      }
      if ((this.logdata.class == 'data manager')) {
        $('.teach').css('display', 'none');
        $('.admin').css('display', 'block');
        $('.dm').css('display', 'none');
      }
      // if ((this.logdata.class == 'executive 1') ){

      // }
    }
  }

  reset_user() {

    $('#add_1').addClass('active');
    localStorage.setItem('set_subscribeduser', JSON.stringify(''));
    this.router.navigate(['admin-configure/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }


  reset_register() {
    $('#add_2').addClass('active');
    localStorage.setItem('set_allregisterrecord', JSON.stringify(''));
    this.router.navigate(['register-student-team/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }


  reset_letter_grade() {
    $('#addt_3').addClass('active');
    localStorage.setItem('set_lettergrade', JSON.stringify(''));
    this.router.navigate(['add-letter-grade/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  reset_course() {
    $('#addt_4').addClass('active');
    localStorage.setItem('set_schoolcourse', JSON.stringify(''));
    this.router.navigate(['edit-school-course/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }
  faq() {
    // alert(window.location.href);
    var url = window.location.href;
    const lastSegment = url.substring(url.lastIndexOf("/") + 1);
    // alert(lastSegment)
    localStorage.setItem('previous_url', JSON.stringify(lastSegment));
  }
  reset_school() {
    $('#addt_5').addClass('active');
    localStorage.setItem('set_schoolcourse', JSON.stringify(''));
    this.router.navigate(['edit-school-name/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  reset_program() {
    $('#addt_6').addClass('active');
    localStorage.setItem('setprogram_module', JSON.stringify(''));
    this.router.navigate(['edit-program-module/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  reset_teacherassign() {
    $('#addt_7').addClass('active');
    localStorage.setItem('set_schoolcourse', JSON.stringify(''));
    this.router.navigate(['edit-teachers-assignment/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  reset_alumni() {
    $('#addt_8').addClass('active');
    localStorage.setItem('set_schoolcourse', JSON.stringify(''));
    this.router.navigate(['admin-alumini-records/']);
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }
}
