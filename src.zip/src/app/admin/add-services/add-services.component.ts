import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;
@Component({
  selector: 'app-add-services',
  templateUrl: './add-services.component.html',
  styleUrls: ['./add-services.component.css']
})
export class AddServicesComponent implements OnInit {
  url = this.api.geturl();
  form: FormGroup;//initializing form
  UserData: any;
  chise_events: any;
  user_class=false;
  survey_link=false;
  survey_title=false;
  survey_id=false;
  survey_description=false;
  error=false;
  survey_list: any=[];
  exe: number;
  cumulative=0;
  cumulative1=0;
  editdata:any=[];
  constructor(private api: ApiService, private fb: FormBuilder, private http: HttpClient, private router: Router,) {
    this.createForm(); //creating form validation
  }
  
  ngOnInit(): void {
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('#dropdownMenu29').addClass('active');
    this.UserData = JSON.parse(localStorage.getItem('loginData'));
 if ((this.UserData.class == 'executive 1') || (this.UserData.class == 'executive 2') ) {
  this.exe =1;
}else{
  this.exe =0; 
}


this.editdata = JSON.parse(localStorage.getItem('set_survey'));
console.log(this.editdata);
if (this.editdata =='') {
  $('#tpsection').html("Add CHIS&E SURVEY");
} else {
  $('#tpsection').html("Edit CHIS&E SURVEY ");
}

this.form.get('survey_id').setValue(this.editdata.id);
this.form.get('survey_link').setValue(this.editdata.survey_link);
this.form.get('user_class').setValue(this.editdata.user_class);
this.form.get('survey_title').setValue(this.editdata.survey_title);
this.form.get('survey_description').setValue(this.editdata.survey_description);
  }

 
//creating form
createForm() {
  this.form = this.fb.group({
    user_class: new FormControl('', [Validators.required,]),
    survey_link: new FormControl('', [Validators.required,]),
    survey_id: new FormControl('', ),
    survey_title:new FormControl('', [Validators.required,]),
    survey_description:new FormControl('', [Validators.required,]),
  });
}
//
OnSubmit(){
  var path=localStorage.setItem('set_editpath', JSON.stringify('survey'));

  if (!($('#survey_description').val())) {
    $('#survey_description').addClass('error');
    this.error = true;
  } else {
    $('#survey_description').removeClass('error');
    this.error = false;
  }
  if (!($('#survey_title').val())) {
    $('#survey_title').addClass('error');
    this.error = true;
  } else {
    $('#survey_title').removeClass('error');
    this.error = false;
  }
  if (!($('#survey_link').val())) {
    $('#survey_link').addClass('error');
    this.error = true;
  } else {
    $('#survey_link').removeClass('error');
    this.error = false;
  }
   if (!($('#user_class').val())) {
    $('#user_class').addClass('error');
    this.error = true;
  } else {
    $('#user_class').removeClass('error');
    this.error = false;
  }
 
    if (this.error == false) {
     
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/add_survey`,this.form.value).subscribe(data => {
        $('.pageloader').hide();
        if (data.status == false) {
          //this.oldPassword= true
          $('#new-pop').trigger('click');
          $('#new_pop_text').html('<img src="assets/images/block.svg">ChiS&E Survey');
          $('#new_pop_html').html(data.message);
        }
        else if (data.status == true) {
    
          $('#error-disp-btn').trigger('click');
          $('#modal_pass').html('<img src="assets/images/success.svg">ChiS&E Survey');
          $('#errortext').html(data.message);
        }
      }, err => {
        $('.pageloader').hide();
      }
      )
    }
}




}
