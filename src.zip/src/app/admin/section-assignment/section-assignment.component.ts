import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-section-assignment',
  templateUrl: './section-assignment.component.html',
  styleUrls: ['./section-assignment.component.css']
})
export class SectionAssignmentComponent implements OnInit {
  searchText: any = '';
  data: any = [];
  url = this.api.geturl();
  programList: any = [];
  exe=0;
  cumulative=0;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }


  ngOnInit(): void {
    localStorage.setItem('set_section_assignment', JSON.stringify(''));
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.getDatas()
  }
  getDatas() {
    console.log(this.data.user_id)
    var type = {
      type: ""// request post data
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/section_assignments`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.programList = data.program
      $('#showcount').html(data.count);
      this.cumulative=data.program.length;
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  //to edit page
  previewPage(data) {
    console.log(data)
    localStorage.setItem('set_section_assignment', JSON.stringify(data));//storing data in session
    this.router.navigate(['edit-section-assignment/']);// redirecting 

  }
  //

  //
  //setting value of filter
  
  setval(type,val2)
  {
    $('#ff').html(val2);
    $('#type').val(type);
    $('.dropdown-item').removeClass('active');
    $('.'+type).addClass('active');
  }
  //
  //search function
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;

    var user_id = {
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/section_assignments`,  user_id   ).subscribe(data => {
      $('.pageloader').hide();
      this.programList = data.program
      $('#showcount').html(data.count);
      if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
    }, err => {
      $('.pageloader').hide();
    })
  }
  //
   //exporting the selected data as csv
 export_data() {
    var selected_array=['track'];
    var header_array=['Track Name'];
    this.api.downloadFile(this.programList,selected_array,header_array, 'chise_tracks');
}
//
}
