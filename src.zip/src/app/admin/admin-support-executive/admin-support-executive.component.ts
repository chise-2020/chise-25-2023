import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-support-executive',
  templateUrl: './admin-support-executive.component.html',
  styleUrls: ['./admin-support-executive.component.css']
})
export class AdminSupportExecutiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
