import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSupportExecutiveComponent } from './admin-support-executive.component';

describe('AdminSupportExecutiveComponent', () => {
  let component: AdminSupportExecutiveComponent;
  let fixture: ComponentFixture<AdminSupportExecutiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSupportExecutiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSupportExecutiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
