import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSchoolinfoLettergradeDetailsComponent } from './admin-schoolinfo-lettergrade-details.component';

describe('AdminSchoolinfoLettergradeDetailsComponent', () => {
  let component: AdminSchoolinfoLettergradeDetailsComponent;
  let fixture: ComponentFixture<AdminSchoolinfoLettergradeDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSchoolinfoLettergradeDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSchoolinfoLettergradeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
