import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-admin-schoolinfo-lettergrade-details',
  templateUrl: './admin-schoolinfo-lettergrade-details.component.html',
  styleUrls: ['./admin-schoolinfo-lettergrade-details.component.css']
})
export class AdminSchoolinfoLettergradeDetailsComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  lettergradeList: any = [];
  items = [];
  exe=0;
  pageOfItems: Array<any>;
  studentid: any;
  cumulative=0;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#c1').trigger('click');
    // $('.sdebar').css('display','none');
    $('#dropdownMenu12').addClass('active');//my dashboard menu highlight
    this.data = JSON.parse(localStorage.getItem('loginData')); //the data stored in session while login
    this.studentid = JSON.parse(localStorage.getItem('set_student_id'));
    this.getDatas()
   
  }
    getDatas() {
      console.log(this.data.user_id)
      var type = {
        user_id:this.studentid // request post data
      }
      $('.pageloader').show();
      this.http.post<any>(`${this.url}/letter_grade_details`, type).subscribe(data => {
        console.log(data)
        $('.pageloader').hide();
        this.lettergradeList = data.user
        this.cumulative= data.user;
        $('#showcount').html(data.count);
        if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
          this.exe =1;
        }else{
          this.exe =0; 
        }
      }, err => {
        $('.pageloader').hide();
        console.log(err);
      })
    }
  //to edit page
  previewPage(data) {
    console.log(data)
    localStorage.setItem('set_lettergrade', JSON.stringify(data));//storing data in session
    console.log('data from list')
    this.router.navigate(['edit-letter-grade/']);

  }
  //
  //deleting users
  deleteData(data) {
    $('#deletebttn').trigger('click');
    var user = {
      tablename : 'students',
      fieldid: data.student_id,
      fieldname: 'student_id'
    }
    localStorage.setItem('delete_item', JSON.stringify(user));
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
       user_id:this.studentid
     }
     $('.pageloader').show();
      this.http.post<any>(`${this.url}/letter_grade_details`,  user_id   ).subscribe(data => {
       $('.pageloader').hide();
       this.lettergradeList = data.user
       $('#showcount').html(data.count);
       if ((this.data.class == 'executive 1') || (this.data.class == 'executive 2') ) {
        this.exe =1;
      }else{
        this.exe =0; 
      }
     }, err => {
       $('.pageloader').hide();
     })
   }
   //
 //exporting the selected data as csv
 export_data() {
    var selected_array=['full_names','academic_year',,'academic_term','grade','school_name','program_name','math_track','math_grade','science_track','science_grade','cs_track','cs_grade'];
    var header_array=['Student','Year','Term','Grade','School','ChiS&E Track','Math Track','Math Grade','Science Track','Science Grade','CS Track','CS Grade'];
    this.api.downloadFile(this.lettergradeList,selected_array,header_array, 'letter_grades_details');
}
//

   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
}
}

