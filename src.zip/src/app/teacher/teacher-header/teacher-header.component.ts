import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-teacher-header',
  templateUrl: './teacher-header.component.html',
  styleUrls: ['./teacher-header.component.css']
})
export class TeacherHeaderComponent implements OnInit {
  logdata:any;
  url = this.api.geturl();
  constructor(private api: ApiService,private fb: FormBuilder,private router: Router,private http: HttpClient ,) {
    
  }

  ngOnInit(): void {
    this.checkuser()
  }
  faq(){
    // alert(window.location.href);
      var url =window.location.href;
      const lastSegment = url.substring(url.lastIndexOf("/") + 1);
      // alert(lastSegment)
      localStorage.setItem('previous_url',JSON.stringify(lastSegment));
  }
  checkuser()
  {
    if(localStorage.getItem('loginData') === null)
    {
      // this.router.navigate(['login/']);
      // localStorage.clear();
    }else
    {
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id : this.logdata.user_id
      }
      this.http.post<any>(`${this.url}/check_user`,user_id).subscribe(data => {
        if(data.status==false)
        {
          this.router.navigate(['login/']);
          localStorage.clear();
        }
       
        })
    }


  }

  logout() {
    localStorage.clear();
    this.router.navigate(['login/']);
  }
}
