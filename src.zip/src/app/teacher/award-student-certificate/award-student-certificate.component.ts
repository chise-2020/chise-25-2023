import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-award-student-certificate',
  templateUrl: './award-student-certificate.component.html',
  styleUrls: ['./award-student-certificate.component.css']
})
export class AwardStudentCertificateComponent implements OnInit {
  logdata: any = [];
  messageForm: FormGroup;
  url = this.api.geturl();
  list: any = [];
  items = [];
  cumulative=0;
  pageOfItems: Array<any>;
  session_num: any;
  tracks: any;
  error: boolean;
  public sourceData: string;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private formBuilder: FormBuilder,) { }
  
  ngOnInit(): void {
    $('#showcount').html('0');
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") ) {
      $('#dropdownMenu13').addClass('active');//menu highlight
      $('#track_pop').html('Please select from the list of Tracks configured for this Term');
    }
    if ((this.logdata.class == "teacher")) {
      $('#dropdownMenu172').addClass('active');//menu highlight
      
    }
    this.getdetails();
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
  }
  getDatas(){
    var type = {
      trackid: $('#teacher_track').val(),
      teacher_id : this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/teacher_rollcall`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.rollcall
      this.cumulative=data.rollcall.length;
      $('#showcount').html(data.rollcall.length);
     
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  getdetails() {
    var type = {
      type: "",// request post data,
      teacher_id : this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_teacherdrops`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      // this.session_num = data.session_num
      this.tracks = data.list
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  award_Certi(data){
    $('#error-disp-btn').trigger('click');
    $('#modal_pass').html('<img src="assets/images/alert.svg">Award Student Certificates');
    if($('#eligiblity').val()=='Yes')
{
    $('#errortext').html('Are you sure you want to award the Student Certificate to '+data.student_name+'?');
}else{
  $('#errortext').html('Are you sure you do not want to award the Student Certificate to '+data.student_name+'?');
}
    $('#ok').css('display','none');
    $('#yesbtn').css('display','block');
    $('#ok_btn').css('display','block');
    var type = {
      // teacher_id : this.logdata.user_id,
      register_id:data.id,
      certificate_status:$('#eligiblity').val(),
      student_id:data.student_id,
      }
      localStorage.setItem('set_award_details', JSON.stringify(type));
      // $('.pageloader').show();
      //     this.http.post<any>(`${this.url}/award_student_certi`, type).subscribe(data => {
      //       console.log(data)
      //       $('.pageloader').hide();
      //       if (data.status == false) {
      //         $('#alerttitle').html('<img src="assets/images/block.svg">Award Student Certificates');
      //         $('#alerttext').html(data.message);
      //         $('#alertbtn').trigger('click');
      //       }
      //       else if (data.status == true) {
      //         $('#alerttitle').html('<img src="assets/images/success.svg">Award Student Certificates');
      //         $('#alerttext').html(data.message);
      //         $('#alertbtn').trigger('click');
      //       }
            
      //     }, err => {
      //       $('.pageloader').hide();
      //       console.log(err);
      //     })
  }
  notify_award(){
    var type = {
      teacher_name: this.logdata.firstname+' '+this.logdata.lastname,
      // register_id:data.id,
      // certificate_status:$('#eligiblity').val(),
      // student_id:data.student_id,
      type:''
      }
   $('.pageloader').show();
          this.http.post<any>(`${this.url}/notify_award`, type).subscribe(data => {
            console.log(data)
            $('.pageloader').hide();
            if (data.status == false) {

              $('#alerttitle').html('<img src="assets/images/block.svg">Award Student Certificates');
              $('#alerttext').html(data.message);
              $('#alertbtn').trigger('click');
            }
            else if (data.status == true) {
        $('#error-disp-btn').trigger('click');
        $('#modal_pass').html('<img src="assets/images/success.svg">Award Student Certificates');
        $('#errortext').html(data.message);
             
            }
            
          }, err => {
            $('.pageloader').hide();
            console.log(err);
          })
  }

    //exporting the selected data as csv
    export_data() {
      var selected_array=['student_name','totalparticipation','needed_participation','eligiblility'];
      var header_array=['Student Name','Actual Participation Level','Required Participation Level','Award Certificate?'];
     this.api.downloadFile(this.list,selected_array,header_array, 'Award Student Certificate');
  }
}
