import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AwardStudentCertificateComponent } from './award-student-certificate.component';

describe('AwardStudentCertificateComponent', () => {
  let component: AwardStudentCertificateComponent;
  let fixture: ComponentFixture<AwardStudentCertificateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AwardStudentCertificateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AwardStudentCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
