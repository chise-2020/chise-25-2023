import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-track-assignment',
  templateUrl: './track-assignment.component.html',
  styleUrls: ['./track-assignment.component.css']
})
export class TrackAssignmentComponent implements OnInit {
  logdata: any = [];
    url = this.api.geturl();
    list: any = [];
    items = [];
    pageOfItems: Array<any>;
    cumulative: any = [];
    constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }
  
    ngOnInit(): void {
      
      // $('#msg1').trigger('click');
      $('#dropdownMenu12').addClass('active');//menu highlight
      this.logdata = JSON.parse(localStorage.getItem('loginData'));
      this.getDatas()
    }
  
  
   
 
   //setting value of filter
   setval(type,type2,type3)
   {
    $('#ff').html(type3);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('#'+type2).addClass('active');
   }
   
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
       user_id : this.logdata.user_id,
     }
     $('.pageloader').show();
     this.http.post<any>(`${this.url}/teacher_assignments`, user_id).subscribe(data => {
       console.log(data)
       $('.pageloader').hide();
       this.list = data.user
       $('#showcount').html(data.count);
     }, err => {
       $('.pageloader').hide();
       console.log(err);
     })
   }

   getDatas() {
    var type = {
      type: "",// request post data,
      user_id : this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/teacher_assignments`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.user
      this.cumulative=data.user.length;
      $('#showcount').html(data.count);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  


  //exporting the selected data as csv //varsha
  export_data() {
      var selected_array=['academic_term', 'academic_year','track'];
      var header_array=['Academic Term', 'Academic Year','Track'];
     this.api.downloadFile(this.list,selected_array,header_array, 'Track Assigned To Me');
  }
  //
  
   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  
  }
  