import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;

@Component({
  selector: 'app-student-awards',
  templateUrl: './student-awards.component.html',
  styleUrls: ['./student-awards.component.css']
})
export class StudentAwardsComponent implements OnInit {
  data: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  logdata: any = [];
  cumulative:any = [];
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#dash1').trigger('click');
    $('#dropdownMenu172').addClass('active');//menu highlight
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    this.getDatas()
  }
  //
   //setting value of filter
   setval(type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+type).addClass('active');
   }
   //
   //search function
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
    var user_id = {
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
      teacher_id : this.logdata.user_id
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/student_certi`,  user_id   ).subscribe(data => {
      this.list = data.awards
      $('#showcount').html(data.awards.length);
      $('#pageheading').html(data.term_year);
      $('.pageloader').hide();
    }, err => {
      $('.pageloader').hide();
    })
  }
  getDatas() {
    var type = {
      type: "",// request post data,
      teacher_id : this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/student_certi`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.awards
      $('#showcount').html(data.awards.length);
      this.cumulative=data.awards.length;
      $('#pageheading').html('Current Term:  '+data.term_year);
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

//deleting schools
deleteData(data) {
 
  $('#deletebttn').trigger('click');
  var user = {
    tablename : 'students',
    fieldid: data.student_id,
    fieldname: 'student_id'
  }
  localStorage.setItem('delete_item', JSON.stringify(user));
}
//
showcertificate(data){
  // alert('working')
  localStorage.setItem('student_certificate', JSON.stringify(data));
 
}



 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}


