import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-registrationflyer',
  templateUrl: './registrationflyer.component.html',
  styleUrls: ['./registrationflyer.component.css']
})
export class RegistrationflyerComponent implements OnInit {

  logdata: any;
  url = this.api.geturl();
  notifications= [];
  constructor(private api: ApiService, private fb: FormBuilder, private router: Router, private http: HttpClient,) {

  }
  ngOnInit(): void {
    // $('#msg1').trigger('click');
    $('#dropdownMenu17').addClass('active');//menu highlight
    this.notification();
  }
  notification() {
    // alert('working')
    if (localStorage.getItem('loginData') === null) {
      this.router.navigate(['login/']);
      localStorage.clear();
    } else {
      
      // this.logdata = JSON.parse(localStorage.getItem('loginData'));
      var user_id = {
        user_id: ''
      }
      this.http.post<any>(`${this.url}/check_online`, user_id).subscribe(data => {
          $('#flyer_content').html(data.message_flyer);
          $('#term_year').html(data.term_year);
        // $('#noti_button').trigger('click');

      })
     
    }
}
}
