import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationflyerComponent } from './registrationflyer.component';

describe('RegistrationflyerComponent', () => {
  let component: RegistrationflyerComponent;
  let fixture: ComponentFixture<RegistrationflyerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistrationflyerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationflyerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
