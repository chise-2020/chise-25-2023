import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-teacher-awards',
  templateUrl: './teacher-awards.component.html',
  styleUrls: ['./teacher-awards.component.css']
})
export class TeacherAwardsComponent implements OnInit {
  logdata: any = [];
  url = this.api.geturl();
  list: any = [];
  cumulative: any = [];
  items = [];
  pageOfItems: Array<any>;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    // $('#dash1').trigger('click');
    $('#dropdownMenu12').addClass('active');//menu highlight
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    this.getDatas()
  }
  //
   //setting value of filter
   setval(val,type,val2)
   {
     $('#ff').html(val2);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
     $('.'+val).addClass('active');
   }
   //
   //search function
  search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
    var user_id = {
      type : $('#type').val(),
      search : search,
      value : $('#value').val(),
      user_id : this.logdata.user_id,
    }
    $('.pageloader').show();
     this.http.post<any>(`${this.url}/teacher_certificate`,  user_id   ).subscribe(data => {
      this.list = data.awards
      $('#showcount').html(data.count);
      $('.pageloader').hide();
    }, err => {
      $('.pageloader').hide();
    })
  }
  getDatas() {
    var type = {
      type: "",// request post data
      user_id : this.logdata.user_id,
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/teacher_certificate`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      this.list = data.awards
      $('#showcount').html(data.count);
      this.cumulative=data.awards.length;
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }

//deleting schools
deleteData(data) {
 
  $('#deletebttn').trigger('click');
  var user = {
    tablename : 'teacher_assignment',
    fieldid: data.assign_id,
    fieldname: 'assign_id'
  }
  localStorage.setItem('delete_item', JSON.stringify(user));
}
//

showcertificate(data){
  // alert('working')
  localStorage.setItem('teacher_certificate', JSON.stringify(data));
 
}



 onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}

