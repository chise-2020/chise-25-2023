import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentAttendenceLevelComponent } from './student-attendence-level.component';

describe('StudentAttendenceLevelComponent', () => {
  let component: StudentAttendenceLevelComponent;
  let fixture: ComponentFixture<StudentAttendenceLevelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentAttendenceLevelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentAttendenceLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
