import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';
declare var $: any;
@Component({
  selector: 'app-student-attendence-level',
  templateUrl: './student-attendence-level.component.html',
  styleUrls: ['./student-attendence-level.component.css']
})
export class StudentAttendenceLevelComponent implements OnInit {
  logdata: any = [];
  url = this.api.geturl();
  list: any = [];
  items = [];
  cumulative=0;
  pageOfItems: Array<any>;
  tracks: any;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,) { }

  ngOnInit(): void {
    $('#dropdownMenu171').addClass('active');//menu highlight
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    // this.getDatas()
    this.getdetails()
  }
//setting value of filter
setval(type,type3)
{
 $('#ff').html(type3);
  $('#type').val(type);
  $('.dropdown-item').removeClass('active');
  // $('#'+type2).addClass('active');
}

//
//search function
search(){
 var searchval=$('#value').val();
 if(searchval=='')
 {
   var search=0;
   $('#ff').html('Filter Unselected');
 }
 else
 var search=1;
  var user_id = {
    type : $('#type').val(),
    search : search,
    value : $('#value').val(),
    user_id : this.logdata.user_id,
    trackid: $('#teacher_track').val(),
    teacher_id : this.logdata.user_id,
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/teacher_rollcall`, user_id).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    this.list = data.rollcall
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
getdetails() {
  var type = {
    type: "",// request post data,
    teacher_id : this.logdata.user_id
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/get_teacherdrops`, type).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    // this.session_num = data.session_num
    this.tracks = data.list
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
getDatas(){
  var type = {
    trackid: $('#teacher_track').val(),
    teacher_id : this.logdata.user_id
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/teacher_rollcall`, type).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    this.list = data.rollcall
    // this.session_num = data.sessions
  
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}

  //exporting the selected data as csv
  export_data() {
    var selected_array=['student_name','total_participation'];
    var header_array=['Student Name','Participation Level'];
   this.api.downloadFile(this.list,selected_array,header_array, 'Attendence Level');
}
//
onChangePage(pageOfItems: Array<any>) {
  // update current page of items
  this.pageOfItems = pageOfItems;
}
}
