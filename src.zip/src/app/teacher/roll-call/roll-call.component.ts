import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../api.service';

import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $: any;
@Component({
  selector: 'app-roll-call',
  templateUrl: './roll-call.component.html',
  styleUrls: ['./roll-call.component.css']
})
export class RollCallComponent implements OnInit {
  logdata: any = [];
  messageForm: FormGroup;
  url = this.api.geturl();
  list: any = [];
  sections: any = [];
  items = [];
  pageOfItems: Array<any>;
  session_num: any;
  tracks: any;
  cumulative=0;
  error: boolean;
  public Editor = ClassicEditor;
  public sourceData: string;
  constructor(private api: ApiService, private http: HttpClient, private router: Router,private formBuilder: FormBuilder,) { }
  
  ngOnInit(): void {
    $('#showcount').html('0');
    $('#dropdownMenu171').addClass('active');//menu highlight
    this.sourceData = '';
    this.messageForm = this.formBuilder.group({
      global_message: new FormControl('', [Validators.required,]),
    })
    this.logdata = JSON.parse(localStorage.getItem('loginData'));
    //this.getDatas();
    
    if ((this.logdata.class == "admin") || (this.logdata.class == "executive 2") || (this.logdata.class == "executive 1") ) {
      $('#msg_form').css('display', 'none');
      $('#roll_head').html('Show roll call or take roll call in every ChiS&E classroom during the current Term / Year');
    
    }
    if ((this.logdata.class == "teacher")) {
      $('#msg_form').css('display', 'block');
    }
    this.getdetails();
    $('select').on('change', function () {
      $(this).removeClass("error");
    });
    $('.date').on('change', function () {
      $(this).removeClass("error");
    });
    $('.form-control').keypress(function () {
      $(this).removeClass("error");
    });
  }
 
   //setting value of filter
   setval(type,type3)
   {
    $('#ff').html(type3);
     $('#type').val(type);
     $('.dropdown-item').removeClass('active');
    //  $('#'+type2).addClass('active');
   }
   
   //
   //search function
   search(){
    var searchval=$('#value').val();
    if(searchval=='')
    {
      var search=0;
      $('#ff').html('Filter Unselected');
    }
    else
    var search=1;
     var user_id = {
       type : $('#type').val(),
       search : search,
       value : $('#value').val(),
       user_id : this.logdata.user_id,
       trackid: $('#teacher_track').val(),
      teacher_id : this.logdata.user_id,
      session_id:$('#sess_num').val(),
      section:$('#section').val(),
     }
     $('.pageloader').show();
     this.http.post<any>(`${this.url}/teacher_rollcall`, user_id).subscribe(data => {
       $('#export_csv').removeClass('textback');
       $('#export_csv').removeClass('disabled');
       $('.pageloader').hide();
       this.sections = data.section
       this.list = data.rollcall
     }, err => {
       $('.pageloader').hide();
       console.log(err);
     })
   }
getDatas(){
  // $("#sess_num").val([]);
  var type = {
    trackid: $('#teacher_track').val(),
    teacher_id : this.logdata.user_id
  }
  $('.pageloader').show();
  this.http.post<any>(`${this.url}/teacher_rollcall`, type).subscribe(data => {
    console.log(data)
    $('.pageloader').hide();
    this.sections = data.section
    this.session_num = data.sessions
    localStorage.setItem('set_termyear', JSON.stringify(data.term_year));
  }, err => {
    $('.pageloader').hide();
    console.log(err);
  })
}
   onSubmit() {
    if (!($('#teacher_track').val())) {
      $('#teacher_track').addClass('error');
      this.error = true;
    } else {
      $('#teacher_track').removeClass('error');
      this.error = false;
    }
    if (!($('#sess_num').val())) {
      $('#sess_num').addClass('error');
      this.error = true;
    } else {
      $('#sess_num').removeClass('error');
      this.error = false;
    }

    if (!($('#section').val())) {
      $('#section').addClass('error');
      this.error = true;
    } else {
      $('#section').removeClass('error');
      this.error = false;
    }
    if (this.error == false) {
    var type = {
      trackid: $('#teacher_track').val(),
      teacher_id : this.logdata.user_id,
      session_id:$('#sess_num').val(),
      section:$('#section').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/teacher_rollcall`, type).subscribe(data => {
      console.log(data)
        $('#export_csv').removeClass('textback');
      $('#export_csv').removeClass('disabled');
      $('.pageloader').hide();
      this.list = data.rollcall
      // this.session_num = data.sessions
      // $("#sess_num").val(data.selected_session);
   
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  }
  // set_session(){
  //   alert($('#sess_num').val())
  //   var sess_data='Session '+$('#sess_num').val();
  //   $('#session_id').html(sess_data);
  // }
  getdetails() {
    var type = {
      type: "",// request post data,
      teacher_id : this.logdata.user_id
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/get_teacherdrops`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      // this.session_num = data.session_num
      this.tracks = data.list
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
  set_Rollcall(data){
var type = {
  roll_call: $('#attendance'+data.index).val(),
  teacher_id : this.logdata.user_id,
  session_num:$('#sess_num').val(),
  trackid:$('#teacher_track').val(),
  student_id:data.student_id,
  section:$('#section').val(),
  }
// localStorage.setItem('setrollcall', JSON.stringify(type));
$('.pageloader').show();
    this.http.post<any>(`${this.url}/add_rollcall`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      if (data.status == false) {
        $('#alerttitle').html('<img src="assets/images/block.svg">Roll Call');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      else if (data.status == true) {
        $('#alerttitle').html('<img src="assets/images/success.svg">Roll Call');
        $('#alerttext').html(data.message);
        $('#alertbtn').trigger('click');
      }
      
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
   onChangePage(pageOfItems: Array<any>) {
    // update current page of items
    this.pageOfItems = pageOfItems;
  }
  getmodel(){
    if(this.messageForm.value.global_message ==''){
      // alert('empty')
      $('.ck-blurred').addClass('error');
      // $('#alerttitle').html('<img src="assets/images/block.svg">Roll Call');
      //   $('#alerttext').html('Enter Message to Send Email');
      //   $('#alertbtn').trigger('click');
    }else{
      // alert('notempty')
      $('.ck-blurred').removeClass('error');
      $('#globalbtn').trigger('click'); 
      console.log( this.messageForm.value.global_message)
      $('#show_message').html(this.messageForm.value.global_message)
      $('#teacher_name').html(this.logdata.firstname+' '+this.logdata.lastname)
      var track=$('#teacher_track option:selected').text();
      $('#track_name').html(track)
      $('#track_id').html($('#teacher_track').val())
      $('#teacher_id').html(this.logdata.user_id)
      $('#term_year').html(JSON.parse(localStorage.getItem('set_termyear')));
    }
    
  }
  export_data(){
    var type = {
      trackid: $('#teacher_track').val(),
      teacher_id : this.logdata.user_id,
      session_id:$('#sess_num').val(),
      section:$('#section').val(),
    }
    $('.pageloader').show();
    this.http.post<any>(`${this.url}/teacher_rollcall`, type).subscribe(data => {
      console.log(data)
      $('.pageloader').hide();
      // this.list = data.rollcall
      // this.session_num = data.sessions
      // $("#sess_num").val(data.selected_session);
      var selected_array=['student_name','emergency_contact','session_id','section','present'];
      var header_array=['Student Name','Emergency Contact','Session #','Section','Present?'];
      this.api.downloadFile(data.rollcall,selected_array,header_array, 'roll_Call');
      
   
    }, err => {
      $('.pageloader').hide();
      console.log(err);
    })
  }
}
