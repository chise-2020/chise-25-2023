import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-sidemenu',
  templateUrl: './teacher-sidemenu.component.html',
  styleUrls: ['./teacher-sidemenu.component.css']
})
export class TeacherSidemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
