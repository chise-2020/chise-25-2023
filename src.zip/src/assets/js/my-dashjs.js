$(".bars").click(function(){
  $(".side-bar").toggleClass("mobile-sidebar");
});